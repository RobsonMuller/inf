/*
C# example for OstroSoft POP3 Component
written by Igor Ostrovsky (OstroSoft)

For more information about OstroSoft POP3 Component go to
http://www.ostrosoft.com/ospop3.aspx

Questions, suggestions, comments - email to info@ostrosoft.com
or submit a form at http://www.ostrosoft.com/contact.asp
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using OSPOP3_Plus;

namespace pop3_csharp
{
    public class frmSession : System.Windows.Forms.Form
    {
        private Session oSession = new Session();

        #region Windows Form Designer declarations
        internal Button cmdHeaders;
        internal ColumnHeader clmSize;
        internal Button cmdDelete;
        internal Label Label4;
        internal Button cmdConnect;
        internal Button cmdView;
        internal TextBox txtPort;
        internal TextBox txtPassword;
        internal ListView lvwMessages;
        internal ColumnHeader clmID;
        internal ColumnHeader clmUIDL;
        internal Label Label3;
        internal TextBox txtLogin;
        internal Label Label1;
        internal Button cmdReset;
        internal Label label2;
        internal Button cmdRefresh;
        internal Label Label6;
        internal TextBox txtNumber;
        internal GroupBox fmMessages;
        internal Label Label5;
        internal TextBox txtSize;
        private CheckBox chkSSL;
        internal TextBox txtStatus;
        internal TextBox txtServer;
        internal GroupBox GroupBox1;

        private System.ComponentModel.Container components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdHeaders = new System.Windows.Forms.Button();
            this.clmSize = new System.Windows.Forms.ColumnHeader();
            this.cmdDelete = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.cmdConnect = new System.Windows.Forms.Button();
            this.cmdView = new System.Windows.Forms.Button();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lvwMessages = new System.Windows.Forms.ListView();
            this.clmID = new System.Windows.Forms.ColumnHeader();
            this.clmUIDL = new System.Windows.Forms.ColumnHeader();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.cmdReset = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmdRefresh = new System.Windows.Forms.Button();
            this.Label6 = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.fmMessages = new System.Windows.Forms.GroupBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.chkSSL = new System.Windows.Forms.CheckBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.fmMessages.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdHeaders
            // 
            this.cmdHeaders.Location = new System.Drawing.Point(448, 92);
            this.cmdHeaders.Name = "cmdHeaders";
            this.cmdHeaders.Size = new System.Drawing.Size(113, 23);
            this.cmdHeaders.TabIndex = 11;
            this.cmdHeaders.Text = "View Headers";
            this.cmdHeaders.Click += new System.EventHandler(this.cmdHeaders_Click);
            // 
            // clmSize
            // 
            this.clmSize.Text = "Size";
            this.clmSize.Width = 91;
            // 
            // cmdDelete
            // 
            this.cmdDelete.Location = new System.Drawing.Point(448, 120);
            this.cmdDelete.Name = "cmdDelete";
            this.cmdDelete.Size = new System.Drawing.Size(113, 23);
            this.cmdDelete.TabIndex = 12;
            this.cmdDelete.Text = "Delete Message";
            this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(400, 26);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(53, 13);
            this.Label4.TabIndex = 7;
            this.Label4.Text = "Password";
            // 
            // cmdConnect
            // 
            this.cmdConnect.Location = new System.Drawing.Point(229, 54);
            this.cmdConnect.Name = "cmdConnect";
            this.cmdConnect.Size = new System.Drawing.Size(113, 23);
            this.cmdConnect.TabIndex = 5;
            this.cmdConnect.Text = "Connect";
            this.cmdConnect.Click += new System.EventHandler(this.cmdConnect_Click);
            // 
            // cmdView
            // 
            this.cmdView.Location = new System.Drawing.Point(448, 64);
            this.cmdView.Name = "cmdView";
            this.cmdView.Size = new System.Drawing.Size(113, 23);
            this.cmdView.TabIndex = 10;
            this.cmdView.Text = "View Message";
            this.cmdView.Click += new System.EventHandler(this.cmdView_Click);
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(224, 24);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(36, 20);
            this.txtPort.TabIndex = 1;
            this.txtPort.Text = "110";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(456, 24);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(102, 20);
            this.txtPassword.TabIndex = 3;
            this.txtPassword.Text = "info";
            // 
            // lvwMessages
            // 
            this.lvwMessages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmID,
            this.clmSize,
            this.clmUIDL});
            this.lvwMessages.FullRowSelect = true;
            this.lvwMessages.HideSelection = false;
            this.lvwMessages.Location = new System.Drawing.Point(8, 56);
            this.lvwMessages.Name = "lvwMessages";
            this.lvwMessages.Size = new System.Drawing.Size(432, 128);
            this.lvwMessages.TabIndex = 13;
            this.lvwMessages.UseCompatibleStateImageBehavior = false;
            this.lvwMessages.View = System.Windows.Forms.View.Details;
            // 
            // clmID
            // 
            this.clmID.Text = "ID";
            this.clmID.Width = 38;
            // 
            // clmUIDL
            // 
            this.clmUIDL.Text = "UIDL";
            this.clmUIDL.Width = 274;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(262, 26);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(33, 13);
            this.Label3.TabIndex = 5;
            this.Label3.Text = "Login";
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(295, 24);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(105, 20);
            this.txtLogin.TabIndex = 2;
            this.txtLogin.Text = "info";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(8, 26);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(38, 13);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "Server";
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(448, 24);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(113, 23);
            this.cmdReset.TabIndex = 9;
            this.cmdReset.Text = "Reset Session";
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Port";
            // 
            // cmdRefresh
            // 
            this.cmdRefresh.Location = new System.Drawing.Point(448, 160);
            this.cmdRefresh.Name = "cmdRefresh";
            this.cmdRefresh.Size = new System.Drawing.Size(113, 23);
            this.cmdRefresh.TabIndex = 8;
            this.cmdRefresh.Text = "Refresh Msg. List";
            this.cmdRefresh.Click += new System.EventHandler(this.cmdRefresh_Click);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(232, 26);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(88, 13);
            this.Label6.TabIndex = 7;
            this.Label6.Text = "Number of emails";
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(328, 24);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(48, 20);
            this.txtNumber.TabIndex = 7;
            this.txtNumber.Text = "0";
            this.txtNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // fmMessages
            // 
            this.fmMessages.Controls.Add(this.cmdDelete);
            this.fmMessages.Controls.Add(this.cmdHeaders);
            this.fmMessages.Controls.Add(this.cmdView);
            this.fmMessages.Controls.Add(this.lvwMessages);
            this.fmMessages.Controls.Add(this.cmdReset);
            this.fmMessages.Controls.Add(this.cmdRefresh);
            this.fmMessages.Controls.Add(this.Label6);
            this.fmMessages.Controls.Add(this.txtNumber);
            this.fmMessages.Controls.Add(this.Label5);
            this.fmMessages.Controls.Add(this.txtSize);
            this.fmMessages.Location = new System.Drawing.Point(2, 80);
            this.fmMessages.Name = "fmMessages";
            this.fmMessages.Size = new System.Drawing.Size(568, 192);
            this.fmMessages.TabIndex = 17;
            this.fmMessages.TabStop = false;
            this.fmMessages.Text = "Messages";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(16, 26);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(133, 13);
            this.Label5.TabIndex = 5;
            this.Label5.Text = "Mailbox size, octets (bytes)";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(160, 24);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(56, 20);
            this.txtSize.TabIndex = 6;
            this.txtSize.Text = "0";
            this.txtSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkSSL
            // 
            this.chkSSL.AutoSize = true;
            this.chkSSL.Location = new System.Drawing.Point(148, 58);
            this.chkSSL.Name = "chkSSL";
            this.chkSSL.Size = new System.Drawing.Size(68, 17);
            this.chkSSL.TabIndex = 4;
            this.chkSSL.Text = "Use SSL";
            this.chkSSL.UseVisualStyleBackColor = true;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(10, 280);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtStatus.Size = new System.Drawing.Size(560, 144);
            this.txtStatus.TabIndex = 18;
            this.txtStatus.Text = "Connection status";
            this.txtStatus.TextChanged += new System.EventHandler(this.txtStatus_TextChanged);
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(48, 24);
            this.txtServer.Name = "txtServer";
            this.txtServer.Size = new System.Drawing.Size(141, 20);
            this.txtServer.TabIndex = 0;
            this.txtServer.Text = "localhost";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.chkSSL);
            this.GroupBox1.Controls.Add(this.label2);
            this.GroupBox1.Controls.Add(this.txtPort);
            this.GroupBox1.Controls.Add(this.cmdConnect);
            this.GroupBox1.Controls.Add(this.Label4);
            this.GroupBox1.Controls.Add(this.txtPassword);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.txtLogin);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Controls.Add(this.txtServer);
            this.GroupBox1.Location = new System.Drawing.Point(2, -11);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(568, 87);
            this.GroupBox1.TabIndex = 16;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Session";
            // 
            // frmSession
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(572, 440);
            this.Controls.Add(this.fmMessages);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.GroupBox1);
            this.Name = "frmSession";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OstroSoft POP3 Component";
            this.Load += new System.EventHandler(this.frmSession_Load);
            this.fmMessages.ResumeLayout(false);
            this.fmMessages.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        [STAThread]
        static void Main()
        {
            Application.Run(new frmSession());
        }
        #endregion

        public frmSession()
        {
            InitializeComponent();

            this.oSession = new OSPOP3_Plus.Session();
            this.oSession.ErrorPOP3 += new Session.ErrorPOP3Handler(oSession_ErrorPOP3);
            this.oSession.StatusChanged += new Session.StatusChangedHandler(oSession_StatusChanged);
            this.oSession.Closed += new Session.ClosedHandler(oSession_Closed);
            this.oSession.Connected += new Session.ConnectedHandler(oSession_Connected);
        }

        private void frmSession_Load(object sender, System.EventArgs e)
        {
            fmMessages.Enabled = false;
        }

        private void cmdConnect_Click(object sender, System.EventArgs e)
        {
            cmdConnect.Enabled = false;
            if (cmdConnect.Text == "Connect")
            {
                txtStatus.Text = "";
                oSession.UseSSL = chkSSL.Checked;
                oSession.OpenPOP3(txtServer.Text, Convert.ToInt32(txtPort.Text), txtLogin.Text, txtPassword.Text);
            }
            else
            {
                oSession.ClosePOP3();
            }
        }

        private void cmdRefresh_Click(object sender, System.EventArgs e)
        {
            GetStats();
        }

        private void cmdReset_Click(object sender, System.EventArgs e)
        {
            oSession.ResetSession();
            GetStats();
        }

        private void cmdView_Click(object sender, System.EventArgs e)
        {
            if (lvwMessages.SelectedItems.Count > 0)
            {
                frmMessage frm = new frmMessage();
                frm.iMessageID = Int32.Parse(lvwMessages.SelectedItems[0].Text);
                frm.bHeadersOnly = false;
                frm.oSession = oSession;
                frm.ShowDialog();
            }
        }

        private void cmdHeaders_Click(object sender, System.EventArgs e)
        {
            if (lvwMessages.SelectedItems.Count > 0)
            {
                frmMessage frm = new frmMessage();
                frm.iMessageID = Int32.Parse(lvwMessages.SelectedItems[0].Text);
                frm.bHeadersOnly = true;
                frm.oSession = oSession;
                frm.ShowDialog();
            }
        }

        private void cmdDelete_Click(object sender, System.EventArgs e)
        {
            if (lvwMessages.SelectedItems.Count > 0)
            {
                if (MessageBox.Show(this, "Would you like to delete a selected email?", "Confirm", System.Windows.Forms.MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    oSession.DeleteMessage(Int32.Parse(lvwMessages.SelectedItems[0].Text));
                    lvwMessages.Items.Remove(lvwMessages.SelectedItems[0]);
                }
            }
        }

        private void txtStatus_TextChanged(object sender, System.EventArgs e)
        {
            txtStatus.SelectionStart = txtStatus.Text.Length;
            txtStatus.ScrollToCaret();
        }

        private void oSession_Closed()
        {
            txtSize.Text = "0";
            txtNumber.Text = "0";
            lvwMessages.Items.Clear();

            cmdConnect.Text = "Connect";
            cmdConnect.Enabled = true;
            fmMessages.Enabled = false;
        }

        private void oSession_Connected()
        {
            GetStats();
            cmdConnect.Text = "Disconnect";
            cmdConnect.Enabled = true;
            fmMessages.Enabled = true;
        }

        private void oSession_ErrorPOP3(int number, string description)
        {
            //txtStatus.Text = txtStatus.Text + "Error " + number + ": " + description + "\r\n";
            if (oSession.State == (Session.StateConstants.popClosed))
            {
                cmdConnect.Text = "Connect";
                fmMessages.Enabled = false;
            }
            else
            {
                cmdConnect.Text = "Disconnect";
            }
            cmdConnect.Enabled = true;
        }

        private void oSession_StatusChanged(string Status, Session.StatusTypeConstants StatusType)
        {
            string sPrompt = "";
            switch ((int)StatusType)
            {
                case (int)Session.StatusTypeConstants.stPOP3Request:
                    sPrompt = "< ";
                    break;
                case (int)Session.StatusTypeConstants.stPOP3Response:
                    sPrompt = "> ";
                    break;
                case (int)Session.StatusTypeConstants.stError:
                    sPrompt = "! ";
                    break;
                case (int)Session.StatusTypeConstants.stState:
                    sPrompt = "# ";
                    break;
                default:
                    sPrompt = "? ";
                    break;
            }

            txtStatus.Text = txtStatus.Text + sPrompt + Status + "\r\n";
        }

        private void GetStats()
        {
            oSession.GetMailboxSize();
            txtSize.Text = oSession.MailboxSize.ToString();
            txtNumber.Text = oSession.MessageCount.ToString();

            ListViewItem li;
            lvwMessages.Items.Clear();
            oSession.GetMessageList();
            foreach (MessageListEntry oMLE in oSession.MessageList)
            {
                li = lvwMessages.Items.Add(oMLE.ID.ToString());
                li.SubItems.Add(oMLE.Size.ToString());
                li.SubItems.Add(oMLE.UIDL);
            }
        }
    }
}
