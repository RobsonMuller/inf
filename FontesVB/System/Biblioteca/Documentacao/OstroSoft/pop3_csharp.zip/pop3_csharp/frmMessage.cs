using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using OSPOP3_Plus;

namespace pop3_csharp
{
    public class frmMessage : System.Windows.Forms.Form
    {
        public OSPOP3_Plus.Session oSession = new OSPOP3_Plus.Session();
        private OSPOP3_Plus.Message m;

        #region Windows Form Designer generated code

        private System.ComponentModel.Container components = null;
        public int iMessageID;
        private FolderBrowserDialog dlgFolder;
        internal Panel Panel1;
        private CheckBox chkAttachments;
        private Button btnSave;
        internal TreeView tvw;
        public bool bHeadersOnly;

        public frmMessage()
        {
            InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dlgFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.chkAttachments = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.tvw = new System.Windows.Forms.TreeView();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Panel1.Controls.Add(this.chkAttachments);
            this.Panel1.Controls.Add(this.btnSave);
            this.Panel1.Location = new System.Drawing.Point(55, 320);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(218, 40);
            this.Panel1.TabIndex = 8;
            // 
            // chkAttachments
            // 
            this.chkAttachments.AutoSize = true;
            this.chkAttachments.Location = new System.Drawing.Point(93, 12);
            this.chkAttachments.Name = "chkAttachments";
            this.chkAttachments.Size = new System.Drawing.Size(121, 17);
            this.chkAttachments.TabIndex = 7;
            this.chkAttachments.Text = "include attachments";
            this.chkAttachments.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(12, 10);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tvw
            // 
            this.tvw.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tvw.Location = new System.Drawing.Point(2, 1);
            this.tvw.Name = "tvw";
            this.tvw.Size = new System.Drawing.Size(324, 313);
            this.tvw.TabIndex = 7;
            // 
            // frmMessage
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(328, 360);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.tvw);
            this.Name = "frmMessage";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Message";
            this.Load += new System.EventHandler(this.frmMessage_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

        private void frmMessage_Load(object sender, System.EventArgs e)
        {
            try
            {
                tvw.Nodes.Clear();

                if (bHeadersOnly)
                    m = oSession.GetMessageHeaders(iMessageID, 0);
                else
                    m = oSession.GetMessage(iMessageID, false);

                TreeNode nd = tvw.Nodes.Add("message " + iMessageID);

                TreeNode ndFrom = nd.Nodes.Add("from");
                ndFrom.Nodes.Add("name: " + m.Sender.Name);
                ndFrom.Nodes.Add("address: " + m.Sender.Address);

                TreeNode ndTo = nd.Nodes.Add("to");
                TreeNode ndRecipient;
                foreach (Email oEmail in m.Recipients) {
                    ndRecipient = ndTo.Nodes.Add("recipient");
                    ndRecipient.Nodes.Add("name: " + oEmail.Name);
                    ndRecipient.Nodes.Add("address: " + oEmail.Address);
                }

                TreeNode ndChild;
                ndChild = nd.Nodes.Add("subject");
                ndChild.Nodes.Add(m.Subject);

                ndChild = nd.Nodes.Add("date");
                ndChild.Nodes.Add(m.DateSent);

                ndChild = nd.Nodes.Add("Content-Type");
                ndChild.Nodes.Add(m.ContentType);

                ndChild = nd.Nodes.Add("Charset");
                ndChild.Nodes.Add(m.Charset);

                ndChild = nd.Nodes.Add("UIDL");
                ndChild.Nodes.Add(m.UIDL);

                TreeNode ndHeaders;
                ndHeaders = nd.Nodes.Add("headers");
                TreeNode ndHeader;
                foreach (Header h in m.Headers) {
                    ndHeader = ndHeaders.Nodes.Add(h.Name);
                    foreach (string s in h.Values)
                        ndHeader.Nodes.Add(s);
                }

                if (!bHeadersOnly)
                {
                    ndChild = nd.Nodes.Add("body");
                    ndChild.Nodes.Add(m.Body);

                    ndChild = nd.Nodes.Add("html");
                    ndChild.Nodes.Add(m.HTMLBody);

                    ndChild = nd.Nodes.Add("attachments");
                    TreeNode ndAttachment;
                    foreach (Attachment a in m.Attachments) {
                        ndAttachment = ndChild.Nodes.Add(a.AttachmentName);
                        ndAttachment.Nodes.Add("ContentDisposition: " + a.ContentDisposition);
                        ndAttachment.Nodes.Add("ContentTransferEncoding: " + a.ContentTransferEncoding);
                        ndAttachment.Nodes.Add("ContentType: " + a.ContentType);
                        ndAttachment.Nodes.Add("FileName: " + a.Filename);
                        ndAttachment.Nodes.Add("Body: " + a.Body);
                        //a.Save (App.Path + "\\" + a.FileName) //uncomment to save an attachment
                    }

                    //m.Save (App.Path + "\\" + m.UIDL + ".eml") //uncomment to save the message
                }

                tvw.ExpandAll();
                ndHeaders.Collapse();
                tvw.SelectedNode = nd;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dlgFolder.ShowDialog();
            string path = dlgFolder.SelectedPath;
            m.Save(path + "\\" + m.UIDL + ".eml");
            if (chkAttachments.Checked)
            {
                foreach (Attachment a in m.Attachments)
                {
                    string fileName = "";
                    int attachmentCounter = 1;
                    if (a.AttachmentName != "")
                        fileName = a.AttachmentName.Replace("\"", ""); //attachment name may contain quotes!
                    else
                    {
                        fileName = "attachment_" + attachmentCounter.ToString(); //file name can't be blank
                        if (a.ContentType == "message/rfc822")
                            fileName = fileName + ".eml";
                    }

                    a.Save(path + "\\" + fileName);
                    attachmentCounter++;
                }
            }
            MessageBox.Show("message saved");
        }
    }
}
