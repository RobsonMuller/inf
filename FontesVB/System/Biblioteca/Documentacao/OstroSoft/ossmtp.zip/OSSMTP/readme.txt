There are 2 flavors of OstroSoft SMTP Component.
Both are functionally identical, but not binary compatible.



Folder OSSMTP contains COM library.
Use it with Visual Basic 6 and earlier, VBA, VBscript, Javascript, MS SQL server and other COM-compliant languages and environments.

- OSSMTP requires Windows XP or later
- OSSMTP will not work in 64-bit Office and 64-bit MS SQL
- OSSMTP will only work in Visual Studio .NET projects set to build/compile for x86 CPU



Folder OSSMTP_Plus contains .NET library.
Use it with any .NET compliant languages.

- OSSMTP_Plus requires .NET Framework 2.0 or later
- OSSMTP_Plus.tlb is no longer included, for COM projects use OSSMTP.dll instead
