using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace smtp_aspnet_csharp
{
    public partial class frmLoadFromFile : System.Web.UI.Page
    {
        public string PAGE_TITLE = "Load HTML From File";
        public string sStatus = "";

        protected void btnAdd_ServerClick(object sender, EventArgs e)
        {
            if (File1.PostedFile != null && File1.PostedFile.ContentLength > 0)
            {
                try
                {
                    int iLength = Convert.ToInt16(File1.PostedFile.InputStream.Length);
                    byte[] bytContent = new byte[iLength];
                    File1.PostedFile.InputStream.Read(bytContent, 0, iLength);
                    string s = System.Text.Encoding.GetEncoding(1252).GetString(bytContent);

                    s = s.Replace("</script>", "<\\/script>");
                    s = s.Replace("\r\n", "\n");

                    Response.Write("<script language=javascript>");
                    Response.Write("opener.document.all.txtMessageHTML.innerText = '" + EncodeJS(s) + "';");
                    Response.Write("window.close();");
                    Response.Write("</script>");
                    Response.End();
                }
                catch (Exception exUpload)
                {
                    sStatus = "Error: " + exUpload.Message;
                }
            }
            else
                sStatus = "Please select a file to upload.";
        }

        public static string EncodeJS(string s)
        {
            if (s == null || s.Length == 0)
                return "";

            char c;
            int i;
            int len = s.Length;
            System.Text.StringBuilder sb = new System.Text.StringBuilder(len + 4);

            for (i = 0; i < len; i += 1)
            {
                c = s[i];
                if (c == '\'')
                {
                    sb.Append('\\');
                    sb.Append(c);
                }
                else if (c == '\b')
                    sb.Append("\\b");
                else if (c == '\t')
                    sb.Append("\\t");
                else if (c == '\n')
                    sb.Append("\\n");
                else if (c == '\f')
                    sb.Append("\\f");
                else if (c == '\r')
                    sb.Append("\\r");
                else
                    sb.Append(c);
            }
            return sb.ToString();
        }
    }
}
