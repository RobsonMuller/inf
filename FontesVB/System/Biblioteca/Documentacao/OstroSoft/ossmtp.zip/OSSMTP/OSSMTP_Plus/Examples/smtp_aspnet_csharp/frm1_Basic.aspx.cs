using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frm1_Basic : System.Web.UI.Page
    {
        private SMTPSession oSMTP = new SMTPSession();
        bool bClose = false;
        public string PAGE_TITLE = "Sending email (basic)";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Form["btnSendEmail"] == "Send Email")
            {
                Response.Write("<html><head><title>" + PAGE_TITLE + "</title>");
                Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>");
                Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" + PAGE_TITLE + "</p>");

                this.oSMTP = new SMTPSession();
                oSMTP.StatusChanged += new SMTPSession.StatusChangedHandler(oSMTP_StatusChanged);
                oSMTP.ErrorSMTP += new SMTPSession.ErrorSMTPHandler(oSMTP_ErrorSMTP);
                oSMTP.CloseSMTP += new SMTPSession.CloseSMTPHandler(oSMTP_CloseSMTP);

                //connection
                oSMTP.Server = Request.Form["txtServer"];
                //message
                oSMTP.MailFrom = Request.Form["txtMailFrom"];
                oSMTP.SendTo = Request.Form["txtSendTo"];
                oSMTP.MessageSubject = Request.Form["txtMessageSubject"];
                oSMTP.MessageText = Request.Form["txtMessageText"];
                //send email
                oSMTP.SendEmail();

                while (!bClose)
                    System.Threading.Thread.Sleep(10);

                oSMTP = null;
                Response.Write("<p><a href=" + this.GetType().BaseType.Name + ".aspx>Return to the form</a></p></body></html>\r\n");
                Response.End();
            }
        }

        private void oSMTP_CloseSMTP()
        {
            bClose = true;
        }

        private void oSMTP_ErrorSMTP(int number, string description)
        {
            Response.Write("Error " + number + ": " + description + "\r\n");
            bClose = true;
        }

        private void oSMTP_StatusChanged(string status)
        {
            Response.Write(Server.HtmlEncode(status + "\r\n").Replace("\r\n", "<br>"));
        }
    }
}
