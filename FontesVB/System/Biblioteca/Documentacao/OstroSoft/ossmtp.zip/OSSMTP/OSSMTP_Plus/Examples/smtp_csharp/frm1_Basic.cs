using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using OSSMTP_Plus;

namespace smtp_csharp
{
    public class frm1_Basic : System.Windows.Forms.Form
    {
        private SMTPSession oSMTP = new SMTPSession();
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox txtStatus;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtMessageText;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtMessageSubject;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtSendTo;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtMailFrom;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtServer;
        internal System.Windows.Forms.Button btnSendEmail;

        private System.ComponentModel.Container components = null;

        public frm1_Basic()
        {
            InitializeComponent();

            this.oSMTP = new OSSMTP_Plus.SMTPSession();
            oSMTP.StatusChanged += new SMTPSession.StatusChangedHandler(oSMTP_StatusChanged);
            oSMTP.ConnectSMTP += new SMTPSession.ConnectSMTPHandler(oSMTP_ConnectSMTP);
            oSMTP.ErrorSMTP += new SMTPSession.ErrorSMTPHandler(oSMTP_ErrorSMTP);
            oSMTP.SendSMTP += new SMTPSession.SendSMTPHandler(oSMTP_SendSMTP);
            oSMTP.CloseSMTP += new SMTPSession.CloseSMTPHandler(oSMTP_CloseSMTP);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.Label6 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtMessageText = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtMessageSubject = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtSendTo = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtMailFrom = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(16, 128);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(37, 13);
            this.Label6.TabIndex = 25;
            this.Label6.Text = "Status";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(8, 144);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtStatus.Size = new System.Drawing.Size(584, 168);
            this.txtStatus.TabIndex = 6;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(328, 8);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(74, 13);
            this.Label5.TabIndex = 22;
            this.Label5.Text = "Message Text";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageText
            // 
            this.txtMessageText.Location = new System.Drawing.Point(408, 8);
            this.txtMessageText.Multiline = true;
            this.txtMessageText.Name = "txtMessageText";
            this.txtMessageText.Size = new System.Drawing.Size(184, 96);
            this.txtMessageText.TabIndex = 4;
            this.txtMessageText.Text = "this is a test mail";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(8, 80);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(89, 13);
            this.Label4.TabIndex = 20;
            this.Label4.Text = "Message Subject";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageSubject
            // 
            this.txtMessageSubject.Location = new System.Drawing.Point(104, 80);
            this.txtMessageSubject.Name = "txtMessageSubject";
            this.txtMessageSubject.Size = new System.Drawing.Size(184, 20);
            this.txtMessageSubject.TabIndex = 3;
            this.txtMessageSubject.Text = "test";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(48, 56);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(48, 13);
            this.Label3.TabIndex = 18;
            this.Label3.Text = "Send To";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtSendTo
            // 
            this.txtSendTo.Location = new System.Drawing.Point(104, 56);
            this.txtSendTo.Name = "txtSendTo";
            this.txtSendTo.Size = new System.Drawing.Size(184, 20);
            this.txtSendTo.TabIndex = 2;
            this.txtSendTo.Text = "info";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(40, 32);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(52, 13);
            this.Label2.TabIndex = 16;
            this.Label2.Text = "Mail From";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMailFrom
            // 
            this.txtMailFrom.Location = new System.Drawing.Point(104, 32);
            this.txtMailFrom.Name = "txtMailFrom";
            this.txtMailFrom.Size = new System.Drawing.Size(184, 20);
            this.txtMailFrom.TabIndex = 1;
            this.txtMailFrom.Text = "test";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(56, 8);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(38, 13);
            this.Label1.TabIndex = 14;
            this.Label1.Text = "Server";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(104, 8);
            this.txtServer.Name = "txtServer";
            this.txtServer.Size = new System.Drawing.Size(184, 20);
            this.txtServer.TabIndex = 0;
            this.txtServer.Text = "localhost";
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Location = new System.Drawing.Point(256, 112);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(75, 23);
            this.btnSendEmail.TabIndex = 5;
            this.btnSendEmail.Text = "Send Email";
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // frm1_Basic
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(600, 317);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtMessageText);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtMessageSubject);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtSendTo);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtMailFrom);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtServer);
            this.Controls.Add(this.btnSendEmail);
            this.Name = "frm1_Basic";
            this.Text = "Sending email (basic)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        [STAThread]
        static void Main()
        {
            Application.Run(new frm1_Basic());
        }

        private void btnSendEmail_Click(object sender, System.EventArgs e)
        {
            txtStatus.Text = "";

            //connection
            oSMTP.Server = txtServer.Text;
            //message
            oSMTP.MailFrom = txtMailFrom.Text;
            oSMTP.SendTo = txtSendTo.Text;
            oSMTP.MessageSubject = txtMessageSubject.Text;
            oSMTP.MessageText = txtMessageText.Text;
            //send email
            oSMTP.SendEmail();
        }

        private void oSMTP_ErrorSMTP(int number, string description)
        {
            txtStatus.Text = txtStatus.Text + "Error " + number + ": " + description + "\r\n";
        }

        private void oSMTP_StatusChanged(string status)
        {
            txtStatus.Text = txtStatus.Text + status + "\r\n";
        }

        static void oSMTP_ConnectSMTP()
        {
        }

        static void oSMTP_SendSMTP()
        {
        }

        static void oSMTP_CloseSMTP()
        {
        }
    }
}