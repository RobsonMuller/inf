Namespace SMTP

    Partial Class frmEmbeddedObject
        Inherits System.Web.UI.Page
        Public sStatus As String = ""
        Public PAGE_TITLE As String = "Add Embedded Object"

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Protected Sub btnAdd_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
            Dim oEmbeddedObject As New OSSMTP_Plus.EmbeddedObject
            Dim sGUID As String = ""
            Dim sFile As String = ""

            If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
                Try
                    Dim sFileName As String
                    With File1.PostedFile
                        sGUID = System.Guid.NewGuid.ToString.Replace("-", "")
                        sFile = Server.MapPath("EmbeddedObjects") & "\" & sGUID
                        sFileName = Mid(.FileName, InStrRev(.FileName, "\") + 1)
                        oEmbeddedObject.ObjectID = sGUID
                        oEmbeddedObject.ContentType = .ContentType
                        oEmbeddedObject.FilePath = sFile
                        .SaveAs(sFile)
                    End With
                    Session(sGUID) = oEmbeddedObject
                    Response.Write("<script language=javascript>")
                    Response.Write("var ddl = window.opener.document.all.lstEmbeddedObjects;")
                    Response.Write("var opt = window.opener.document.createElement('option');")
                    Response.Write("ddl.options.add(opt);")
                    Response.Write("opt.innerText = '" & sFileName & "';")
                    Response.Write("opt.value = '" & sGUID & "';")
                    Response.Write("ddl.selectedIndex = ddl.options.length - 1;")
                    Response.Write("window.opener.document.all.btnRefresh.click();")
                    Response.Write("window.close();")
                    Response.Write("</script>")
                    Response.End()
                Catch exUpload As Exception
                    sStatus = "Error: " & exUpload.Message
                End Try
            Else
                sStatus = "Please select a file to upload."
            End If
        End Sub
    End Class

End Namespace
