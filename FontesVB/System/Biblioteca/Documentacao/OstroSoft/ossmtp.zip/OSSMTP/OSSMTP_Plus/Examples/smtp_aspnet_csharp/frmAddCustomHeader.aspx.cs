using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frmAddCustomHeader : System.Web.UI.Page
    {
        public string PAGE_TITLE = "Add Custom Header";
        public string sStatus = "";

        protected void btnAdd_ServerClick(object sender, EventArgs e)
        {
            CustomHeader oCustomHeader = new CustomHeader();
            string sGUID = "";

            if (txtHeaderName.Value == "")
            {
                sStatus = "Enter Header Name";
                return;
            }
            if (txtHeaderValue.Value == "")
            {
                sStatus = "Enter Header Value";
                return;
            }

            try
            {
                sGUID = System.Guid.NewGuid().ToString().Replace("-", "");
                oCustomHeader.HeaderName = txtHeaderName.Value;
                oCustomHeader.HeaderValue = txtHeaderValue.Value;

                Session[sGUID] = oCustomHeader;
                Response.Write("<script language=javascript>");
                Response.Write("var ddl = window.opener.document.all.lstCustomHeaders;");
                Response.Write("var opt = window.opener.document.createElement('option');");
                Response.Write("ddl.options.add(opt);");
                Response.Write("opt.innerText = '" + oCustomHeader.HeaderName + "';");
                Response.Write("opt.value = '" + sGUID + "';");
                Response.Write("ddl.selectedIndex = ddl.options.length - 1;");
                Response.Write("window.close();");
                Response.Write("</script>");
                Response.End();
            }
            catch (Exception exUpload)
            {
                sStatus = "Error: " + exUpload.Message;
            }
        }
    }
}
