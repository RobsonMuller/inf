Public Class frm2_Authentication
    Dim WithEvents oSMTP As OSSMTP_Plus.SMTPSession

    Private Sub btnSendEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        txtStatus.Text = ""
        With oSMTP
            'connection
            .Server = txtServer.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedIndex
            If txtUsername.Text <> "" Then .Username = txtUsername.Text
            If txtPassword.Text <> "" Then .Password = txtPassword.Text
            If txtPOPServer.Text <> "" Then .POPServer = txtPOPServer.Text
            .UseSSL = chkSSL.Checked
            'message
            .MailFrom = txtMailFrom.Text
            .SendTo = txtSendTo.Text
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            'send email
            .SendEmail()
        End With
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin, OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Integer, ByVal Description As String) Handles oSMTP.ErrorSMTP
        txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        txtStatus.Text = txtStatus.Text & Status & vbCrLf
    End Sub

    Private Sub frm1_Basic_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        oSMTP = New OSSMTP_Plus.SMTPSession
        With ddlAuthenticationType.Items
            .Add("None")
            .Add("POP3")
            .Add("AUTH LOGIN")
            .Add("AUTH PLAIN")
        End With
        ddlAuthenticationType.SelectedIndex = 0
    End Sub

    Private Sub frm1_Basic_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        oSMTP = Nothing
    End Sub
End Class
