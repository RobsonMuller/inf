using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frm3_Attachments : System.Web.UI.Page
    {
        private SMTPSession oSMTP = new SMTPSession();
        bool bClose = false;
        public string PAGE_TITLE = "Sending email (with attachments)";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                AddListItem("None", SMTPSession.authentication_type.AuthNone);
                AddListItem("POP3", SMTPSession.authentication_type.AuthPOP);
                AddListItem("AUTH LOGIN", SMTPSession.authentication_type.AuthLogin);
                AddListItem("AUTH PLAIN", SMTPSession.authentication_type.AuthPlain);
                ddlAuthenticationType.SelectedIndex = 0;
            }
            if (Request.Form["btnSendEmail"] == "Send Email")
            {
                Response.Write("<html><head><title>" + PAGE_TITLE + "</title>");
                Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>");
                Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" + PAGE_TITLE + "</p>");

                this.oSMTP = new SMTPSession();
                oSMTP.StatusChanged += new SMTPSession.StatusChangedHandler(oSMTP_StatusChanged);
                oSMTP.ErrorSMTP += new SMTPSession.ErrorSMTPHandler(oSMTP_ErrorSMTP);
                oSMTP.CloseSMTP += new SMTPSession.CloseSMTPHandler(oSMTP_CloseSMTP);

                //connection
                oSMTP.Server = Request.Form["txtServer"];
                //authentication
                oSMTP.AuthenticationType = (SMTPSession.authentication_type)Convert.ToInt16(Request.Form["ddlAuthenticationType"]);
                oSMTP.Username = Request.Form["txtUsername"];
                oSMTP.Password = Request.Form["txtPassword"];
                oSMTP.POPServer = Request.Form["txtPOPServer"];
                oSMTP.UseSSL = chkSSL.Checked;
                //message
                oSMTP.MailFrom = Request.Form["txtMailFrom"];
                oSMTP.SendTo = Request.Form["txtSendTo"];
                oSMTP.MessageSubject = Request.Form["txtMessageSubject"];
                oSMTP.MessageText = Request.Form["txtMessageText"];
                //attachments
                if (!String.IsNullOrEmpty(Request.Form["lstAttachments"]))
                {
                    Attachment oAttachment = new Attachment();
                    string[] sAttachments = Request.Form["lstAttachments"].Split(',');
                    for (int i = 0; i < sAttachments.Length; i++)
                    {
                        oAttachment = (Attachment)Session[sAttachments[i]];
                        oSMTP.Attachments.Add(oAttachment);
                    }
                }
                //send email
                oSMTP.SendEmail();

                while (!bClose)
                    System.Threading.Thread.Sleep(10);

                oSMTP = null;
                Response.Write("<p><a href=" + this.GetType().BaseType.Name + ".aspx>Return to the form</a></p></body></html>\r\n");
                Response.End();
            }
        }

        private void oSMTP_CloseSMTP()
        {
            bClose = true;
        }

        private void oSMTP_ErrorSMTP(int number, string description)
        {
            Response.Write("Error " + number + ": " + description + "\r\n");
            bClose = true;
        }

        private void oSMTP_StatusChanged(string status)
        {
            Response.Write(Server.HtmlEncode(status + "\r\n").Replace("\r\n", "<br>"));
        }

        private void AddListItem(string _caption, SMTPSession.authentication_type _auth)
        {
            ddlAuthenticationType.Items.Add(new ListItem(_caption, Convert.ToInt16(_auth).ToString()));
        }

        protected void ddlAuthenticationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch ((SMTPSession.authentication_type)ddlAuthenticationType.SelectedIndex)
            {
                case SMTPSession.authentication_type.AuthNone:
                    txtUsername.Enabled = false;
                    txtUsername.Text = "";
                    txtPassword.Enabled = false;
                    txtPassword.Text = "";
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
                case SMTPSession.authentication_type.AuthPOP:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = true;
                    break;
                case SMTPSession.authentication_type.AuthLogin:
                case SMTPSession.authentication_type.AuthPlain:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
            }
        }
    }
}
