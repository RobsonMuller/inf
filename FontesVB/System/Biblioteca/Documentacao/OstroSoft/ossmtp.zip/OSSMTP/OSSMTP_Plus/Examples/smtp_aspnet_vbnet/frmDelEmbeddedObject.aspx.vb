Namespace SMTP

    Partial Class frmDelEmbeddedObject
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
            Dim s As String = ""
            Try
                s = Request.QueryString("s")
            Catch ex As Exception
            End Try

            Response.Write("<script language=javascript>")
            If s <> "" Then
                Dim oEmbeddedObject As New OSSMTP_Plus.EmbeddedObject
                oEmbeddedObject = Session(s)
                System.IO.File.Delete(oEmbeddedObject.FilePath)
                Session(s) = Nothing

                Response.Write("var ddl = window.opener.document.all.lstEmbeddedObjects;")
                Response.Write("ddl.options.remove(ddl.selectedIndex);")
                Response.Write("window.opener.document.all.btnRefresh.click();")
            End If
            Response.Write("window.close();")
            Response.Write("</script>")
            Response.End()
        End Sub

    End Class

End Namespace
