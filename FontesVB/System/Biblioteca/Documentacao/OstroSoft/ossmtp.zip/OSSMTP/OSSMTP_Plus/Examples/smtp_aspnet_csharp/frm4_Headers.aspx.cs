using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frm4_Headers : System.Web.UI.Page
    {
        private SMTPSession oSMTP = new SMTPSession();
        bool bClose = false;
        public string PAGE_TITLE = "Sending email (with extra headers and additional recipients)";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) PopulateDropDowns();

            if (Request.Form["btnSendEmail"] == "Send Email")
            {
                Response.Write("<html><head><title>" + PAGE_TITLE + "</title>");
                Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>");
                Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" + PAGE_TITLE + "</p>");

                this.oSMTP = new SMTPSession();
                oSMTP.StatusChanged += new SMTPSession.StatusChangedHandler(oSMTP_StatusChanged);
                oSMTP.ErrorSMTP += new SMTPSession.ErrorSMTPHandler(oSMTP_ErrorSMTP);
                oSMTP.CloseSMTP += new SMTPSession.CloseSMTPHandler(oSMTP_CloseSMTP);

                //connection
                oSMTP.Server = Request.Form["txtServer"];
                //authentication
                oSMTP.AuthenticationType = (SMTPSession.authentication_type)Convert.ToInt16(Request.Form["ddlAuthenticationType"]);
                oSMTP.Username = Request.Form["txtUsername"];
                oSMTP.Password = Request.Form["txtPassword"];
                oSMTP.POPServer = Request.Form["txtPOPServer"];
                oSMTP.UseSSL = chkSSL.Checked;
                //sender and extra headers
                oSMTP.MailFrom = Request.Form["txtMailFrom"];
                if (Request.Form["txtExpiresAfter"] != "") 
                    oSMTP.ExpiresAfter = Request.Form["txtExpiresAfter"];
                oSMTP.Importance = (SMTPSession.importance_level)Convert.ToInt16(Request.Form["ddlImportance"]);
                oSMTP.Notification = (SMTPSession.notification_type)Convert.ToInt16(Request.Form["ddlNotification"]);
                if (Request.Form["txtReplyTo"] != "") 
                    oSMTP.ReplyTo = Request.Form["txtReplyTo"];
                oSMTP.Sensitivity = (SMTPSession.sensitivity_level)Convert.ToInt16(Request.Form["ddlSensitivity"]);
                if (Request.Form["txtTimeStamp"] != "") 
                    oSMTP.TimeStamp = Request.Form["txtTimeStamp"];
                //custom headers
                if (!String.IsNullOrEmpty(Request.Form["lstCustomHeaders"]))
                {
                    CustomHeader oCustomHeader = new CustomHeader();
                    string[] sCustomHeaders = Request.Form["lstCustomHeaders"].Split(',');
                    for (int i = 0; i < sCustomHeaders.Length; i++)
                    {
                        oCustomHeader = (CustomHeader)Session[sCustomHeaders[i]];
                        oSMTP.CustomHeaders.Add(oCustomHeader);
                    }
                }
                //recipients
                oSMTP.SendTo = Request.Form["txtSendTo"];
                if (Request.Form["txtBCC"] != "") 
                    oSMTP.BCC = Request.Form["txtBCC"];
                if (Request.Form["txtCC"] != "") 
                    oSMTP.CC = Request.Form["txtCC"];
                //message
                oSMTP.MessageSubject = Request.Form["txtMessageSubject"];
                oSMTP.MessageText = Request.Form["txtMessageText"];
                if (Request.Form["txtCharset"] != "") 
                    oSMTP.Charset = Request.Form["txtCharset"];
                if (Request.Form["txtContentTransferEncoding"] != "") 
                    oSMTP.ContentTransferEncoding = Request.Form["txtContentTransferEncoding"];
                if (Request.Form["txtContentType"] != "") 
                    oSMTP.ContentType = Request.Form["txtContentType"];
                //attachments
                if (!String.IsNullOrEmpty(Request.Form["lstAttachments"]))
                {
                    Attachment oAttachment = new Attachment();
                    string[] sAttachments = Request.Form["lstAttachments"].Split(',');
                    for (int i = 0; i < sAttachments.Length; i++)
                    {
                        oAttachment = (Attachment)Session[sAttachments[i]];
                        oSMTP.Attachments.Add(oAttachment);
                    }
                }
                //send email
                oSMTP.SendEmail();

                while (!bClose)
                    System.Threading.Thread.Sleep(10);

                oSMTP = null;
                Response.Write("<p><a href=" + this.GetType().BaseType.Name + ".aspx>Return to the form</a></p></body></html>\r\n");
                Response.End();
            }
        }

        private void oSMTP_CloseSMTP()
        {
            bClose = true;
        }

        private void oSMTP_ErrorSMTP(int number, string description)
        {
            Response.Write("Error " + number + ": " + description + "\r\n");
            bClose = true;
        }

        private void oSMTP_StatusChanged(string status)
        {
            Response.Write(Server.HtmlEncode(status + "\r\n").Replace("\r\n", "<br>"));
        }

        #region dropdowns
        private void PopulateDropDowns()
        {
            AddListItem("None", SMTPSession.authentication_type.AuthNone);
            AddListItem("POP3", SMTPSession.authentication_type.AuthPOP);
            AddListItem("AUTH LOGIN", SMTPSession.authentication_type.AuthLogin);
            AddListItem("AUTH PLAIN", SMTPSession.authentication_type.AuthPlain);
            ddlAuthenticationType.SelectedIndex = 0;

            AddListItem("Normal", SMTPSession.importance_level.ImportanceNormal);
            AddListItem("Low", SMTPSession.importance_level.ImportanceLow);
            AddListItem("High", SMTPSession.importance_level.ImportanceHigh);
            ddlImportance.SelectedIndex = 0;

            AddListItem("None", SMTPSession.notification_type.NotificationNone);
            AddListItem("On Delivery", SMTPSession.notification_type.NotificationDelivery);
            AddListItem("On Read", SMTPSession.notification_type.NotificationRead);
            AddListItem("On Delivery And Read", SMTPSession.notification_type.NotificationDeliveryAndRead);
            ddlNotification.SelectedIndex = 0;

            AddListItem("Normal", SMTPSession.sensitivity_level.SensitivityNormal);
            AddListItem("Personal", SMTPSession.sensitivity_level.SensitivityPersonal);
            AddListItem("Private", SMTPSession.sensitivity_level.SensitivityPrivate);
            AddListItem("Confidential", SMTPSession.sensitivity_level.SensitivityConfidential);
            ddlSensitivity.SelectedIndex = 0;
        }

        private void AddListItem(string _caption, SMTPSession.authentication_type _auth)
        {
            ddlAuthenticationType.Items.Add(new ListItem(_caption, Convert.ToInt16(_auth).ToString()));
        }

        private void AddListItem(string _caption, SMTPSession.importance_level _imp)
        {
            ddlImportance.Items.Add(new ListItem(_caption, Convert.ToInt16(_imp).ToString()));
        }

        private void AddListItem(string _caption, SMTPSession.notification_type _notif)
        {
            ddlNotification.Items.Add(new ListItem(_caption, Convert.ToInt16(_notif).ToString()));
        }

        private void AddListItem(string _caption, SMTPSession.sensitivity_level _sens)
        {
            ddlSensitivity.Items.Add(new ListItem(_caption, Convert.ToInt16(_sens).ToString()));
        }
        #endregion

        protected void ddlAuthenticationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch ((SMTPSession.authentication_type)ddlAuthenticationType.SelectedIndex)
            {
                case SMTPSession.authentication_type.AuthNone:
                    txtUsername.Enabled = false;
                    txtUsername.Text = "";
                    txtPassword.Enabled = false;
                    txtPassword.Text = "";
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
                case SMTPSession.authentication_type.AuthPOP:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = true;
                    break;
                case SMTPSession.authentication_type.AuthLogin:
                case SMTPSession.authentication_type.AuthPlain:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
            }
        }
    }
}
