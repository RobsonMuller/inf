<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl = New System.Windows.Forms.Label
        Me.btnHTML = New System.Windows.Forms.Button
        Me.btnBasic = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnAll = New System.Windows.Forms.Button
        Me.btnHeaders = New System.Windows.Forms.Button
        Me.btnAttachments = New System.Windows.Forms.Button
        Me.btnAuthentication = New System.Windows.Forms.Button
        Me.btnEmbedded = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lbl
        '
        Me.lbl.Location = New System.Drawing.Point(22, 243)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(392, 56)
        Me.lbl.TabIndex = 22
        '
        'btnHTML
        '
        Me.btnHTML.Location = New System.Drawing.Point(18, 171)
        Me.btnHTML.Name = "btnHTML"
        Me.btnHTML.Size = New System.Drawing.Size(392, 23)
        Me.btnHTML.TabIndex = 5
        Me.btnHTML.Text = "Sending email (with HTML part)"
        '
        'btnBasic
        '
        Me.btnBasic.Location = New System.Drawing.Point(18, 11)
        Me.btnBasic.Name = "btnBasic"
        Me.btnBasic.Size = New System.Drawing.Size(392, 23)
        Me.btnBasic.TabIndex = 0
        Me.btnBasic.Text = "Sending email (basic)"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(350, 315)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(64, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        '
        'btnAll
        '
        Me.btnAll.Location = New System.Drawing.Point(18, 140)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(392, 23)
        Me.btnAll.TabIndex = 4
        Me.btnAll.Text = "Sending email (all properties, collections and methods)"
        '
        'btnHeaders
        '
        Me.btnHeaders.Location = New System.Drawing.Point(18, 108)
        Me.btnHeaders.Name = "btnHeaders"
        Me.btnHeaders.Size = New System.Drawing.Size(392, 23)
        Me.btnHeaders.TabIndex = 3
        Me.btnHeaders.Text = "Sending email (with extra headers and additional recipients)"
        '
        'btnAttachments
        '
        Me.btnAttachments.Location = New System.Drawing.Point(18, 76)
        Me.btnAttachments.Name = "btnAttachments"
        Me.btnAttachments.Size = New System.Drawing.Size(392, 23)
        Me.btnAttachments.TabIndex = 2
        Me.btnAttachments.Text = "Sending email (with attachments)"
        '
        'btnAuthentication
        '
        Me.btnAuthentication.Location = New System.Drawing.Point(18, 44)
        Me.btnAuthentication.Name = "btnAuthentication"
        Me.btnAuthentication.Size = New System.Drawing.Size(392, 23)
        Me.btnAuthentication.TabIndex = 1
        Me.btnAuthentication.Text = "Sending email (with authentication)"
        '
        'btnEmbedded
        '
        Me.btnEmbedded.Location = New System.Drawing.Point(20, 208)
        Me.btnEmbedded.Name = "btnEmbedded"
        Me.btnEmbedded.Size = New System.Drawing.Size(392, 23)
        Me.btnEmbedded.TabIndex = 23
        Me.btnEmbedded.Text = "Sending email (with embedded objects)"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(432, 349)
        Me.Controls.Add(Me.btnEmbedded)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.btnHTML)
        Me.Controls.Add(Me.btnBasic)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAll)
        Me.Controls.Add(Me.btnHeaders)
        Me.Controls.Add(Me.btnAttachments)
        Me.Controls.Add(Me.btnAuthentication)
        Me.Name = "frmMain"
        Me.Text = "VB.NET samples for OstroSoft SMTP Component (OSSMTP_Plus.dll)"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbl As System.Windows.Forms.Label
    Friend WithEvents btnHTML As System.Windows.Forms.Button
    Friend WithEvents btnBasic As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnAll As System.Windows.Forms.Button
    Friend WithEvents btnHeaders As System.Windows.Forms.Button
    Friend WithEvents btnAttachments As System.Windows.Forms.Button
    Friend WithEvents btnAuthentication As System.Windows.Forms.Button
    Friend WithEvents btnEmbedded As System.Windows.Forms.Button
End Class
