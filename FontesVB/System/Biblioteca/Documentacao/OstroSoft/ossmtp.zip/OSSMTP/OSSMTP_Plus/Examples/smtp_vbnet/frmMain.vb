Public Class frmMain

    Private Sub btnBasic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBasic.Click
        Dim frm As New frm1_Basic
        frm.Show()
    End Sub

    Private Sub btnAuthentication_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAuthentication.Click
        Dim frm As New frm2_Authentication
        frm.Show()
    End Sub

    Private Sub btnAttachments_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAttachments.Click
        Dim frm As New frm3_Attachments
        frm.Show()
    End Sub

    Private Sub btnHeaders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHeaders.Click
        Dim frm As New frm4_Headers
        frm.Show()
    End Sub

    Private Sub btnAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAll.Click
        Dim frm As New frm5_All
        frm.Show()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnHTML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHTML.Click
        Dim frm As New frm6_HTML
        frm.Show()
    End Sub

    Private Sub btnEmbedded_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmbedded.Click
        Dim frm As New frm7_Embedded
        frm.Show()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbl.Text = "OstroSoft SMTP Component example for Visual Basic.NET," & vbCrLf & _
          "written by Igor Ostrovsky (OstroSoft)" & vbCrLf & _
          "For more information about OstroSoft SMTP Component go to " & vbCrLf & _
          "http://www.ostrosoft.com/ossmtp.aspx"
    End Sub
End Class