<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm6_HTML
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkSSL = New System.Windows.Forms.CheckBox
        Me.btnLoadFromURL = New System.Windows.Forms.Button
        Me.btnLoadFromFile = New System.Windows.Forms.Button
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtMessageHTML = New System.Windows.Forms.TextBox
        Me.dlg = New System.Windows.Forms.OpenFileDialog
        Me.btnOK = New System.Windows.Forms.Button
        Me.grpURL = New System.Windows.Forms.GroupBox
        Me.btnCancel = New System.Windows.Forms.Button
        Me.txtURL = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtPOPServer = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.ddlAuthenticationType = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.txtMessageText = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMessageSubject = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMailFrom = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtSendTo = New System.Windows.Forms.TextBox
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.btnSendEmail = New System.Windows.Forms.Button
        Me.grpURL.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkSSL
        '
        Me.chkSSL.AutoSize = True
        Me.chkSSL.Location = New System.Drawing.Point(12, 322)
        Me.chkSSL.Name = "chkSSL"
        Me.chkSSL.Size = New System.Drawing.Size(128, 17)
        Me.chkSSL.TabIndex = 9
        Me.chkSSL.Text = "Use secure SSL/TLS"
        Me.chkSSL.UseVisualStyleBackColor = True
        '
        'btnLoadFromURL
        '
        Me.btnLoadFromURL.Location = New System.Drawing.Point(456, 287)
        Me.btnLoadFromURL.Name = "btnLoadFromURL"
        Me.btnLoadFromURL.Size = New System.Drawing.Size(96, 23)
        Me.btnLoadFromURL.TabIndex = 13
        Me.btnLoadFromURL.Text = "Load from URL"
        '
        'btnLoadFromFile
        '
        Me.btnLoadFromFile.Location = New System.Drawing.Point(344, 287)
        Me.btnLoadFromFile.Name = "btnLoadFromFile"
        Me.btnLoadFromFile.Size = New System.Drawing.Size(96, 23)
        Me.btnLoadFromFile.TabIndex = 12
        Me.btnLoadFromFile.Text = "Load from file"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(304, 7)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 13)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Message HTML"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageHTML
        '
        Me.txtMessageHTML.Location = New System.Drawing.Point(304, 23)
        Me.txtMessageHTML.Multiline = True
        Me.txtMessageHTML.Name = "txtMessageHTML"
        Me.txtMessageHTML.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMessageHTML.Size = New System.Drawing.Size(288, 256)
        Me.txtMessageHTML.TabIndex = 10
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(64, 56)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 20)
        Me.btnOK.TabIndex = 14
        Me.btnOK.Text = "OK"
        '
        'grpURL
        '
        Me.grpURL.Controls.Add(Me.btnOK)
        Me.grpURL.Controls.Add(Me.btnCancel)
        Me.grpURL.Controls.Add(Me.txtURL)
        Me.grpURL.Location = New System.Drawing.Point(264, 263)
        Me.grpURL.Name = "grpURL"
        Me.grpURL.Size = New System.Drawing.Size(288, 88)
        Me.grpURL.TabIndex = 11
        Me.grpURL.TabStop = False
        Me.grpURL.Text = "Enter URL"
        Me.grpURL.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(144, 56)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 20)
        Me.btnCancel.TabIndex = 15
        Me.btnCancel.Text = "Cancel"
        '
        'txtURL
        '
        Me.txtURL.Location = New System.Drawing.Point(8, 24)
        Me.txtURL.Name = "txtURL"
        Me.txtURL.Size = New System.Drawing.Size(272, 20)
        Me.txtURL.TabIndex = 11
        Me.txtURL.Text = "http://www.ostrosoft.com"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtPOPServer)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.ddlAuthenticationType)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 116)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Authentication settings"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(59, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Type"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "POP3 Server"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPOPServer
        '
        Me.txtPOPServer.Location = New System.Drawing.Point(96, 88)
        Me.txtPOPServer.Name = "txtPOPServer"
        Me.txtPOPServer.Size = New System.Drawing.Size(184, 20)
        Me.txtPOPServer.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(34, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Password"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(96, 64)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(184, 20)
        Me.txtPassword.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Username"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(96, 40)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(184, 20)
        Me.txtUsername.TabIndex = 2
        '
        'ddlAuthenticationType
        '
        Me.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlAuthenticationType.Location = New System.Drawing.Point(96, 16)
        Me.ddlAuthenticationType.Name = "ddlAuthenticationType"
        Me.ddlAuthenticationType.Size = New System.Drawing.Size(184, 21)
        Me.ddlAuthenticationType.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 343)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Status"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 223)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Message Text"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(8, 359)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(584, 168)
        Me.txtStatus.TabIndex = 15
        '
        'txtMessageText
        '
        Me.txtMessageText.Location = New System.Drawing.Point(104, 223)
        Me.txtMessageText.Multiline = True
        Me.txtMessageText.Name = "txtMessageText"
        Me.txtMessageText.Size = New System.Drawing.Size(184, 96)
        Me.txtMessageText.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 199)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "Message Subject"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageSubject
        '
        Me.txtMessageSubject.Location = New System.Drawing.Point(104, 199)
        Me.txtMessageSubject.Name = "txtMessageSubject"
        Me.txtMessageSubject.Size = New System.Drawing.Size(184, 20)
        Me.txtMessageSubject.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Mail From"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMailFrom
        '
        Me.txtMailFrom.Location = New System.Drawing.Point(104, 151)
        Me.txtMailFrom.Name = "txtMailFrom"
        Me.txtMailFrom.Size = New System.Drawing.Size(184, 20)
        Me.txtMailFrom.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Server"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Send To"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtSendTo
        '
        Me.txtSendTo.Location = New System.Drawing.Point(104, 175)
        Me.txtSendTo.Name = "txtSendTo"
        Me.txtSendTo.Size = New System.Drawing.Size(184, 20)
        Me.txtSendTo.TabIndex = 6
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(104, 5)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(184, 20)
        Me.txtServer.TabIndex = 0
        '
        'btnSendEmail
        '
        Me.btnSendEmail.Location = New System.Drawing.Point(264, 327)
        Me.btnSendEmail.Name = "btnSendEmail"
        Me.btnSendEmail.Size = New System.Drawing.Size(75, 23)
        Me.btnSendEmail.TabIndex = 14
        Me.btnSendEmail.Text = "Send Email"
        '
        'frm6_HTML
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 533)
        Me.Controls.Add(Me.grpURL)
        Me.Controls.Add(Me.chkSSL)
        Me.Controls.Add(Me.btnLoadFromURL)
        Me.Controls.Add(Me.btnLoadFromFile)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtMessageHTML)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.txtMessageText)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtMessageSubject)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMailFrom)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtSendTo)
        Me.Controls.Add(Me.txtServer)
        Me.Controls.Add(Me.btnSendEmail)
        Me.Name = "frm6_HTML"
        Me.Text = "Sending email (with HTML part)"
        Me.grpURL.ResumeLayout(False)
        Me.grpURL.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents chkSSL As System.Windows.Forms.CheckBox
    Friend WithEvents btnLoadFromURL As System.Windows.Forms.Button
    Friend WithEvents btnLoadFromFile As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtMessageHTML As System.Windows.Forms.TextBox
    Friend WithEvents dlg As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents grpURL As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents txtURL As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPOPServer As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents ddlAuthenticationType As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtMessageText As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMessageSubject As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMailFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSendTo As System.Windows.Forms.TextBox
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents btnSendEmail As System.Windows.Forms.Button
End Class
