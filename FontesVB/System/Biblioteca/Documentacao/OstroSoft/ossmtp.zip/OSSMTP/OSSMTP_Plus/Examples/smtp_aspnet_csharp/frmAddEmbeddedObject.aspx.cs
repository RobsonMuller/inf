using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frmAddEmbeddedObject : System.Web.UI.Page
    {
        public string PAGE_TITLE = "Add Embedded Object";
        public string sStatus = "";

        protected void btnAdd_ServerClick(object sender, EventArgs e)
        {
            EmbeddedObject oEmbeddedObject = new EmbeddedObject();
            string sGUID = "";
            string sFile = "";

            if (File1.PostedFile != null && File1.PostedFile.ContentLength > 0)
            {
                try
                {
                    string sFileName;
                    sGUID = System.Guid.NewGuid().ToString().Replace("-", "");
                    sFile = Server.MapPath("EmbeddedObjects") + "\\" + sGUID;
                    sFileName = File1.PostedFile.FileName.Substring(File1.PostedFile.FileName.LastIndexOf("\\") + 1);
                    oEmbeddedObject.ObjectID = sGUID;
                    oEmbeddedObject.ContentType = File1.PostedFile.ContentType;
                    oEmbeddedObject.FilePath = sFile;
                    File1.PostedFile.SaveAs(sFile);

                    Session[sGUID] = oEmbeddedObject;
                    Response.Write("<script language=javascript>");
                    Response.Write("var ddl = window.opener.document.all.lstEmbeddedObjects;");
                    Response.Write("var opt = window.opener.document.createElement('option');");
                    Response.Write("ddl.options.add(opt);");
                    Response.Write("opt.innerText = '" + sFileName + "';");
                    Response.Write("opt.value = '" + sGUID + "';");
                    Response.Write("ddl.selectedIndex = ddl.options.length - 1;");
                    Response.Write("window.opener.document.all.btnRefresh.click();");
                    Response.Write("window.close();");
                    Response.Write("</script>");
                    Response.End();
                }
                catch (Exception exUpload)
                {
                    sStatus = "Error: " + exUpload.Message;
                }
            }
            else
                sStatus = "Please select a file to upload.";
        }
    }
}
