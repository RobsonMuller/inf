<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm7_Embedded
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkSSL = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnDel = New System.Windows.Forms.Button
        Me.btnAdd = New System.Windows.Forms.Button
        Me.lstEmbeddedObjects = New System.Windows.Forms.ListBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtPOPServer = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.ddlAuthenticationType = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtMessageHTML = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMessageSubject = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtSendTo = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMailFrom = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.btnSendEmail = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkSSL
        '
        Me.chkSSL.AutoSize = True
        Me.chkSSL.Location = New System.Drawing.Point(11, 230)
        Me.chkSSL.Name = "chkSSL"
        Me.chkSSL.Size = New System.Drawing.Size(128, 17)
        Me.chkSSL.TabIndex = 5
        Me.chkSSL.Text = "Use secure SSL/TLS"
        Me.chkSSL.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDel)
        Me.GroupBox2.Controls.Add(Me.btnAdd)
        Me.GroupBox2.Controls.Add(Me.lstEmbeddedObjects)
        Me.GroupBox2.Location = New System.Drawing.Point(312, 111)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(272, 136)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Embedded Objects"
        '
        'btnDel
        '
        Me.btnDel.Location = New System.Drawing.Point(152, 104)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(75, 23)
        Me.btnDel.TabIndex = 12
        Me.btnDel.Text = "Delete"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(64, 104)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 11
        Me.btnAdd.Text = "Add"
        '
        'lstEmbeddedObjects
        '
        Me.lstEmbeddedObjects.HorizontalScrollbar = True
        Me.lstEmbeddedObjects.Location = New System.Drawing.Point(8, 16)
        Me.lstEmbeddedObjects.Name = "lstEmbeddedObjects"
        Me.lstEmbeddedObjects.Size = New System.Drawing.Size(256, 82)
        Me.lstEmbeddedObjects.TabIndex = 10
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtPOPServer)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.ddlAuthenticationType)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 116)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Authentication settings"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(59, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Type"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "POP3 Server"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPOPServer
        '
        Me.txtPOPServer.Location = New System.Drawing.Point(96, 88)
        Me.txtPOPServer.Name = "txtPOPServer"
        Me.txtPOPServer.Size = New System.Drawing.Size(184, 20)
        Me.txtPOPServer.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(34, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Password"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(96, 64)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(184, 20)
        Me.txtPassword.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Username"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(96, 40)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(184, 20)
        Me.txtUsername.TabIndex = 2
        '
        'ddlAuthenticationType
        '
        Me.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlAuthenticationType.Location = New System.Drawing.Point(96, 16)
        Me.ddlAuthenticationType.Name = "ddlAuthenticationType"
        Me.ddlAuthenticationType.Size = New System.Drawing.Size(184, 21)
        Me.ddlAuthenticationType.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 271)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Status"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(8, 287)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(584, 168)
        Me.txtStatus.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(313, 7)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 13)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Message HTML"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageHTML
        '
        Me.txtMessageHTML.Location = New System.Drawing.Point(312, 23)
        Me.txtMessageHTML.Multiline = True
        Me.txtMessageHTML.Name = "txtMessageHTML"
        Me.txtMessageHTML.Size = New System.Drawing.Size(272, 80)
        Me.txtMessageHTML.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 199)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "Message Subject"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageSubject
        '
        Me.txtMessageSubject.Location = New System.Drawing.Point(104, 199)
        Me.txtMessageSubject.Name = "txtMessageSubject"
        Me.txtMessageSubject.Size = New System.Drawing.Size(184, 20)
        Me.txtMessageSubject.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Send To"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtSendTo
        '
        Me.txtSendTo.Location = New System.Drawing.Point(104, 175)
        Me.txtSendTo.Name = "txtSendTo"
        Me.txtSendTo.Size = New System.Drawing.Size(184, 20)
        Me.txtSendTo.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Mail From"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMailFrom
        '
        Me.txtMailFrom.Location = New System.Drawing.Point(104, 151)
        Me.txtMailFrom.Name = "txtMailFrom"
        Me.txtMailFrom.Size = New System.Drawing.Size(184, 20)
        Me.txtMailFrom.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "Server"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(104, 5)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(184, 20)
        Me.txtServer.TabIndex = 0
        '
        'btnSendEmail
        '
        Me.btnSendEmail.Location = New System.Drawing.Point(264, 255)
        Me.btnSendEmail.Name = "btnSendEmail"
        Me.btnSendEmail.Size = New System.Drawing.Size(75, 23)
        Me.btnSendEmail.TabIndex = 8
        Me.btnSendEmail.Text = "Send Email"
        '
        'frm7_Embedded
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 461)
        Me.Controls.Add(Me.chkSSL)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtMessageHTML)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtMessageSubject)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtSendTo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMailFrom)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtServer)
        Me.Controls.Add(Me.btnSendEmail)
        Me.Name = "frm7_Embedded"
        Me.Text = "Sending email (with attachments)"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents chkSSL As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lstEmbeddedObjects As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPOPServer As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents ddlAuthenticationType As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMessageHTML As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMessageSubject As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSendTo As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMailFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents btnSendEmail As System.Windows.Forms.Button
End Class
