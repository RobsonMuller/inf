Namespace SMTP

    Partial Class frm7_Embedded
        Inherits System.Web.UI.Page
        Dim WithEvents oSMTP As OSSMTP_Plus.SMTPSession
        Dim bClose As Boolean = False
        Public PAGE_TITLE As String = "Sending email (with Embedded Objects)"

#Region " Web Form Controls "
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.ID = "frmMain"

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
            If Not IsPostBack Then
                With ddlAuthenticationType.Items
                    .Add(New ListItem("None", OSSMTP_Plus.SMTPSession.authentication_type.AuthNone))
                    .Add(New ListItem("POP3", OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP))
                    .Add(New ListItem("AUTH LOGIN", OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin))
                    .Add(New ListItem("AUTH PLAIN", OSSMTP_Plus.SMTPSession.authentication_type.AuthPlain))
                End With
                ddlAuthenticationType.SelectedIndex = 0
            End If
            If Request.Form("btnSendEmail") = "Send Email" Then
                Response.Write("<html><head><title>" & PAGE_TITLE & "</title>")
                Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>")
                Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" & PAGE_TITLE & "</p>")

                oSMTP = New OSSMTP_Plus.SMTPSession
                With oSMTP
                    'connection
                    .Server = Request.Form("txtServer")
                    'authentication
                    .AuthenticationType = Request.Form("ddlAuthenticationType")
                    .Username = Request.Form("txtUsername")
                    .Password = Request.Form("txtPassword")
                    .POPServer = Request.Form("txtPOPServer")
                    .UseSSL = chkSSL.Checked
                    'message
                    .MailFrom = Request.Form("txtMailFrom")
                    .SendTo = Request.Form("txtSendTo")
                    .MessageSubject = Request.Form("txtMessageSubject")
                    .MessageHTML = Request.Form("txtMessageHTML")
                    'EmbeddedObjects
                    If Request.Form("lstEmbeddedObjects") <> "" Then
                        Dim oEmbeddedObject As New OSSMTP_Plus.EmbeddedObject
                        Dim sEmbeddedObjects() As String = Split(Request.Form("lstEmbeddedObjects"), ",")
                        Dim i As Integer = 0
                        For i = 0 To sEmbeddedObjects.Length - 1
                            oEmbeddedObject = Session(sEmbeddedObjects(i))
                            .EmbeddedObjects.Add(oEmbeddedObject)
                        Next
                    End If
                    'send email
                    .SendEmail()
                End With
                While Not bClose
                    System.Threading.Thread.Sleep(10)
                End While
                'cleanup
                If Request.Form("lstEmbeddedObjects") <> "" Then
                    Dim oEmbeddedObject As New OSSMTP_Plus.EmbeddedObject
                    Dim sEmbeddedObjects() As String = Split(Request.Form("lstEmbeddedObjects"), ",")
                    Dim i As Integer = 0
                    For i = 0 To sEmbeddedObjects.Length - 1
                        oEmbeddedObject = Session(sEmbeddedObjects(i))
                        System.IO.File.Delete(oEmbeddedObject.FilePath)
                        Session(sEmbeddedObjects(i)) = Nothing
                    Next
                End If
                oSMTP = Nothing
                Response.Write("<p><a href=" & Me.GetType().BaseType.Name & ".aspx>Return to the form</a></p></body></html>" & vbCrLf)
                Response.End()
            End If
        End Sub

        Private Sub oSMTP_CloseSMTP() Handles oSMTP.CloseSMTP
            bClose = True
        End Sub

        Private Sub oSMTP_ErrorSMTP(ByVal Number As Integer, ByVal Description As String) Handles oSMTP.ErrorSMTP
            Response.Write("Error " & Number & ": " & Description & "<br>" & vbCrLf)
            bClose = True
        End Sub

        Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
            Response.Write(Server.HtmlEncode(Status & vbCrLf).Replace(vbCrLf, "<br>"))
        End Sub

        Protected Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
            Select Case ddlAuthenticationType.SelectedIndex
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                    txtUsername.Enabled = False
                    txtUsername.Text = ""
                    txtPassword.Enabled = False
                    txtPassword.Text = ""
                    txtPOPServer.Enabled = False
                    txtPOPServer.Text = ""
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP
                    txtUsername.Enabled = True
                    txtPassword.Enabled = True
                    txtPOPServer.Enabled = True
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin, OSSMTP_Plus.SMTPSession.authentication_type.AuthPlain
                    txtUsername.Enabled = True
                    txtPassword.Enabled = True
                    txtPOPServer.Enabled = False
                    txtPOPServer.Text = ""
            End Select
        End Sub
    End Class

End Namespace
