using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.IO;

namespace smtp_aspnet_csharp
{
    public partial class frmLoadFromURL : System.Web.UI.Page
    {
        public string PAGE_TITLE = "Load HTML From URL";
        public string sStatus = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                try
                {
                    HttpWebRequest oHttpWebRequest = (HttpWebRequest)WebRequest.Create(Request.Form["txtURL"]);
                    HttpWebResponse oHttpWebResponse = (HttpWebResponse)oHttpWebRequest.GetResponse();
                    Stream oStream = oHttpWebResponse.GetResponseStream();
                    StreamReader oStreamReader = new StreamReader(oStream);
                    string s = "";
                    while (oStreamReader.Peek() > -1)
                        s = s + oStreamReader.ReadLine();

                    oStreamReader.Close();
                    oStream.Close();
                    oHttpWebResponse.Close();

                    s = s.Replace("</script>", "<\\/script>");
                    s = s.Replace("\r\n", "\n");

                    Response.Write("<script language=javascript>");
                    Response.Write("opener.document.all.txtMessageHTML.innerText = '" + EncodeJS(s) + "';");
                    Response.Write("window.close();");
                    Response.Write("</script>");
                    Response.End();
                }
                catch (Exception exUpload)
                {
                    sStatus = "Error: " + exUpload.Message;
                }
            }
        }

        public static string EncodeJS(string s)
        {
            if (s == null || s.Length == 0)
                return "";

            char c;
            int i;
            int len = s.Length;
            System.Text.StringBuilder sb = new System.Text.StringBuilder(len + 4);

            for (i = 0; i < len; i += 1)
            {
                c = s[i];
                if (c == '\'')
                {
                    sb.Append('\\');
                    sb.Append(c);
                }
                else if (c == '\b')
                    sb.Append("\\b");
                else if (c == '\t')
                    sb.Append("\\t");
                else if (c == '\n')
                    sb.Append("\\n");
                else if (c == '\f')
                    sb.Append("\\f");
                else if (c == '\r')
                    sb.Append("\\r");
                else
                    sb.Append(c);
            }
            return sb.ToString();
        }
    }
}
