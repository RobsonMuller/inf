Namespace SMTP

    Partial Class frm5_All
        Inherits System.Web.UI.Page
        Dim WithEvents oSMTP As OSSMTP_Plus.SMTPSession
        Dim bClose As Boolean = False
        Public PAGE_TITLE As String = "Sending email (all properties, collections and methods)"

#Region " Web Form Controls "
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.ID = "frmMain"

        End Sub


        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
            If Not IsPostBack Then PopulateDropDowns()

            If Request.Form("btnSendEmail") <> "" Then
                Response.Write("<html><head><title>" & PAGE_TITLE & "</title>")
                Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>")
                Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" & PAGE_TITLE & "</p>")

                oSMTP = New OSSMTP_Plus.SMTPSession
                With oSMTP
                    'connection
                    .Server = Request.Form("txtServer")
                    If Request.Form("txtPort") <> "" Then .Port = Request.Form("txtPort")
                    If Request.Form("txtClientHostName") <> "" Then .ClientHostName = Request.Form("txtClientHostName")
                    If Request.Form("txtTimeout") <> "" Then .Timeout = Request.Form("txtTimeout")
                    'authentication
                    .AuthenticationType = Request.Form("ddlAuthenticationType")
                    If Request.Form("txtUsername") <> "" Then .Username = Request.Form("txtUsername")
                    If Request.Form("txtPassword") <> "" Then .Password = Request.Form("txtPassword")
                    If Request.Form("txtPOPServer") <> "" Then .POPServer = Request.Form("txtPOPServer")
                    .UseSSL = chkSSL.Checked
                    'sender and extra headers
                    .MailFrom = Request.Form("txtMailFrom")
                    If Request.Form("txtExpiresAfter") <> "" Then .ExpiresAfter = Request.Form("txtExpiresAfter")
                    .Importance = Request.Form("ddlImportance")
                    .Notification = Request.Form("ddlNotification")
                    If Request.Form("txtReplyTo") <> "" Then .ReplyTo = Request.Form("txtReplyTo")
                    .Sensitivity = Request.Form("ddlSensitivity")
                    If Request.Form("txtTimeStamp") <> "" Then .TimeStamp = Request.Form("txtTimeStamp")
                    'custom headers
                    If Request.Form("lstCustomHeaders") <> "" Then
                        Dim oCustomHeader As New OSSMTP_Plus.CustomHeader
                        Dim sCustomHeaders() As String = Split(Request.Form("lstCustomHeaders"), ",")
                        Dim i As Integer = 0
                        For i = 0 To sCustomHeaders.Length - 1
                            oCustomHeader = Session(sCustomHeaders(i))
                            .CustomHeaders.Add(oCustomHeader)
                        Next
                    End If
                    'recipients
                    .SendTo = Request.Form("txtSendTo")
                    If Request.Form("txtBCC") <> "" Then .BCC = Request.Form("txtBCC")
                    If Request.Form("txtCC") <> "" Then .CC = Request.Form("txtCC")
                    'message
                    .MessageSubject = Request.Form("txtMessageSubject")
                    .MessageText = Request.Form("txtMessageText")
                    If Request.Form("txtCharset") <> "" Then .Charset = Request.Form("txtCharset")
                    If Request.Form("txtContentTransferEncoding") <> "" Then .ContentTransferEncoding = Request.Form("txtContentTransferEncoding")
                    If Request.Form("txtContentType") <> "" Then .ContentType = Request.Form("txtContentType")
                    'attachments
                    If Request.Form("lstAttachments") <> "" Then
                        Dim oAttachment As New OSSMTP_Plus.Attachment
                        Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
                        Dim i As Integer = 0
                        For i = 0 To sAttachments.Length - 1
                            oAttachment = Session(sAttachments(i))
                            .Attachments.Add(oAttachment)
                        Next
                    End If
                    'action
                    If Request.Form("btnSendEmail") = "Send Email" Then
                        .SendEmail()
                        While Not bClose
                            System.Threading.Thread.Sleep(10)
                        End While
                    ElseIf Request.Form("btnSendEmail") = "Save To EML File" Then
                        Dim sFile As String = System.Guid.NewGuid.ToString & ".eml"
                        .SaveToEML(Server.MapPath("SavedMessages") & "\" & sFile)
                        Dim oStreamReader As System.IO.StreamReader = System.IO.File.OpenText(Server.MapPath("SavedMessages") & "\" & sFile)
                        Response.Write("<p>Message was saved to <a href=""SavedMessages/" & sFile & """ target=""_blank"">" & sFile & "</a></p>")
                        Response.Write("<p><textarea cols=60 rows=10>" & Replace(oStreamReader.ReadToEnd, "<", "&lt;") & "</textarea></p>")
                        oStreamReader.Close()
                    End If
                End With
                'cleanup
                If Request.Form("lstCustomHeaders") <> "" Then
                    Dim sCustomHeaders() As String = Split(Request.Form("lstCustomHeaders"), ",")
                    Dim i As Integer = 0
                    For i = 0 To sCustomHeaders.Length - 1
                        Session(sCustomHeaders(i)) = Nothing
                    Next
                End If
                If Request.Form("lstAttachments") <> "" Then
                    Dim oAttachment As New OSSMTP_Plus.Attachment
                    Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
                    Dim i As Integer = 0
                    For i = 0 To sAttachments.Length - 1
                        oAttachment = Session(sAttachments(i))
                        System.IO.File.Delete(oAttachment.FilePath)
                        Session(sAttachments(i)) = Nothing
                    Next
                End If
                oSMTP = Nothing
                Response.Write("<p><a href=" & Me.GetType().BaseType.Name & ".aspx>Return to the form</a></p></body></html>" & vbCrLf)
                Response.End()
            End If
        End Sub

        Private Sub oSMTP_CloseSMTP() Handles oSMTP.CloseSMTP
            bClose = True
        End Sub

        Private Sub oSMTP_ErrorSMTP(ByVal Number As Integer, ByVal Description As String) Handles oSMTP.ErrorSMTP
            Response.Write("Error " & Number & ": " & Description & "<br>" & vbCrLf)
            bClose = True
        End Sub

        Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
            Response.Write(Status.Replace("<", "&lt;").Replace(">", "&gt;").Replace("<", "&lt;").Replace(">", "&gt;") & "<br>" & vbCrLf)
        End Sub

        Protected Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
            Select Case ddlAuthenticationType.SelectedIndex
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                    txtUsername.Enabled = False
                    txtUsername.Text = ""
                    txtPassword.Enabled = False
                    txtPassword.Text = ""
                    txtPOPServer.Enabled = False
                    txtPOPServer.Text = ""
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP
                    txtUsername.Enabled = True
                    txtPassword.Enabled = True
                    txtPOPServer.Enabled = True
                Case OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin, OSSMTP_Plus.SMTPSession.authentication_type.AuthPlain
                    txtUsername.Enabled = True
                    txtPassword.Enabled = True
                    txtPOPServer.Enabled = False
                    txtPOPServer.Text = ""
            End Select
        End Sub

        Private Sub PopulateDropDowns()
            With ddlAuthenticationType.Items
                .Add(New ListItem("None", OSSMTP_Plus.SMTPSession.authentication_type.AuthNone))
                .Add(New ListItem("POP3", OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP))
                .Add(New ListItem("AUTH LOGIN", OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin))
                .Add(New ListItem("AUTH PLAIN", OSSMTP_Plus.SMTPSession.authentication_type.AuthPlain))
            End With
            ddlAuthenticationType.SelectedIndex = 0

            With ddlImportance.Items
                .Add(New ListItem("Normal", OSSMTP_Plus.SMTPSession.importance_level.ImportanceNormal))
                .Add(New ListItem("Low", OSSMTP_Plus.SMTPSession.importance_level.ImportanceLow))
                .Add(New ListItem("High", OSSMTP_Plus.SMTPSession.importance_level.ImportanceHigh))
            End With
            ddlImportance.SelectedIndex = 0

            With ddlNotification.Items
                .Add(New ListItem("None", OSSMTP_Plus.SMTPSession.notification_type.NotificationNone))
                .Add(New ListItem("On Delivery", OSSMTP_Plus.SMTPSession.notification_type.NotificationDelivery))
                .Add(New ListItem("On Read", OSSMTP_Plus.SMTPSession.notification_type.NotificationRead))
                .Add(New ListItem("On Delivery And Read", OSSMTP_Plus.SMTPSession.notification_type.NotificationDeliveryAndRead))
            End With
            ddlNotification.SelectedIndex = 0

            With ddlSensitivity.Items
                .Add(New ListItem("Normal", OSSMTP_Plus.SMTPSession.sensitivity_level.SensitivityNormal))
                .Add(New ListItem("Personal", OSSMTP_Plus.SMTPSession.sensitivity_level.SensitivityPersonal))
                .Add(New ListItem("Private", OSSMTP_Plus.SMTPSession.sensitivity_level.SensitivityPrivate))
                .Add(New ListItem("Confidential", OSSMTP_Plus.SMTPSession.sensitivity_level.SensitivityConfidential))
            End With
            ddlSensitivity.SelectedIndex = 0
        End Sub

        Private Sub oSMTP_MessageSaved() Handles oSMTP.MessageSaved

        End Sub
    End Class

End Namespace
