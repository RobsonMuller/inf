using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OSSMTP_Plus;

namespace smtp_aspnet_csharp
{
    public partial class frmDelEmbeddedObject : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = "";
            try
            {
                s = Request.QueryString["s"];
            }
            catch (Exception ex) { }

            Response.Write("<script language=javascript>");
            if (s != "")
            {
                EmbeddedObject oEmbeddedObject = new EmbeddedObject();
                oEmbeddedObject = (EmbeddedObject)Session[s];
                System.IO.File.Delete(oEmbeddedObject.FilePath);
                Session[s] = null;

                Response.Write("var ddl = window.opener.document.all.lstEmbeddedObjects;");
                Response.Write("ddl.options.remove(ddl.selectedIndex);");
                Response.Write("window.opener.document.all.btnRefresh.click();");
            }
            Response.Write("window.close();");
            Response.Write("</script>");
            Response.End();
        }
    }
}
