using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using OSSMTP_Plus;

namespace smtp_csharp
{
    public class frm4_Headers : System.Windows.Forms.Form
    {
        private SMTPSession oSMTP = new SMTPSession();
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox txtPOPServer;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox txtPassword;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox txtUsername;
        internal System.Windows.Forms.ComboBox ddlAuthenticationType;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox txtStatus;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtServer;
        internal System.Windows.Forms.Button btnSendEmail;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button btnDelAttachment;
        internal System.Windows.Forms.Button btnAddAttachment;
        internal System.Windows.Forms.ListBox lstAttachments;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtMessageText;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtMessageSubject;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox txtCharset;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.TextBox txtContentType;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.TextBox txtContentTransferEncoding;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtSendTo;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.TextBox txtCC;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox txtBCC;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.Button btnDelCustomHeader;
        internal System.Windows.Forms.Button btnAddCustomHeader;
        internal System.Windows.Forms.ListBox lstCustomHeaders;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox txtTimeStamp;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtMailFrom;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.ComboBox ddlNotification;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.ComboBox ddlImportance;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.TextBox txtReplyTo;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox txtExpiresAfter;
        internal System.Windows.Forms.ComboBox ddlSensitivity;
        private CheckBox chkSSL;

        private System.ComponentModel.Container components = null;

        public frm4_Headers()
        {
            InitializeComponent();

            this.oSMTP = new SMTPSession();
            oSMTP.StatusChanged += new SMTPSession.StatusChangedHandler(oSMTP_StatusChanged);
            oSMTP.ConnectSMTP += new SMTPSession.ConnectSMTPHandler(oSMTP_ConnectSMTP);
            oSMTP.ErrorSMTP += new SMTPSession.ErrorSMTPHandler(oSMTP_ErrorSMTP);
            oSMTP.SendSMTP += new SMTPSession.SendSMTPHandler(oSMTP_SendSMTP);
            oSMTP.CloseSMTP += new SMTPSession.CloseSMTPHandler(oSMTP_CloseSMTP);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.txtPOPServer = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.ddlAuthenticationType = new System.Windows.Forms.ComboBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelAttachment = new System.Windows.Forms.Button();
            this.btnAddAttachment = new System.Windows.Forms.Button();
            this.lstAttachments = new System.Windows.Forms.ListBox();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtMessageText = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtMessageSubject = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.txtCharset = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.txtContentType = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.txtContentTransferEncoding = new System.Windows.Forms.TextBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtSendTo = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.txtCC = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtBCC = new System.Windows.Forms.TextBox();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.btnDelCustomHeader = new System.Windows.Forms.Button();
            this.btnAddCustomHeader = new System.Windows.Forms.Button();
            this.lstCustomHeaders = new System.Windows.Forms.ListBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.txtTimeStamp = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtMailFrom = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.ddlNotification = new System.Windows.Forms.ComboBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.ddlImportance = new System.Windows.Forms.ComboBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.txtReplyTo = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtExpiresAfter = new System.Windows.Forms.TextBox();
            this.ddlSensitivity = new System.Windows.Forms.ComboBox();
            this.chkSSL = new System.Windows.Forms.CheckBox();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.Label10);
            this.GroupBox1.Controls.Add(this.Label7);
            this.GroupBox1.Controls.Add(this.txtPOPServer);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Controls.Add(this.txtPassword);
            this.GroupBox1.Controls.Add(this.Label9);
            this.GroupBox1.Controls.Add(this.txtUsername);
            this.GroupBox1.Controls.Add(this.ddlAuthenticationType);
            this.GroupBox1.Location = new System.Drawing.Point(8, 30);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(288, 116);
            this.GroupBox1.TabIndex = 1;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Authentication settings";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(59, 18);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(31, 13);
            this.Label10.TabIndex = 14;
            this.Label10.Text = "Type";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(17, 88);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(69, 13);
            this.Label7.TabIndex = 13;
            this.Label7.Text = "POP3 Server";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtPOPServer
            // 
            this.txtPOPServer.Location = new System.Drawing.Point(96, 88);
            this.txtPOPServer.Name = "txtPOPServer";
            this.txtPOPServer.Size = new System.Drawing.Size(184, 20);
            this.txtPOPServer.TabIndex = 4;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(34, 64);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(53, 13);
            this.Label8.TabIndex = 11;
            this.Label8.Text = "Password";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(96, 64);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(184, 20);
            this.txtPassword.TabIndex = 3;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(32, 40);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(55, 13);
            this.Label9.TabIndex = 9;
            this.Label9.Text = "Username";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(96, 40);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(184, 20);
            this.txtUsername.TabIndex = 2;
            // 
            // ddlAuthenticationType
            // 
            this.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAuthenticationType.Location = new System.Drawing.Point(96, 16);
            this.ddlAuthenticationType.Name = "ddlAuthenticationType";
            this.ddlAuthenticationType.Size = new System.Drawing.Size(184, 21);
            this.ddlAuthenticationType.TabIndex = 1;
            this.ddlAuthenticationType.SelectedIndexChanged += new System.EventHandler(this.ddlAuthenticationType_SelectedIndexChanged);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(16, 512);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(37, 13);
            this.Label6.TabIndex = 26;
            this.Label6.Text = "Status";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(8, 528);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtStatus.Size = new System.Drawing.Size(584, 168);
            this.txtStatus.TabIndex = 28;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(56, 6);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(38, 13);
            this.Label1.TabIndex = 15;
            this.Label1.Text = "Server";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(104, 6);
            this.txtServer.Name = "txtServer";
            this.txtServer.Size = new System.Drawing.Size(184, 20);
            this.txtServer.TabIndex = 0;
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Location = new System.Drawing.Point(264, 496);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(75, 23);
            this.btnSendEmail.TabIndex = 27;
            this.btnSendEmail.Text = "Send Email";
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.btnDelAttachment);
            this.GroupBox2.Controls.Add(this.btnAddAttachment);
            this.GroupBox2.Controls.Add(this.lstAttachments);
            this.GroupBox2.Location = new System.Drawing.Point(304, 344);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(288, 136);
            this.GroupBox2.TabIndex = 6;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Attachments";
            // 
            // btnDelAttachment
            // 
            this.btnDelAttachment.Location = new System.Drawing.Point(152, 104);
            this.btnDelAttachment.Name = "btnDelAttachment";
            this.btnDelAttachment.Size = new System.Drawing.Size(75, 23);
            this.btnDelAttachment.TabIndex = 25;
            this.btnDelAttachment.Text = "Delete";
            this.btnDelAttachment.Click += new System.EventHandler(this.btnDelAttachment_Click);
            // 
            // btnAddAttachment
            // 
            this.btnAddAttachment.Location = new System.Drawing.Point(64, 104);
            this.btnAddAttachment.Name = "btnAddAttachment";
            this.btnAddAttachment.Size = new System.Drawing.Size(75, 23);
            this.btnAddAttachment.TabIndex = 24;
            this.btnAddAttachment.Text = "Add";
            this.btnAddAttachment.Click += new System.EventHandler(this.btnAddAttachment_Click);
            // 
            // lstAttachments
            // 
            this.lstAttachments.HorizontalScrollbar = true;
            this.lstAttachments.Location = new System.Drawing.Point(8, 16);
            this.lstAttachments.Name = "lstAttachments";
            this.lstAttachments.Size = new System.Drawing.Size(272, 82);
            this.lstAttachments.TabIndex = 23;
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.Label5);
            this.GroupBox6.Controls.Add(this.txtMessageText);
            this.GroupBox6.Controls.Add(this.Label4);
            this.GroupBox6.Controls.Add(this.txtMessageSubject);
            this.GroupBox6.Controls.Add(this.Label12);
            this.GroupBox6.Controls.Add(this.txtCharset);
            this.GroupBox6.Controls.Add(this.Label20);
            this.GroupBox6.Controls.Add(this.txtContentType);
            this.GroupBox6.Controls.Add(this.Label21);
            this.GroupBox6.Controls.Add(this.txtContentTransferEncoding);
            this.GroupBox6.Location = new System.Drawing.Point(304, 112);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(288, 224);
            this.GroupBox6.TabIndex = 5;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Message";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(16, 40);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(74, 13);
            this.Label5.TabIndex = 19;
            this.Label5.Text = "Message Text";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageText
            // 
            this.txtMessageText.Location = new System.Drawing.Point(96, 40);
            this.txtMessageText.Multiline = true;
            this.txtMessageText.Name = "txtMessageText";
            this.txtMessageText.Size = new System.Drawing.Size(184, 96);
            this.txtMessageText.TabIndex = 16;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(0, 16);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(89, 13);
            this.Label4.TabIndex = 17;
            this.Label4.Text = "Message Subject";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageSubject
            // 
            this.txtMessageSubject.Location = new System.Drawing.Point(96, 16);
            this.txtMessageSubject.Name = "txtMessageSubject";
            this.txtMessageSubject.Size = new System.Drawing.Size(184, 20);
            this.txtMessageSubject.TabIndex = 15;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(48, 144);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(43, 13);
            this.Label12.TabIndex = 15;
            this.Label12.Text = "Charset";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtCharset
            // 
            this.txtCharset.Location = new System.Drawing.Point(96, 144);
            this.txtCharset.Name = "txtCharset";
            this.txtCharset.Size = new System.Drawing.Size(184, 20);
            this.txtCharset.TabIndex = 17;
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Location = new System.Drawing.Point(16, 192);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(71, 13);
            this.Label20.TabIndex = 13;
            this.Label20.Text = "Content Type";
            this.Label20.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtContentType
            // 
            this.txtContentType.Location = new System.Drawing.Point(96, 192);
            this.txtContentType.Name = "txtContentType";
            this.txtContentType.Size = new System.Drawing.Size(184, 20);
            this.txtContentType.TabIndex = 19;
            // 
            // Label21
            // 
            this.Label21.Location = new System.Drawing.Point(0, 168);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(96, 24);
            this.Label21.TabIndex = 11;
            this.Label21.Text = "Content Transfer Encoding";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtContentTransferEncoding
            // 
            this.txtContentTransferEncoding.Location = new System.Drawing.Point(96, 168);
            this.txtContentTransferEncoding.Name = "txtContentTransferEncoding";
            this.txtContentTransferEncoding.Size = new System.Drawing.Size(184, 20);
            this.txtContentTransferEncoding.TabIndex = 18;
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.Label3);
            this.GroupBox5.Controls.Add(this.txtSendTo);
            this.GroupBox5.Controls.Add(this.Label18);
            this.GroupBox5.Controls.Add(this.txtCC);
            this.GroupBox5.Controls.Add(this.Label19);
            this.GroupBox5.Controls.Add(this.txtBCC);
            this.GroupBox5.Location = new System.Drawing.Point(304, 8);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(288, 96);
            this.GroupBox5.TabIndex = 4;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Recipients";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(40, 16);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(48, 13);
            this.Label3.TabIndex = 15;
            this.Label3.Text = "Send To";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtSendTo
            // 
            this.txtSendTo.Location = new System.Drawing.Point(96, 16);
            this.txtSendTo.Name = "txtSendTo";
            this.txtSendTo.Size = new System.Drawing.Size(184, 20);
            this.txtSendTo.TabIndex = 12;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(66, 64);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(21, 13);
            this.Label18.TabIndex = 13;
            this.Label18.Text = "CC";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtCC
            // 
            this.txtCC.Location = new System.Drawing.Point(96, 64);
            this.txtCC.Name = "txtCC";
            this.txtCC.Size = new System.Drawing.Size(184, 20);
            this.txtCC.TabIndex = 14;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(59, 40);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(28, 13);
            this.Label19.TabIndex = 11;
            this.Label19.Text = "BCC";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtBCC
            // 
            this.txtBCC.Location = new System.Drawing.Point(96, 40);
            this.txtBCC.Name = "txtBCC";
            this.txtBCC.Size = new System.Drawing.Size(184, 20);
            this.txtBCC.TabIndex = 13;
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.btnDelCustomHeader);
            this.GroupBox4.Controls.Add(this.btnAddCustomHeader);
            this.GroupBox4.Controls.Add(this.lstCustomHeaders);
            this.GroupBox4.Location = new System.Drawing.Point(8, 344);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(288, 136);
            this.GroupBox4.TabIndex = 3;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Custom Headers";
            // 
            // btnDelCustomHeader
            // 
            this.btnDelCustomHeader.Location = new System.Drawing.Point(152, 104);
            this.btnDelCustomHeader.Name = "btnDelCustomHeader";
            this.btnDelCustomHeader.Size = new System.Drawing.Size(75, 23);
            this.btnDelCustomHeader.TabIndex = 22;
            this.btnDelCustomHeader.Text = "Delete";
            this.btnDelCustomHeader.Click += new System.EventHandler(this.btnDelCustomHeader_Click);
            // 
            // btnAddCustomHeader
            // 
            this.btnAddCustomHeader.Location = new System.Drawing.Point(64, 104);
            this.btnAddCustomHeader.Name = "btnAddCustomHeader";
            this.btnAddCustomHeader.Size = new System.Drawing.Size(75, 23);
            this.btnAddCustomHeader.TabIndex = 21;
            this.btnAddCustomHeader.Text = "Add";
            this.btnAddCustomHeader.Click += new System.EventHandler(this.btnAddCustomHeader_Click);
            // 
            // lstCustomHeaders
            // 
            this.lstCustomHeaders.HorizontalScrollbar = true;
            this.lstCustomHeaders.Location = new System.Drawing.Point(8, 16);
            this.lstCustomHeaders.Name = "lstCustomHeaders";
            this.lstCustomHeaders.Size = new System.Drawing.Size(272, 82);
            this.lstCustomHeaders.TabIndex = 20;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.Label17);
            this.GroupBox3.Controls.Add(this.txtTimeStamp);
            this.GroupBox3.Controls.Add(this.Label2);
            this.GroupBox3.Controls.Add(this.txtMailFrom);
            this.GroupBox3.Controls.Add(this.Label16);
            this.GroupBox3.Controls.Add(this.ddlNotification);
            this.GroupBox3.Controls.Add(this.Label15);
            this.GroupBox3.Controls.Add(this.ddlImportance);
            this.GroupBox3.Controls.Add(this.Label11);
            this.GroupBox3.Controls.Add(this.Label13);
            this.GroupBox3.Controls.Add(this.txtReplyTo);
            this.GroupBox3.Controls.Add(this.Label14);
            this.GroupBox3.Controls.Add(this.txtExpiresAfter);
            this.GroupBox3.Controls.Add(this.ddlSensitivity);
            this.GroupBox3.Location = new System.Drawing.Point(8, 152);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(288, 184);
            this.GroupBox3.TabIndex = 2;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Sender and extra headers";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(25, 160);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(60, 13);
            this.Label17.TabIndex = 22;
            this.Label17.Text = "TimeStamp";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtTimeStamp
            // 
            this.txtTimeStamp.Location = new System.Drawing.Point(96, 160);
            this.txtTimeStamp.Name = "txtTimeStamp";
            this.txtTimeStamp.Size = new System.Drawing.Size(184, 20);
            this.txtTimeStamp.TabIndex = 11;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(32, 16);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(52, 13);
            this.Label2.TabIndex = 20;
            this.Label2.Text = "Mail From";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMailFrom
            // 
            this.txtMailFrom.Location = new System.Drawing.Point(96, 16);
            this.txtMailFrom.Name = "txtMailFrom";
            this.txtMailFrom.Size = new System.Drawing.Size(184, 20);
            this.txtMailFrom.TabIndex = 5;
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(27, 88);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(60, 13);
            this.Label16.TabIndex = 18;
            this.Label16.Text = "Notification";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // ddlNotification
            // 
            this.ddlNotification.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlNotification.Location = new System.Drawing.Point(96, 88);
            this.ddlNotification.Name = "ddlNotification";
            this.ddlNotification.Size = new System.Drawing.Size(184, 21);
            this.ddlNotification.TabIndex = 8;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(26, 64);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(60, 13);
            this.Label15.TabIndex = 16;
            this.Label15.Text = "Importance";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // ddlImportance
            // 
            this.ddlImportance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlImportance.Location = new System.Drawing.Point(96, 64);
            this.ddlImportance.Name = "ddlImportance";
            this.ddlImportance.Size = new System.Drawing.Size(184, 21);
            this.ddlImportance.TabIndex = 7;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(32, 136);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(54, 13);
            this.Label11.TabIndex = 14;
            this.Label11.Text = "Sensitivity";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(38, 112);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(50, 13);
            this.Label13.TabIndex = 11;
            this.Label13.Text = "Reply To";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtReplyTo
            // 
            this.txtReplyTo.Location = new System.Drawing.Point(96, 112);
            this.txtReplyTo.Name = "txtReplyTo";
            this.txtReplyTo.Size = new System.Drawing.Size(184, 20);
            this.txtReplyTo.TabIndex = 9;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(18, 40);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(66, 13);
            this.Label14.TabIndex = 9;
            this.Label14.Text = "Expires After";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtExpiresAfter
            // 
            this.txtExpiresAfter.Location = new System.Drawing.Point(96, 40);
            this.txtExpiresAfter.Name = "txtExpiresAfter";
            this.txtExpiresAfter.Size = new System.Drawing.Size(184, 20);
            this.txtExpiresAfter.TabIndex = 6;
            // 
            // ddlSensitivity
            // 
            this.ddlSensitivity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSensitivity.Location = new System.Drawing.Point(96, 136);
            this.ddlSensitivity.Name = "ddlSensitivity";
            this.ddlSensitivity.Size = new System.Drawing.Size(184, 21);
            this.ddlSensitivity.TabIndex = 10;
            // 
            // chkSSL
            // 
            this.chkSSL.AutoSize = true;
            this.chkSSL.Location = new System.Drawing.Point(8, 486);
            this.chkSSL.Name = "chkSSL";
            this.chkSSL.Size = new System.Drawing.Size(128, 17);
            this.chkSSL.TabIndex = 26;
            this.chkSSL.Text = "Use secure SSL/TLS";
            this.chkSSL.UseVisualStyleBackColor = true;
            // 
            // frm4_Headers
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(600, 701);
            this.Controls.Add(this.chkSSL);
            this.Controls.Add(this.GroupBox6);
            this.Controls.Add(this.GroupBox5);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtServer);
            this.Controls.Add(this.btnSendEmail);
            this.Name = "frm4_Headers";
            this.Text = "Sending email (with extra headers and additional recipients)";
            this.Load += new System.EventHandler(this.frm4_Headers_Load);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        [STAThread]
        static void Main()
        {
            Application.Run(new frm4_Headers());
        }

        private void btnSendEmail_Click(object sender, System.EventArgs e)
        {
            txtStatus.Text = "";

            //connection
            oSMTP.Server = txtServer.Text;
            //authentication
            oSMTP.AuthenticationType = (OSSMTP_Plus.SMTPSession.authentication_type)ddlAuthenticationType.SelectedIndex;
            if (txtUsername.Text != "")
                oSMTP.Username = txtUsername.Text;
            if (txtPassword.Text != "")
                oSMTP.Password = txtPassword.Text;
            if (txtPOPServer.Text != "")
                oSMTP.POPServer = txtPOPServer.Text;
            oSMTP.UseSSL = chkSSL.Checked;
            //sender and extra headers
            oSMTP.MailFrom = txtMailFrom.Text;
            if (txtExpiresAfter.Text != "")
                oSMTP.ExpiresAfter = txtExpiresAfter.Text;
            oSMTP.Importance = (SMTPSession.importance_level)ddlImportance.SelectedIndex;
            oSMTP.Notification = (SMTPSession.notification_type)ddlNotification.SelectedIndex;
            if (txtReplyTo.Text != "")
                oSMTP.ReplyTo = txtReplyTo.Text;
            oSMTP.Sensitivity = (SMTPSession.sensitivity_level)ddlSensitivity.SelectedIndex;
            if (txtTimeStamp.Text != "")
                oSMTP.TimeStamp = txtTimeStamp.Text;
            //custom headers
            string _customHeader = "";
            for (int i = 0; i < lstCustomHeaders.Items.Count; i++)
            {
                _customHeader = lstCustomHeaders.Items[i].ToString();
                oSMTP.CustomHeaders.Add(new OSSMTP_Plus.CustomHeader(_customHeader));
            }
            //recipients
            oSMTP.SendTo = txtSendTo.Text;
            if (txtBCC.Text != "")
                oSMTP.BCC = txtBCC.Text;
            if (txtCC.Text != "")
                oSMTP.CC = txtCC.Text;
            //message
            oSMTP.MessageSubject = txtMessageSubject.Text;
            oSMTP.MessageText = txtMessageText.Text;
            if (txtCharset.Text != "")
                oSMTP.Charset = txtCharset.Text;
            if (txtContentTransferEncoding.Text != "")
                oSMTP.ContentTransferEncoding = txtContentTransferEncoding.Text;
            if (txtContentType.Text != "")
                oSMTP.ContentType = txtContentType.Text;
            //attachments
            string _filePath = "";
            for (int i = 0; i < lstAttachments.Items.Count; i++)
            {
                _filePath = lstAttachments.Items[i].ToString();
                oSMTP.Attachments.Add(new OSSMTP_Plus.Attachment(_filePath));
            }
            //send email
            oSMTP.SendEmail();
        }

        private void oSMTP_ErrorSMTP(int number, string description)
        {
            txtStatus.Text = txtStatus.Text + "Error " + number + ": " + description + "\r\n";
        }

        private void oSMTP_StatusChanged(string status)
        {
            txtStatus.Text = txtStatus.Text + status + "\r\n";
        }

        static void oSMTP_ConnectSMTP()
        {
        }

        static void oSMTP_SendSMTP()
        {
        }

        static void oSMTP_CloseSMTP()
        {
        }

        private void frm4_Headers_Load(object sender, System.EventArgs e)
        {
            ddlAuthenticationType.Items.Add("None");
            ddlAuthenticationType.Items.Add("POP3");
            ddlAuthenticationType.Items.Add("AUTH LOGIN");
            ddlAuthenticationType.Items.Add("AUTH PLAIN");
            ddlAuthenticationType.SelectedIndex = 0;

            ddlImportance.Items.Add("Normal");
            ddlImportance.Items.Add("Low");
            ddlImportance.Items.Add("High");
            ddlImportance.SelectedIndex = 0;

            ddlNotification.Items.Add("None");
            ddlNotification.Items.Add("On Delivery");
            ddlNotification.Items.Add("On Read");
            ddlNotification.Items.Add("On Delivery And Read");
            ddlNotification.SelectedIndex = 0;

            ddlSensitivity.Items.Add("Normal");
            ddlSensitivity.Items.Add("Personal");
            ddlSensitivity.Items.Add("Private");
            ddlSensitivity.Items.Add("Confidential");
            ddlSensitivity.SelectedIndex = 0;
        }

        private void ddlAuthenticationType_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            switch (ddlAuthenticationType.SelectedIndex)
            {
                case (int)SMTPSession.authentication_type.AuthNone:
                    txtUsername.Enabled = false;
                    txtUsername.Text = "";
                    txtPassword.Enabled = false;
                    txtPassword.Text = "";
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
                case (int)SMTPSession.authentication_type.AuthPOP:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = true;
                    break;
                case (int)SMTPSession.authentication_type.AuthLogin:
                case (int)SMTPSession.authentication_type.AuthPlain:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
            }
        }

        private void btnAddAttachment_Click(object sender, System.EventArgs e)
        {
            frmAddAttachment frm = new frmAddAttachment();
            frm.ShowDialog(this);
            if (frm.txtFile.Text.Trim() != "")
                lstAttachments.Items.Add(frm.txtFile.Text);
            frm.Dispose();
        }

        private void btnDelAttachment_Click(object sender, System.EventArgs e)
        {
            if (lstAttachments.SelectedIndex > -1)
                lstAttachments.Items.RemoveAt(lstAttachments.SelectedIndex);
        }

        private void btnAddCustomHeader_Click(object sender, System.EventArgs e)
        {
            frmAddCustomHeader frm = new frmAddCustomHeader();
            frm.ShowDialog(this);
            if (frm.txtHeaderName.Text.Trim() != "")
                lstCustomHeaders.Items.Add(frm.txtHeaderName.Text + ": " + frm.txtHeaderValue.Text);
            frm.Dispose();
        }

        private void btnDelCustomHeader_Click(object sender, System.EventArgs e)
        {
            if (lstCustomHeaders.SelectedIndex > -1)
                lstCustomHeaders.Items.RemoveAt(lstCustomHeaders.SelectedIndex);
        }
    }
}