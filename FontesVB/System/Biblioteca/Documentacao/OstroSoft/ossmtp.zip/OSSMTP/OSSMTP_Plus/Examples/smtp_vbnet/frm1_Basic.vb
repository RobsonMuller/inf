Public Class frm1_Basic
    Dim WithEvents oSMTP As OSSMTP_Plus.SMTPSession

    Private Sub btnSendEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        txtStatus.Text = ""
        With oSMTP
            'connection
            .Server = txtServer.Text
            'message
            .MailFrom = txtMailFrom.Text
            .SendTo = txtSendTo.Text
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            'send email
            .SendEmail()
        End With
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Integer, ByVal Description As String) Handles oSMTP.ErrorSMTP
        txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        txtStatus.Text = txtStatus.Text & Status & vbCrLf
    End Sub

    Private Sub frm1_Basic_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        oSMTP = New OSSMTP_Plus.SMTPSession
    End Sub

    Private Sub frm1_Basic_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        oSMTP = Nothing
    End Sub
End Class
