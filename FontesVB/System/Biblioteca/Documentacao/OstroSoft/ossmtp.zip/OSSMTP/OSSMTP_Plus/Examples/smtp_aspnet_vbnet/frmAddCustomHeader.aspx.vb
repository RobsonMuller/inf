Namespace SMTP

    Partial Class frmAddCustomHeader
        Inherits System.Web.UI.Page
        Public sStatus As String = ""
        Public PAGE_TITLE As String = "Add Custom Header"

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs)
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Protected Sub btnAdd_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
            Dim oCustomHeader As New OSSMTP_Plus.CustomHeader
            Dim sGUID As String = ""
            Dim sFile As String = ""

            If txtHeaderName.Value = "" Then
                sStatus = "Enter Header Name"
            ElseIf txtHeaderValue.Value = "" Then
                sStatus = "Enter Header Value"
            Else
                Try
                    sGUID = System.Guid.NewGuid.ToString
                    oCustomHeader.HeaderName = txtHeaderName.Value
                    oCustomHeader.HeaderValue = txtHeaderValue.Value

                    Session(sGUID) = oCustomHeader
                    Response.Write("<script language=javascript>")
                    Response.Write("var ddl = window.opener.document.all.lstCustomHeaders;")
                    Response.Write("var opt = window.opener.document.createElement('option');")
                    Response.Write("ddl.options.add(opt);")
                    Response.Write("opt.innerText = '" & oCustomHeader.HeaderName & ": " & oCustomHeader.HeaderValue & "';")
                    Response.Write("opt.value = '" & sGUID & "';")
                    Response.Write("ddl.selectedIndex = ddl.options.length - 1;")
                    Response.Write("window.close();")
                    Response.Write("</script>")
                    Response.End()
                Catch exUpload As Exception
                    sStatus = "Error: " & exUpload.Message
                End Try
            End If
        End Sub
    End Class

End Namespace
