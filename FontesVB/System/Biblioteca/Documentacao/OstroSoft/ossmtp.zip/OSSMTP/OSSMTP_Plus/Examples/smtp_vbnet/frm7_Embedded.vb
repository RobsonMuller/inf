Public Class frm7_Embedded
    Dim WithEvents oSMTP As OSSMTP_Plus.SMTPSession

    Private Sub btnSendEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        txtStatus.Text = ""
        With oSMTP
            'connection
            .Server = txtServer.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedIndex
            If txtUsername.Text <> "" Then .Username = txtUsername.Text
            If txtPassword.Text <> "" Then .Password = txtPassword.Text
            If txtPOPServer.Text <> "" Then .POPServer = txtPOPServer.Text
            .UseSSL = chkSSL.Checked
            'message
            .MailFrom = txtMailFrom.Text
            .SendTo = txtSendTo.Text
            .MessageSubject = txtMessageSubject.Text
            .MessageHTML = txtMessageHTML.Text
            'EmbeddedObjects
            Dim _filePath As String = ""
            Dim i As Integer = 0
            For i = 0 To lstEmbeddedObjects.Items.Count - 1
                _filePath = lstEmbeddedObjects.Items(i)
                .EmbeddedObjects.Add(New OSSMTP_Plus.EmbeddedObject("image" + i.ToString(), _filePath))
            Next
            'send email
            .SendEmail()
        End With
        oSMTP = Nothing
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP_Plus.SMTPSession.authentication_type.AuthLogin, OSSMTP_Plus.SMTPSession.authentication_type.AuthNone
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Integer, ByVal Description As String) Handles oSMTP.ErrorSMTP
        txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        txtStatus.Text = txtStatus.Text & Status & vbCrLf
    End Sub

    Private Sub frm1_Basic_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        oSMTP = New OSSMTP_Plus.SMTPSession
        With ddlAuthenticationType.Items
            .Add("None")
            .Add("POP3")
            .Add("AUTH LOGIN")
            .Add("AUTH PLAIN")
        End With
        ddlAuthenticationType.SelectedIndex = 0
    End Sub

    Private Sub frm1_Basic_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        oSMTP = Nothing
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim frm As New frmAddAttachment
        frm.Text = "Add Embedded Object"
        frm.ShowDialog(Me)
        If Trim(frm.txtFile.Text) <> "" Then lstEmbeddedObjects.Items.Add(frm.txtFile.Text)
        frm.Dispose()
        GenerateHTML()
    End Sub

    Private Sub btnDel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDel.Click
        If lstEmbeddedObjects.SelectedIndex > -1 Then lstEmbeddedObjects.Items.RemoveAt(lstEmbeddedObjects.SelectedIndex)
        GenerateHTML()
    End Sub

    Private Sub GenerateHTML()
        txtMessageHTML.Text = "<html><body>" + "embedded image test<br>" & vbCrLf
        Dim _filePath As String = ""
        Dim i As Integer = 0
        For i = 0 To lstEmbeddedObjects.Items.Count - 1
            _filePath = lstEmbeddedObjects.Items(i)
            _filePath = _filePath.Substring(_filePath.LastIndexOf("\") + 1)
            txtMessageHTML.Text += "<p>" + _filePath + "<br>" & vbCrLf
            txtMessageHTML.Text += "<img src=""cid:image" + i.ToString() + """></p>" & vbCrLf
        Next
        txtMessageHTML.Text += "</body></html>"
    End Sub
End Class
