Partial Class frm7_EmbeddedObjects
    Inherits System.Web.UI.Page
    Dim WithEvents oSMTP As OSSMTP.SMTPSession
    Dim bClose As Boolean = False
    Public PAGE_TITLE As String = "Sending email (with HTML and embedded objects)"

#Region " Web Form Controls "


#End Region

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ID = "frmMain"

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            With ddlAuthenticationType.Items
                .Add(New ListItem("None", OSSMTP.authentication_type.AuthNone))
                .Add(New ListItem("POP3", OSSMTP.authentication_type.AuthPOP))
                .Add(New ListItem("AUTH LOGIN", OSSMTP.authentication_type.AuthLogin))
                .Add(New ListItem("AUTH PLAIN", OSSMTP.authentication_type.AuthPlain))
                .Add(New ListItem("NTLM", OSSMTP.authentication_type.AuthNTLM))
            End With
            ddlAuthenticationType.SelectedIndex = 0
        End If
    End Sub

    Protected Sub btnSendEmail_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSendEmail.Click
        Response.Write("<html><head><title>" & PAGE_TITLE & "</title>")
        Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>")
        Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" & PAGE_TITLE & "</p>")
        oSMTP = New OSSMTP.SMTPSession
        With oSMTP
            'connection
            .Server = txtServer.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedValue
            .Username = txtUsername.Text
            .Password = txtPassword.Text
            .POPServer = txtPOPServer.Text
            .UseSSL = chkUseSSL.Checked
            'message
            .MailFrom = txtMailFrom.Text
            .SendTo = txtSendTo.Text
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            .MessageHTML = txtMessageHTML.Text
            'Embedded Objects
            If Request.Form("lstAttachments") <> "" Then
                Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
                Dim i As Integer = 0
                For i = 0 To sAttachments.Length - 1
                    .EmbeddedObjects.Add(Session(sAttachments(i)))
                Next
            End If
            'send email
            .SendEmail()
        End With
        While Not bClose
            System.Threading.Thread.Sleep(10)
        End While
        'cleanup
        If Request.Form("lstAttachments") <> "" Then
            Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
            Dim i As Integer = 0
            For i = 0 To sAttachments.Length - 1
                System.IO.File.Delete(Session(sAttachments(i)))
            Next
        End If
        oSMTP = Nothing
        Response.Write("<p><a href=" & Me.GetType().BaseType.Name & ".aspx>Return to the form</a></p></body></html>" & vbCrLf)
        Response.End()
    End Sub

    Private Sub oSMTP_CloseSMTP() Handles oSMTP.CloseSMTP
        bClose = True
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Short, ByRef Description As String) Handles oSMTP.ErrorSMTP
        Response.Write("Error " & Number & ": " & Description & "<br>" & vbCrLf)
        bClose = True
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        Response.Write(oSMTP.Status & "<br>" & vbCrLf)
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthNTLM
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub
End Class
