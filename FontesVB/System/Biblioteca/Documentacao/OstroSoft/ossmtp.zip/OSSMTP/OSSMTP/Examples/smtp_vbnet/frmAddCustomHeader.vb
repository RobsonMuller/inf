Public Class frmAddCustomHeader
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents Label18 As System.Windows.Forms.Label
  Friend WithEvents Label19 As System.Windows.Forms.Label
  Friend WithEvents txtHeaderValue As System.Windows.Forms.TextBox
  Friend WithEvents txtHeaderName As System.Windows.Forms.TextBox
  Friend WithEvents btnCancel As System.Windows.Forms.Button
  Friend WithEvents btnOK As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtHeaderValue = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtHeaderName = New System.Windows.Forms.TextBox
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnOK = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(16, 32)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(34, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Value"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtHeaderValue
        '
        Me.txtHeaderValue.Location = New System.Drawing.Point(56, 32)
        Me.txtHeaderValue.Name = "txtHeaderValue"
        Me.txtHeaderValue.Size = New System.Drawing.Size(184, 20)
        Me.txtHeaderValue.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(8, 8)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(42, 13)
        Me.Label19.TabIndex = 15
        Me.Label19.Text = "Header"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtHeaderName
        '
        Me.txtHeaderName.Location = New System.Drawing.Point(56, 8)
        Me.txtHeaderName.Name = "txtHeaderName"
        Me.txtHeaderName.Size = New System.Drawing.Size(184, 20)
        Me.txtHeaderName.TabIndex = 0
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(160, 64)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 20)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(56, 64)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 20)
        Me.btnOK.TabIndex = 2
        Me.btnOK.Text = "OK"
        '
        'frmAddCustomHeader
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 93)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.txtHeaderValue)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtHeaderName)
        Me.Name = "frmAddCustomHeader"
        Me.Text = "Add Custom Header"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

  Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
    txtHeaderName.Text = ""
    Me.Close()
  End Sub

  Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
    Me.Close()
  End Sub
End Class
