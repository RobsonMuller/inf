Partial Class frm5_All
    Inherits System.Web.UI.Page
    Dim WithEvents oSMTP As OSSMTP.SMTPSession
    Dim bClose As Boolean = False
    Public PAGE_TITLE As String = "Sending email (all properties, collections and methods)"

#Region " Web Form Controls "




#End Region

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ID = "frmMain"

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then PopulateDropDowns()
    End Sub

    Protected Sub btnSendEmail_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSendEmail.Click
        Response.Write("<html><head><title>" & PAGE_TITLE & "</title>")
        Response.Write("<style>body {font-family: arial; font-size: 8pt;}</style></head><body>")
        Response.Write("<p style='font-size: 12pt; font-weight: bold;'>" & PAGE_TITLE & "</p>")
        oSMTP = New OSSMTP.SMTPSession
        With oSMTP
            'connection
            .Server = txtServer.Text
            If txtPort.Text <> "" Then .Port = txtPort.Text
            If txtTimeout.Text <> "" Then .Timeout = txtTimeout.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedValue
            .Username = txtUsername.Text
            .Password = txtPassword.Text
            .POPServer = txtPOPServer.Text
            .UseSSL = chkUseSSL.Checked
            'sender and extra headers
            .MailFrom = txtMailFrom.Text
            If txtExpiresAfter.Text <> "" Then .ExpiresAfter = txtExpiresAfter.Text
            .Importance = ddlImportance.SelectedValue
            .Notification = ddlNotification.SelectedValue
            If txtReplyTo.Text <> "" Then .ReplyTo = txtReplyTo.Text
            .Sensitivity = ddlSensitivity.SelectedValue
            If txtTimeStamp.Text <> "" Then .TimeStamp = txtTimeStamp.Text
            'custom headers
            If Request.Form("lstCustomHeaders") <> "" Then
                Dim sCustomHeaders() As String = Split(Request.Form("lstCustomHeaders"), ",")
                Dim i As Integer = 0
                For i = 0 To sCustomHeaders.Length - 1
                    .CustomHeaders.Add(Session(sCustomHeaders(i)))
                Next
            End If
            'recipients
            .SendTo = txtSendTo.Text
            If txtBCC.Text <> "" Then .BCC = txtBCC.Text
            If txtCC.Text <> "" Then .CC = txtCC.Text
            'message
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            If txtCharset.Text <> "" Then .Charset = txtCharset.Text
            If txtContentTransferEncoding.Text <> "" Then .ContentTransferEncoding = txtContentTransferEncoding.Text
            If txtContentType.Text <> "" Then .ContentType = txtContentType.Text
            'attachments
            If Request.Form("lstAttachments") <> "" Then
                Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
                Dim i As Integer = 0
                For i = 0 To sAttachments.Length - 1
                    .Attachments.Add(Session(sAttachments(i)))
                Next
            End If
            'send email
            'action
            Dim b As Button = CType(sender, Button)
            If b.ID = "btnSendEmail" Then
                .SendEmail()
                While Not bClose
                    System.Threading.Thread.Sleep(10)
                End While
            ElseIf b.ID = "btnSaveEmail" Then
                Dim sFile As String = System.Guid.NewGuid.ToString & ".eml"
                .SaveToEML(Server.MapPath("SavedMessages") & "\" & sFile)
                Dim oStreamReader As System.IO.StreamReader = System.IO.File.OpenText(Server.MapPath("SavedMessages") & "\" & sFile)
                Response.Write("<p>Message was saved to <a href=""SavedMessages/" & sFile & """ target=""_blank"">" & sFile & "</a></p>")
                Response.Write("<p><textarea cols=60 rows=10>" & Replace(oStreamReader.ReadToEnd, "<", "&lt;") & "</textarea></p>")
                oStreamReader.Close()
            End If
        End With
        While Not bClose
            System.Threading.Thread.Sleep(10)
        End While
        'cleanup
        If Request.Form("lstAttachments") <> "" Then
            Dim sAttachments() As String = Split(Request.Form("lstAttachments"), ",")
            Dim i As Integer = 0
            For i = 0 To sAttachments.Length - 1
                System.IO.File.Delete(Session(sAttachments(i)))
            Next
        End If
        oSMTP = Nothing
        Response.Write("<p><a href=" & Me.GetType().BaseType.Name & ".aspx>Return to the form</a></p></body></html>" & vbCrLf)
        Response.End()
    End Sub

    Private Sub oSMTP_CloseSMTP() Handles oSMTP.CloseSMTP
        bClose = True
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Short, ByRef Description As String) Handles oSMTP.ErrorSMTP
        Response.Write("Error " & Number & ": " & Description & "<br>" & vbCrLf)
        bClose = True
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        Response.Write(oSMTP.Status & "<br>" & vbCrLf)
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthNTLM
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub

    Private Sub PopulateDropDowns()
        With ddlAuthenticationType.Items
            .Add(New ListItem("None", OSSMTP.authentication_type.AuthNone))
            .Add(New ListItem("POP3", OSSMTP.authentication_type.AuthPOP))
            .Add(New ListItem("AUTH LOGIN", OSSMTP.authentication_type.AuthLogin))
            .Add(New ListItem("AUTH PLAIN", OSSMTP.authentication_type.AuthPlain))
            .Add(New ListItem("NTLM", OSSMTP.authentication_type.AuthNTLM))
        End With
        ddlAuthenticationType.SelectedIndex = 0

        With ddlImportance.Items
            .Add(New ListItem("Normal", OSSMTP.importance_level.ImportanceNormal))
            .Add(New ListItem("Low", OSSMTP.importance_level.ImportanceLow))
            .Add(New ListItem("High", OSSMTP.importance_level.ImportanceHigh))
        End With
        ddlImportance.SelectedIndex = 0

        With ddlNotification.Items
            .Add(New ListItem("None", OSSMTP.notification_type.NotificationNone))
            .Add(New ListItem("On Delivery", OSSMTP.notification_type.NotificationDelivery))
            .Add(New ListItem("On Read", OSSMTP.notification_type.NotificationRead))
            .Add(New ListItem("On Delivery And Read", OSSMTP.notification_type.NotificationDeliveryAndRead))
        End With
        ddlNotification.SelectedIndex = 0

        With ddlSensitivity.Items
            .Add(New ListItem("Normal", OSSMTP.sensitivity_level.SensitivityNormal))
            .Add(New ListItem("Personal", OSSMTP.sensitivity_level.SensitivityPersonal))
            .Add(New ListItem("Private", OSSMTP.sensitivity_level.SensitivityPrivate))
            .Add(New ListItem("Confidential", OSSMTP.sensitivity_level.SensitivityConfidential))
        End With
        ddlSensitivity.SelectedIndex = 0
    End Sub

    Private Sub oSMTP_MessageSaved() Handles oSMTP.MessageSaved

    End Sub
End Class
