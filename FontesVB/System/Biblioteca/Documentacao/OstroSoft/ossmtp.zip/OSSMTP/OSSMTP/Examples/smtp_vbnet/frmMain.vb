Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnBasic As System.Windows.Forms.Button
    Friend WithEvents btnAuthentication As System.Windows.Forms.Button
    Friend WithEvents btnAttachments As System.Windows.Forms.Button
    Friend WithEvents btnHeaders As System.Windows.Forms.Button
    Friend WithEvents btnAll As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnHTML As System.Windows.Forms.Button
    Friend WithEvents btnEmbed As System.Windows.Forms.Button
    Friend WithEvents lbl As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnBasic = New System.Windows.Forms.Button
        Me.btnAuthentication = New System.Windows.Forms.Button
        Me.btnAttachments = New System.Windows.Forms.Button
        Me.btnHeaders = New System.Windows.Forms.Button
        Me.btnAll = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnHTML = New System.Windows.Forms.Button
        Me.lbl = New System.Windows.Forms.Label
        Me.btnEmbed = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnBasic
        '
        Me.btnBasic.Location = New System.Drawing.Point(16, 16)
        Me.btnBasic.Name = "btnBasic"
        Me.btnBasic.Size = New System.Drawing.Size(392, 23)
        Me.btnBasic.TabIndex = 0
        Me.btnBasic.Text = "Sending email (basic)"
        '
        'btnAuthentication
        '
        Me.btnAuthentication.Location = New System.Drawing.Point(16, 48)
        Me.btnAuthentication.Name = "btnAuthentication"
        Me.btnAuthentication.Size = New System.Drawing.Size(392, 23)
        Me.btnAuthentication.TabIndex = 1
        Me.btnAuthentication.Text = "Sending email (with authentication)"
        '
        'btnAttachments
        '
        Me.btnAttachments.Location = New System.Drawing.Point(16, 80)
        Me.btnAttachments.Name = "btnAttachments"
        Me.btnAttachments.Size = New System.Drawing.Size(392, 23)
        Me.btnAttachments.TabIndex = 2
        Me.btnAttachments.Text = "Sending email (with attachments)"
        '
        'btnHeaders
        '
        Me.btnHeaders.Location = New System.Drawing.Point(16, 112)
        Me.btnHeaders.Name = "btnHeaders"
        Me.btnHeaders.Size = New System.Drawing.Size(392, 23)
        Me.btnHeaders.TabIndex = 3
        Me.btnHeaders.Text = "Sending email (with extra headers and additional recipients)"
        '
        'btnAll
        '
        Me.btnAll.Location = New System.Drawing.Point(16, 144)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(392, 23)
        Me.btnAll.TabIndex = 4
        Me.btnAll.Text = "Sending email (all properties, collections and methods)"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(344, 320)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(64, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        '
        'btnHTML
        '
        Me.btnHTML.Location = New System.Drawing.Point(16, 176)
        Me.btnHTML.Name = "btnHTML"
        Me.btnHTML.Size = New System.Drawing.Size(392, 23)
        Me.btnHTML.TabIndex = 5
        Me.btnHTML.Text = "Sending email (with HTML part)"
        '
        'lbl
        '
        Me.lbl.Location = New System.Drawing.Point(16, 240)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(392, 56)
        Me.lbl.TabIndex = 7
        '
        'btnEmbed
        '
        Me.btnEmbed.Location = New System.Drawing.Point(20, 208)
        Me.btnEmbed.Name = "btnEmbed"
        Me.btnEmbed.Size = New System.Drawing.Size(392, 23)
        Me.btnEmbed.TabIndex = 16
        Me.btnEmbed.Text = "Sending email (with HTML and embedded objects)"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(432, 349)
        Me.Controls.Add(Me.btnEmbed)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.btnHTML)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAll)
        Me.Controls.Add(Me.btnHeaders)
        Me.Controls.Add(Me.btnAttachments)
        Me.Controls.Add(Me.btnAuthentication)
        Me.Controls.Add(Me.btnBasic)
        Me.Name = "frmMain"
        Me.Text = "VB.NET samples for OstroSoft SMTP Component (OSSMTP.dll)"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnBasic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBasic.Click
        Dim frm As New frm1_Basic
        frm.Show()
    End Sub

    Private Sub btnAuthentication_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAuthentication.Click
        Dim frm As New frm2_Authentication
        frm.Show()
    End Sub

    Private Sub btnAttachments_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAttachments.Click
        Dim frm As New frm3_Attachments
        frm.Show()
    End Sub

    Private Sub btnHeaders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHeaders.Click
        Dim frm As New frm4_Headers
        frm.Show()
    End Sub

    Private Sub btnAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAll.Click
        Dim frm As New frm5_All
        frm.Show()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnHTML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHTML.Click
        Dim frm As New frm6_HTML
        frm.Show()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbl.Text = "OstroSoft SMTP Component example for Visual Basic.NET," & vbCrLf & _
          "written by Igor Ostrovsky (OstroSoft)" & vbCrLf & _
          "For more information about OstroSoft SMTP Component go to " & vbCrLf & _
          "http://www.ostrosoft.com/ossmtp.aspx"
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub btnEmbed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmbed.Click
        Dim frm As New frm7_EmbeddedObjects
        frm.Show()
    End Sub
End Class
