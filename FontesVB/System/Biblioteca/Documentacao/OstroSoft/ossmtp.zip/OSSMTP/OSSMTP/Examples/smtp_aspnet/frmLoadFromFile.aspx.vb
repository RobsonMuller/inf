Partial Class frmLoadFromFile
    Inherits System.Web.UI.Page
    Public sStatus As String = ""
    Public PAGE_TITLE As String = "Load HTML From File"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnAdd_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.ServerClick
        Dim sGUID As String = ""
        Dim sFile As String = ""

        If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
            Try
                Dim iLength As Integer = CType(File1.PostedFile.InputStream.Length, Integer)
                Dim bytContent As Byte()
                ReDim bytContent(iLength)
                File1.PostedFile.InputStream.Read(bytContent, 0, iLength)
                Dim s As String = System.Text.Encoding.GetEncoding(1252).GetString(bytContent)
                s = Replace(s, "'", "\'")
                s = Replace(s, "</script>", "<\/script>")
                s = Replace(s, vbCrLf, "\n")

                Response.Write("<script language=javascript>")
                Response.Write("opener.document.getElementById('txtMessageHTML').value = '" & s & "';")
                Response.Write("window.close();")
                Response.Write("</script>")
                Response.End()
            Catch exUpload As Exception
                sStatus = "Error: " & exUpload.Message
            End Try
        Else
            sStatus = "Please select a file to upload."
        End If
    End Sub
End Class
