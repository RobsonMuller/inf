Public Class frmAddAttachment
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents dlg As System.Windows.Forms.OpenFileDialog
  Friend WithEvents txtFile As System.Windows.Forms.TextBox
  Friend WithEvents btnBrowse As System.Windows.Forms.Button
  Friend WithEvents btnOK As System.Windows.Forms.Button
  Friend WithEvents btnCancel As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.dlg = New System.Windows.Forms.OpenFileDialog
    Me.txtFile = New System.Windows.Forms.TextBox
    Me.btnBrowse = New System.Windows.Forms.Button
    Me.btnOK = New System.Windows.Forms.Button
    Me.btnCancel = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'txtFile
    '
    Me.txtFile.Location = New System.Drawing.Point(8, 8)
    Me.txtFile.Name = "txtFile"
    Me.txtFile.Size = New System.Drawing.Size(288, 20)
    Me.txtFile.TabIndex = 0
    Me.txtFile.Text = ""
    '
    'btnBrowse
    '
    Me.btnBrowse.Location = New System.Drawing.Point(304, 8)
    Me.btnBrowse.Name = "btnBrowse"
    Me.btnBrowse.Size = New System.Drawing.Size(75, 20)
    Me.btnBrowse.TabIndex = 1
    Me.btnBrowse.Text = "Browse"
    '
    'btnOK
    '
    Me.btnOK.Location = New System.Drawing.Point(104, 40)
    Me.btnOK.Name = "btnOK"
    Me.btnOK.Size = New System.Drawing.Size(75, 20)
    Me.btnOK.TabIndex = 2
    Me.btnOK.Text = "OK"
    '
    'btnCancel
    '
    Me.btnCancel.Location = New System.Drawing.Point(208, 40)
    Me.btnCancel.Name = "btnCancel"
    Me.btnCancel.Size = New System.Drawing.Size(75, 20)
    Me.btnCancel.TabIndex = 3
    Me.btnCancel.Text = "Cancel"
    '
    'frmAddAttachment
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(384, 69)
    Me.Controls.Add(Me.btnCancel)
    Me.Controls.Add(Me.btnOK)
    Me.Controls.Add(Me.btnBrowse)
    Me.Controls.Add(Me.txtFile)
    Me.Name = "frmAddAttachment"
    Me.Text = "Add Attachment"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
    dlg.ShowDialog()
    txtFile.Text = dlg.FileName
  End Sub

  Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
    txtFile.Text = ""
    Me.Close()
  End Sub

  Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
    Me.Close()
  End Sub
End Class
