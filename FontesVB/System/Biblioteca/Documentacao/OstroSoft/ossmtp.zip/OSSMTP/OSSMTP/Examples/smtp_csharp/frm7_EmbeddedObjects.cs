﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace smtp_csharp
{
    public partial class frm7_EmbeddedObjects : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkUseSSL = new System.Windows.Forms.CheckBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtMessageHTML = new System.Windows.Forms.TextBox();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.txtPOPServer = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.ddlAuthenticationType = new System.Windows.Forms.ComboBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtMessageText = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtMessageSubject = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtMailFrom = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtSendTo = new System.Windows.Forms.TextBox();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelAttachment = new System.Windows.Forms.Button();
            this.btnAddAttachment = new System.Windows.Forms.Button();
            this.lstEmbeddedObjects = new System.Windows.Forms.ListBox();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkUseSSL
            // 
            this.chkUseSSL.AutoSize = true;
            this.chkUseSSL.Location = new System.Drawing.Point(104, 331);
            this.chkUseSSL.Name = "chkUseSSL";
            this.chkUseSSL.Size = new System.Drawing.Size(68, 17);
            this.chkUseSSL.TabIndex = 39;
            this.chkUseSSL.Text = "Use SSL";
            this.chkUseSSL.UseVisualStyleBackColor = true;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(304, 7);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(83, 13);
            this.Label11.TabIndex = 49;
            this.Label11.Text = "Message HTML";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageHTML
            // 
            this.txtMessageHTML.Location = new System.Drawing.Point(304, 23);
            this.txtMessageHTML.Multiline = true;
            this.txtMessageHTML.Name = "txtMessageHTML";
            this.txtMessageHTML.ReadOnly = true;
            this.txtMessageHTML.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMessageHTML.Size = new System.Drawing.Size(288, 148);
            this.txtMessageHTML.TabIndex = 38;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.Label10);
            this.GroupBox1.Controls.Add(this.Label7);
            this.GroupBox1.Controls.Add(this.txtPOPServer);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Controls.Add(this.txtPassword);
            this.GroupBox1.Controls.Add(this.Label9);
            this.GroupBox1.Controls.Add(this.txtUsername);
            this.GroupBox1.Controls.Add(this.ddlAuthenticationType);
            this.GroupBox1.Location = new System.Drawing.Point(8, 29);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(288, 116);
            this.GroupBox1.TabIndex = 48;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Authentication settings";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(59, 18);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(31, 13);
            this.Label10.TabIndex = 14;
            this.Label10.Text = "Type";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(17, 88);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(69, 13);
            this.Label7.TabIndex = 13;
            this.Label7.Text = "POP3 Server";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtPOPServer
            // 
            this.txtPOPServer.Location = new System.Drawing.Point(96, 88);
            this.txtPOPServer.Name = "txtPOPServer";
            this.txtPOPServer.Size = new System.Drawing.Size(184, 20);
            this.txtPOPServer.TabIndex = 4;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(34, 64);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(53, 13);
            this.Label8.TabIndex = 11;
            this.Label8.Text = "Password";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(96, 64);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(184, 20);
            this.txtPassword.TabIndex = 3;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(32, 40);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(55, 13);
            this.Label9.TabIndex = 9;
            this.Label9.Text = "Username";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(96, 40);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(184, 20);
            this.txtUsername.TabIndex = 2;
            // 
            // ddlAuthenticationType
            // 
            this.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAuthenticationType.Location = new System.Drawing.Point(96, 16);
            this.ddlAuthenticationType.Name = "ddlAuthenticationType";
            this.ddlAuthenticationType.Size = new System.Drawing.Size(184, 21);
            this.ddlAuthenticationType.TabIndex = 1;
            this.ddlAuthenticationType.SelectedIndexChanged += new System.EventHandler(this.ddlAuthenticationType_SelectedIndexChanged);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(16, 343);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(37, 13);
            this.Label6.TabIndex = 47;
            this.Label6.Text = "Status";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(24, 223);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(74, 13);
            this.Label5.TabIndex = 44;
            this.Label5.Text = "Message Text";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(8, 359);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtStatus.Size = new System.Drawing.Size(584, 168);
            this.txtStatus.TabIndex = 46;
            // 
            // txtMessageText
            // 
            this.txtMessageText.Location = new System.Drawing.Point(104, 223);
            this.txtMessageText.Multiline = true;
            this.txtMessageText.Name = "txtMessageText";
            this.txtMessageText.Size = new System.Drawing.Size(184, 96);
            this.txtMessageText.TabIndex = 37;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(8, 199);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(89, 13);
            this.Label4.TabIndex = 43;
            this.Label4.Text = "Message Subject";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMessageSubject
            // 
            this.txtMessageSubject.Location = new System.Drawing.Point(104, 199);
            this.txtMessageSubject.Name = "txtMessageSubject";
            this.txtMessageSubject.Size = new System.Drawing.Size(184, 20);
            this.txtMessageSubject.TabIndex = 36;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(40, 151);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(52, 13);
            this.Label2.TabIndex = 41;
            this.Label2.Text = "Mail From";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtMailFrom
            // 
            this.txtMailFrom.Location = new System.Drawing.Point(104, 151);
            this.txtMailFrom.Name = "txtMailFrom";
            this.txtMailFrom.Size = new System.Drawing.Size(184, 20);
            this.txtMailFrom.TabIndex = 34;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(56, 5);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(38, 13);
            this.Label1.TabIndex = 40;
            this.Label1.Text = "Server";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(48, 175);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(48, 13);
            this.Label3.TabIndex = 42;
            this.Label3.Text = "Send To";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtSendTo
            // 
            this.txtSendTo.Location = new System.Drawing.Point(104, 175);
            this.txtSendTo.Name = "txtSendTo";
            this.txtSendTo.Size = new System.Drawing.Size(184, 20);
            this.txtSendTo.TabIndex = 35;
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(104, 5);
            this.txtServer.Name = "txtServer";
            this.txtServer.Size = new System.Drawing.Size(184, 20);
            this.txtServer.TabIndex = 33;
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Location = new System.Drawing.Point(264, 327);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(75, 23);
            this.btnSendEmail.TabIndex = 45;
            this.btnSendEmail.Text = "Send Email";
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.btnDelAttachment);
            this.GroupBox2.Controls.Add(this.btnAddAttachment);
            this.GroupBox2.Controls.Add(this.lstEmbeddedObjects);
            this.GroupBox2.Location = new System.Drawing.Point(304, 177);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(272, 136);
            this.GroupBox2.TabIndex = 50;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Embedded Objects";
            // 
            // btnDelAttachment
            // 
            this.btnDelAttachment.Location = new System.Drawing.Point(152, 104);
            this.btnDelAttachment.Name = "btnDelAttachment";
            this.btnDelAttachment.Size = new System.Drawing.Size(75, 23);
            this.btnDelAttachment.TabIndex = 10;
            this.btnDelAttachment.Text = "Delete";
            this.btnDelAttachment.Click += new System.EventHandler(this.btnDelAttachment_Click);
            // 
            // btnAddAttachment
            // 
            this.btnAddAttachment.Location = new System.Drawing.Point(64, 104);
            this.btnAddAttachment.Name = "btnAddAttachment";
            this.btnAddAttachment.Size = new System.Drawing.Size(75, 23);
            this.btnAddAttachment.TabIndex = 9;
            this.btnAddAttachment.Text = "Add";
            this.btnAddAttachment.Click += new System.EventHandler(this.btnAddAttachment_Click);
            // 
            // lstEmbeddedObjects
            // 
            this.lstEmbeddedObjects.HorizontalScrollbar = true;
            this.lstEmbeddedObjects.Location = new System.Drawing.Point(8, 16);
            this.lstEmbeddedObjects.Name = "lstEmbeddedObjects";
            this.lstEmbeddedObjects.Size = new System.Drawing.Size(256, 82);
            this.lstEmbeddedObjects.TabIndex = 18;
            // 
            // frm7_EmbeddedObjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 533);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.chkUseSSL);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.txtMessageHTML);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.txtMessageText);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtMessageSubject);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtMailFrom);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtSendTo);
            this.Controls.Add(this.txtServer);
            this.Controls.Add(this.btnSendEmail);
            this.Name = "frm7_EmbeddedObjects";
            this.Text = "Sending email (with HTML and embedded objects)";
            this.Load += new System.EventHandler(this.frm2_Authentication_Load);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private OSSMTP.SMTPSession oSMTP;
        private System.Windows.Forms.CheckBox chkUseSSL;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox txtMessageHTML;
        internal System.Windows.Forms.OpenFileDialog dlg;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox txtPOPServer;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox txtPassword;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox txtUsername;
        internal System.Windows.Forms.ComboBox ddlAuthenticationType;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtStatus;
        internal System.Windows.Forms.TextBox txtMessageText;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtMessageSubject;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtMailFrom;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtSendTo;
        internal System.Windows.Forms.TextBox txtServer;
        internal System.Windows.Forms.Button btnSendEmail;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button btnDelAttachment;
        internal System.Windows.Forms.Button btnAddAttachment;
        internal System.Windows.Forms.ListBox lstEmbeddedObjects;

        public frm7_EmbeddedObjects()
        {
            InitializeComponent();

            this.oSMTP = new OSSMTP.SMTPSession();
            this.oSMTP.ErrorSMTP += new OSSMTP.__SMTPSession_ErrorSMTPEventHandler(this.oSMTP_ErrorSMTP);
            this.oSMTP.StatusChanged += new OSSMTP.__SMTPSession_StatusChangedEventHandler(this.oSMTP_StatusChanged);
        }

        private void btnSendEmail_Click(object sender, System.EventArgs e)
        {
            txtStatus.Text = "";

            //connection
            oSMTP.Server = txtServer.Text;
            //authentication
            oSMTP.AuthenticationType = (OSSMTP.authentication_type)ddlAuthenticationType.SelectedIndex;
            if (txtUsername.Text != "") oSMTP.Username = txtUsername.Text;
            if (txtPassword.Text != "") oSMTP.Password = txtPassword.Text;
            if (txtPOPServer.Text != "") oSMTP.POPServer = txtPOPServer.Text;
            oSMTP.UseSSL = chkUseSSL.Checked;
            //message
            oSMTP.MailFrom = txtMailFrom.Text;
            oSMTP.SendTo = txtSendTo.Text;
            oSMTP.MessageSubject = txtMessageSubject.Text;
            oSMTP.MessageText = txtMessageText.Text;
            oSMTP.MessageHTML = txtMessageHTML.Text;
            //attachments
            int i = 0;
            object objNone = System.Reflection.Missing.Value;
            object objFile = "";
            for (i = 0; i < lstEmbeddedObjects.Items.Count; i++)
            {
                objFile = lstEmbeddedObjects.Items[i];
                oSMTP.Attachments.Add(ref objFile, ref objNone, ref objNone, ref objNone);
            }
            //send email
            oSMTP.SendEmail();
        }

        private void oSMTP_ErrorSMTP(short number, ref string description)
        {
            txtStatus.Text = txtStatus.Text + "Error " + number + ": " + description + "\r\n";
        }

        private void oSMTP_StatusChanged(string status)
        {
            txtStatus.Text = txtStatus.Text + status + "\r\n";
        }

        private void frm2_Authentication_Load(object sender, System.EventArgs e)
        {
            ddlAuthenticationType.Items.Add("None");
            ddlAuthenticationType.Items.Add("POP3");
            ddlAuthenticationType.Items.Add("AUTH LOGIN");
            ddlAuthenticationType.Items.Add("AUTH PLAIN");
            ddlAuthenticationType.Items.Add("NTLM");
            ddlAuthenticationType.SelectedIndex = 0;
        }

        private void ddlAuthenticationType_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            switch (ddlAuthenticationType.SelectedIndex)
            {
                case (int)OSSMTP.authentication_type.AuthNone:
                    txtUsername.Enabled = false;
                    txtUsername.Text = "";
                    txtPassword.Enabled = false;
                    txtPassword.Text = "";
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
                case (int)OSSMTP.authentication_type.AuthPOP:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = true;
                    break;
                case (int)OSSMTP.authentication_type.AuthLogin:
                case (int)OSSMTP.authentication_type.AuthPlain:
                    txtUsername.Enabled = true;
                    txtPassword.Enabled = true;
                    txtPOPServer.Enabled = false;
                    txtPOPServer.Text = "";
                    break;
            }
        }

        private void btnAddAttachment_Click(object sender, System.EventArgs e)
        {
            frmAddAttachment frm = new frmAddAttachment();
            frm.Text = "Add Embedded Object";
            frm.ShowDialog(this);
            if (frm.txtFile.Text.Trim() != "")
                lstEmbeddedObjects.Items.Add(frm.txtFile.Text);
            frm.Dispose();
            UpdateHTML();
        }

        private void btnDelAttachment_Click(object sender, System.EventArgs e)
        {
            if (lstEmbeddedObjects.SelectedIndex > -1)
                lstEmbeddedObjects.Items.RemoveAt(lstEmbeddedObjects.SelectedIndex);
            UpdateHTML();
        }

        private void UpdateHTML()
        {
            if (lstEmbeddedObjects.Items.Count == 0)
                txtMessageHTML.Text = "";
            else
            {
                string sHTML = "";
                string s = "";
                sHTML = "<html><body>embedded image test<br>\r\n";
                for (int i = 0; i < lstEmbeddedObjects.Items.Count; i++)
                {
                    s = Convert.ToString(lstEmbeddedObjects.Items[i]);
                    if (s.IndexOf("\\") > 0)
                        s = s.Substring(s.LastIndexOf("\\") + 1);
                    sHTML = sHTML + "<img src=\"cid:" + s + "\">\r\n";
                }
                sHTML = sHTML + "</body></html>\r\n";
                txtMessageHTML.Text = sHTML;
            }
        }
    }
}
