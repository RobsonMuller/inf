Public Class frm4_Headers
    Inherits System.Windows.Forms.Form
    Dim WithEvents oSMTP As OSSMTP.SMTPSession

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnSendEmail As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ddlAuthenticationType As System.Windows.Forms.ComboBox
    Friend WithEvents txtPOPServer As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDelAttachment As System.Windows.Forms.Button
    Friend WithEvents btnAddAttachment As System.Windows.Forms.Button
    Friend WithEvents lstAttachments As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtReplyTo As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtExpiresAfter As System.Windows.Forms.TextBox
    Friend WithEvents ddlSensitivity As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ddlImportance As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ddlNotification As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMailFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtTimeStamp As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDelCustomHeader As System.Windows.Forms.Button
    Friend WithEvents btnAddCustomHeader As System.Windows.Forms.Button
    Friend WithEvents lstCustomHeaders As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtCC As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtBCC As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSendTo As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMessageText As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMessageSubject As System.Windows.Forms.TextBox
    Friend WithEvents txtCharset As System.Windows.Forms.TextBox
    Friend WithEvents txtContentType As System.Windows.Forms.TextBox
    Private WithEvents chkUseSSL As System.Windows.Forms.CheckBox
    Friend WithEvents txtContentTransferEncoding As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnSendEmail = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtPOPServer = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.ddlAuthenticationType = New System.Windows.Forms.ComboBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnDelAttachment = New System.Windows.Forms.Button
        Me.btnAddAttachment = New System.Windows.Forms.Button
        Me.lstAttachments = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtTimeStamp = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMailFrom = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.ddlNotification = New System.Windows.Forms.ComboBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.ddlImportance = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtReplyTo = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtExpiresAfter = New System.Windows.Forms.TextBox
        Me.ddlSensitivity = New System.Windows.Forms.ComboBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.btnDelCustomHeader = New System.Windows.Forms.Button
        Me.btnAddCustomHeader = New System.Windows.Forms.Button
        Me.lstCustomHeaders = New System.Windows.Forms.ListBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtSendTo = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtCC = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtBCC = New System.Windows.Forms.TextBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtMessageText = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMessageSubject = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtCharset = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtContentType = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtContentTransferEncoding = New System.Windows.Forms.TextBox
        Me.chkUseSSL = New System.Windows.Forms.CheckBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(104, 8)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(184, 20)
        Me.txtServer.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Server"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'btnSendEmail
        '
        Me.btnSendEmail.Location = New System.Drawing.Point(264, 496)
        Me.btnSendEmail.Name = "btnSendEmail"
        Me.btnSendEmail.Size = New System.Drawing.Size(75, 23)
        Me.btnSendEmail.TabIndex = 25
        Me.btnSendEmail.Text = "Send Email"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 512)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Status"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(8, 528)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(584, 168)
        Me.txtStatus.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtPOPServer)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.ddlAuthenticationType)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 116)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Authentication settings"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(59, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Type"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "POP3 Server"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPOPServer
        '
        Me.txtPOPServer.Location = New System.Drawing.Point(96, 88)
        Me.txtPOPServer.Name = "txtPOPServer"
        Me.txtPOPServer.Size = New System.Drawing.Size(184, 20)
        Me.txtPOPServer.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(34, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Password"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(96, 64)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(184, 20)
        Me.txtPassword.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Username"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(96, 40)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(184, 20)
        Me.txtUsername.TabIndex = 2
        '
        'ddlAuthenticationType
        '
        Me.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlAuthenticationType.Location = New System.Drawing.Point(96, 16)
        Me.ddlAuthenticationType.Name = "ddlAuthenticationType"
        Me.ddlAuthenticationType.Size = New System.Drawing.Size(184, 21)
        Me.ddlAuthenticationType.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDelAttachment)
        Me.GroupBox2.Controls.Add(Me.btnAddAttachment)
        Me.GroupBox2.Controls.Add(Me.lstAttachments)
        Me.GroupBox2.Location = New System.Drawing.Point(304, 344)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(288, 136)
        Me.GroupBox2.TabIndex = 18
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Attachments"
        '
        'btnDelAttachment
        '
        Me.btnDelAttachment.Location = New System.Drawing.Point(152, 104)
        Me.btnDelAttachment.Name = "btnDelAttachment"
        Me.btnDelAttachment.Size = New System.Drawing.Size(75, 23)
        Me.btnDelAttachment.TabIndex = 23
        Me.btnDelAttachment.Text = "Delete"
        '
        'btnAddAttachment
        '
        Me.btnAddAttachment.Location = New System.Drawing.Point(64, 104)
        Me.btnAddAttachment.Name = "btnAddAttachment"
        Me.btnAddAttachment.Size = New System.Drawing.Size(75, 23)
        Me.btnAddAttachment.TabIndex = 22
        Me.btnAddAttachment.Text = "Add"
        '
        'lstAttachments
        '
        Me.lstAttachments.HorizontalScrollbar = True
        Me.lstAttachments.Location = New System.Drawing.Point(8, 16)
        Me.lstAttachments.Name = "lstAttachments"
        Me.lstAttachments.Size = New System.Drawing.Size(272, 82)
        Me.lstAttachments.TabIndex = 36
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.txtTimeStamp)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtMailFrom)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.ddlNotification)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.ddlImportance)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.txtReplyTo)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.txtExpiresAfter)
        Me.GroupBox3.Controls.Add(Me.ddlSensitivity)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 152)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(288, 184)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Sender and extra headers"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(25, 160)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 13)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "TimeStamp"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtTimeStamp
        '
        Me.txtTimeStamp.Location = New System.Drawing.Point(96, 160)
        Me.txtTimeStamp.Name = "txtTimeStamp"
        Me.txtTimeStamp.Size = New System.Drawing.Size(184, 20)
        Me.txtTimeStamp.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Mail From"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMailFrom
        '
        Me.txtMailFrom.Location = New System.Drawing.Point(96, 16)
        Me.txtMailFrom.Name = "txtMailFrom"
        Me.txtMailFrom.Size = New System.Drawing.Size(184, 20)
        Me.txtMailFrom.TabIndex = 5
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(27, 88)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 13)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "Notification"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'ddlNotification
        '
        Me.ddlNotification.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlNotification.Location = New System.Drawing.Point(96, 88)
        Me.ddlNotification.Name = "ddlNotification"
        Me.ddlNotification.Size = New System.Drawing.Size(184, 21)
        Me.ddlNotification.TabIndex = 8
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(26, 64)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(60, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Importance"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'ddlImportance
        '
        Me.ddlImportance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlImportance.Location = New System.Drawing.Point(96, 64)
        Me.ddlImportance.Name = "ddlImportance"
        Me.ddlImportance.Size = New System.Drawing.Size(184, 21)
        Me.ddlImportance.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(32, 136)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Sensitivity"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(38, 112)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Reply To"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtReplyTo
        '
        Me.txtReplyTo.Location = New System.Drawing.Point(96, 112)
        Me.txtReplyTo.Name = "txtReplyTo"
        Me.txtReplyTo.Size = New System.Drawing.Size(184, 20)
        Me.txtReplyTo.TabIndex = 9
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(18, 40)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Expires After"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtExpiresAfter
        '
        Me.txtExpiresAfter.Location = New System.Drawing.Point(96, 40)
        Me.txtExpiresAfter.Name = "txtExpiresAfter"
        Me.txtExpiresAfter.Size = New System.Drawing.Size(184, 20)
        Me.txtExpiresAfter.TabIndex = 6
        '
        'ddlSensitivity
        '
        Me.ddlSensitivity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlSensitivity.Location = New System.Drawing.Point(96, 136)
        Me.ddlSensitivity.Name = "ddlSensitivity"
        Me.ddlSensitivity.Size = New System.Drawing.Size(184, 21)
        Me.ddlSensitivity.TabIndex = 10
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnDelCustomHeader)
        Me.GroupBox4.Controls.Add(Me.btnAddCustomHeader)
        Me.GroupBox4.Controls.Add(Me.lstCustomHeaders)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 344)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(288, 136)
        Me.GroupBox4.TabIndex = 20
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Custom Headers"
        '
        'btnDelCustomHeader
        '
        Me.btnDelCustomHeader.Location = New System.Drawing.Point(152, 104)
        Me.btnDelCustomHeader.Name = "btnDelCustomHeader"
        Me.btnDelCustomHeader.Size = New System.Drawing.Size(75, 23)
        Me.btnDelCustomHeader.TabIndex = 13
        Me.btnDelCustomHeader.Text = "Delete"
        '
        'btnAddCustomHeader
        '
        Me.btnAddCustomHeader.Location = New System.Drawing.Point(64, 104)
        Me.btnAddCustomHeader.Name = "btnAddCustomHeader"
        Me.btnAddCustomHeader.Size = New System.Drawing.Size(75, 23)
        Me.btnAddCustomHeader.TabIndex = 12
        Me.btnAddCustomHeader.Text = "Add"
        '
        'lstCustomHeaders
        '
        Me.lstCustomHeaders.HorizontalScrollbar = True
        Me.lstCustomHeaders.Location = New System.Drawing.Point(8, 16)
        Me.lstCustomHeaders.Name = "lstCustomHeaders"
        Me.lstCustomHeaders.Size = New System.Drawing.Size(272, 82)
        Me.lstCustomHeaders.TabIndex = 35
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.txtSendTo)
        Me.GroupBox5.Controls.Add(Me.Label18)
        Me.GroupBox5.Controls.Add(Me.txtCC)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Controls.Add(Me.txtBCC)
        Me.GroupBox5.Location = New System.Drawing.Point(304, 8)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(288, 96)
        Me.GroupBox5.TabIndex = 21
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Recipients"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Send To"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtSendTo
        '
        Me.txtSendTo.Location = New System.Drawing.Point(96, 16)
        Me.txtSendTo.Name = "txtSendTo"
        Me.txtSendTo.Size = New System.Drawing.Size(184, 20)
        Me.txtSendTo.TabIndex = 14
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(66, 64)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(21, 13)
        Me.Label18.TabIndex = 13
        Me.Label18.Text = "CC"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtCC
        '
        Me.txtCC.Location = New System.Drawing.Point(96, 64)
        Me.txtCC.Name = "txtCC"
        Me.txtCC.Size = New System.Drawing.Size(184, 20)
        Me.txtCC.TabIndex = 16
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(59, 40)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 13)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "BCC"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtBCC
        '
        Me.txtBCC.Location = New System.Drawing.Point(96, 40)
        Me.txtBCC.Name = "txtBCC"
        Me.txtBCC.Size = New System.Drawing.Size(184, 20)
        Me.txtBCC.TabIndex = 15
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.txtMessageText)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Controls.Add(Me.txtMessageSubject)
        Me.GroupBox6.Controls.Add(Me.Label12)
        Me.GroupBox6.Controls.Add(Me.txtCharset)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Controls.Add(Me.txtContentType)
        Me.GroupBox6.Controls.Add(Me.Label21)
        Me.GroupBox6.Controls.Add(Me.txtContentTransferEncoding)
        Me.GroupBox6.Location = New System.Drawing.Point(304, 112)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(288, 224)
        Me.GroupBox6.TabIndex = 22
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Message"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Message Text"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageText
        '
        Me.txtMessageText.Location = New System.Drawing.Point(96, 40)
        Me.txtMessageText.Multiline = True
        Me.txtMessageText.Name = "txtMessageText"
        Me.txtMessageText.Size = New System.Drawing.Size(184, 96)
        Me.txtMessageText.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(0, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Message Subject"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageSubject
        '
        Me.txtMessageSubject.Location = New System.Drawing.Point(96, 16)
        Me.txtMessageSubject.Name = "txtMessageSubject"
        Me.txtMessageSubject.Size = New System.Drawing.Size(184, 20)
        Me.txtMessageSubject.TabIndex = 17
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(48, 144)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(43, 13)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Charset"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtCharset
        '
        Me.txtCharset.Location = New System.Drawing.Point(96, 144)
        Me.txtCharset.Name = "txtCharset"
        Me.txtCharset.Size = New System.Drawing.Size(184, 20)
        Me.txtCharset.TabIndex = 19
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(16, 192)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(71, 13)
        Me.Label20.TabIndex = 13
        Me.Label20.Text = "Content Type"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtContentType
        '
        Me.txtContentType.Location = New System.Drawing.Point(96, 192)
        Me.txtContentType.Name = "txtContentType"
        Me.txtContentType.Size = New System.Drawing.Size(184, 20)
        Me.txtContentType.TabIndex = 21
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(0, 168)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(96, 24)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Content Transfer Encoding"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtContentTransferEncoding
        '
        Me.txtContentTransferEncoding.Location = New System.Drawing.Point(96, 168)
        Me.txtContentTransferEncoding.Name = "txtContentTransferEncoding"
        Me.txtContentTransferEncoding.Size = New System.Drawing.Size(184, 20)
        Me.txtContentTransferEncoding.TabIndex = 20
        '
        'chkUseSSL
        '
        Me.chkUseSSL.AutoSize = True
        Me.chkUseSSL.Location = New System.Drawing.Point(104, 486)
        Me.chkUseSSL.Name = "chkUseSSL"
        Me.chkUseSSL.Size = New System.Drawing.Size(68, 17)
        Me.chkUseSSL.TabIndex = 24
        Me.chkUseSSL.Text = "Use SSL"
        Me.chkUseSSL.UseVisualStyleBackColor = True
        '
        'frm4_Headers
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 701)
        Me.Controls.Add(Me.chkUseSSL)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtServer)
        Me.Controls.Add(Me.btnSendEmail)
        Me.Name = "frm4_Headers"
        Me.Text = "Sending email (with extra headers and additional recipients)"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub btnSendEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        oSMTP = New OSSMTP.SMTPSession
        txtStatus.Text = ""
        Dim i As Integer = 0
        With oSMTP
            'connection
            .Server = txtServer.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedIndex
            If txtUsername.Text <> "" Then .Username = txtUsername.Text
            If txtPassword.Text <> "" Then .Password = txtPassword.Text
            If txtPOPServer.Text <> "" Then .POPServer = txtPOPServer.Text
            oSMTP.UseSSL = chkUseSSL.Checked
            'sender and extra headers
            .MailFrom = txtMailFrom.Text
            If txtExpiresAfter.Text <> "" Then .ExpiresAfter = txtExpiresAfter.Text
            .Importance = ddlImportance.SelectedIndex
            .Notification = ddlNotification.SelectedIndex
            If txtReplyTo.Text <> "" Then .ReplyTo = txtReplyTo.Text
            .Sensitivity = ddlSensitivity.SelectedIndex
            If txtTimeStamp.Text <> "" Then .TimeStamp = txtTimeStamp.Text
            'custom headers
            For i = 0 To lstCustomHeaders.Items.Count - 1
                .CustomHeaders.Add(CStr(lstCustomHeaders.Items(i)))
            Next
            'recipients
            .SendTo = txtSendTo.Text
            If txtBCC.Text <> "" Then .BCC = txtBCC.Text
            If txtCC.Text <> "" Then .CC = txtCC.Text
            'message
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            If txtCharset.Text <> "" Then .Charset = txtCharset.Text
            If txtContentTransferEncoding.Text <> "" Then .ContentTransferEncoding = txtContentTransferEncoding.Text
            If txtContentType.Text <> "" Then .ContentType = txtContentType.Text
            'attachments
            For i = 0 To lstAttachments.Items.Count - 1
                .Attachments.Add(CStr(lstAttachments.Items(i)))
            Next
            'send email
            .SendEmail()
        End With
        oSMTP = Nothing
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Short, ByRef Description As String) Handles oSMTP.ErrorSMTP
        txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        txtStatus.Text = txtStatus.Text & oSMTP.Status & vbCrLf
    End Sub

    Private Sub frm1_Basic_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With ddlAuthenticationType.Items
            .Add("None")
            .Add("POP3")
            .Add("AUTH LOGIN")
            .Add("AUTH PLAIN")
            .Add("NTLM")
        End With
        ddlAuthenticationType.SelectedIndex = 0

        With ddlImportance.Items
            .Add("Normal")
            .Add("Low")
            .Add("High")
        End With
        ddlImportance.SelectedIndex = 0

        With ddlNotification.Items
            .Add("None")
            .Add("On Delivery")
            .Add("On Read")
            .Add("On Delivery And Read")
        End With
        ddlNotification.SelectedIndex = 0

        With ddlSensitivity.Items
            .Add("Normal")
            .Add("Personal")
            .Add("Private")
            .Add("Confidential")
        End With
        ddlSensitivity.SelectedIndex = 0
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub

    Private Sub btnAddAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddAttachment.Click
        Dim frm As New frmAddAttachment
        frm.ShowDialog(Me)
        If Trim(frm.txtFile.Text) <> "" Then lstAttachments.Items.Add(frm.txtFile.Text)
        frm.Dispose()
    End Sub

    Private Sub btnDelAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelAttachment.Click
        If lstAttachments.SelectedIndex > -1 Then lstAttachments.Items.RemoveAt(lstAttachments.SelectedIndex)
    End Sub

    Private Sub btnAddCustomHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCustomHeader.Click
        Dim frm As New frmAddCustomHeader
        frm.ShowDialog(Me)
        If Trim(frm.txtHeaderName.Text) <> "" Then lstCustomHeaders.Items.Add(frm.txtHeaderName.Text & ": " & frm.txtHeaderValue.Text)
        frm.Dispose()
    End Sub

    Private Sub btnDelCustomHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelCustomHeader.Click
        If lstCustomHeaders.SelectedIndex > -1 Then lstCustomHeaders.Items.RemoveAt(lstCustomHeaders.SelectedIndex)
    End Sub
End Class
