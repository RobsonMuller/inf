var wAddAttachment = null;
var wAddCustomHeader = null;

function AddAttachment() {
//  try {
//    wAddAttachment.focus();
//  } catch(e) {
    wAddAttachment = window.open('frmAddAttachment.aspx', 'frmAddAttachment', 
      'top=100, left=100, width=400, height=150, resizable=yes, toolbar=no, menubar=no, location=no, directories=no');
//  }
}    

function DelAttachment() {
  var o = document.all.lstAttachments; 
  if (o.selectedIndex == -1) {
    alert('Please select an attachment to delete');
    return false;
  }
  
  var s = o.options[o.selectedIndex].value;
  window.open('frmDelAttachment.aspx?s=' + s, 'frmDelAttachment', 
    'top=-100, left=-100, width=10, height=10, resizable=yes, toolbar=no, menubar=no, location=no, directories=no');
}    

function AddCustomHeader() {
  try {
    wAddCustomHeader.focus();
  } catch(e) {
    wAddCustomHeader = window.open('frmAddCustomHeader.aspx', 'frmAddCustomHeader', 
      'top=100, left=100, width=450, height=150, resizable=yes, toolbar=no, menubar=no, location=no, directories=no');
  }
}    

function DelCustomHeader() {
  var o = document.all.lstCustomHeaders; 
  if (o.selectedIndex == -1) {
    alert('Please select a custom header to delete');
    return false;
  }
  
  var s = o.options[o.selectedIndex].value;
  window.open('frmDelCustomHeader.aspx?s=' + s, 'frmDelCustomHeader', 
    'top=-100, left=-100, width=10, height=10, resizable=yes, toolbar=no, menubar=no, location=no, directories=no');
}    

function SelectAll(lst) { 
  for (i = 0; i < lst.length; i++) 
    lst.options[i].selected = true 
} 
