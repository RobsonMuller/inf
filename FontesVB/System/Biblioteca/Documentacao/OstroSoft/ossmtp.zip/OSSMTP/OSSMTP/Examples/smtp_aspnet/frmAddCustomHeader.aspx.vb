Partial Class frmAddCustomHeader
    Inherits System.Web.UI.Page
    Public sStatus As String = ""
    Public PAGE_TITLE As String = "Add Custom Header"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnAdd_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.ServerClick
        Dim oCustomHeader As New OSSMTP.CustomHeader
        Dim sGUID As String = ""
        Dim sFile As String = ""

        If txtHeaderName.Value = "" Then
            sStatus = "Enter Header Name"
        ElseIf txtHeaderValue.Value = "" Then
            sStatus = "Enter Header Value"
        Else
            Try
                sGUID = System.Guid.NewGuid.ToString
                Session(sGUID) = txtHeaderName.Value & ": " & txtHeaderValue.Value
                Response.Write("<script language=javascript>")
                Response.Write("var ddl = window.opener.document.getElementById('lstCustomHeaders');")
                Response.Write("var opt = window.opener.document.createElement('option');")
                Response.Write("ddl.options.add(opt);")
                Response.Write("opt.text = '" & txtHeaderName.Value & ": " & txtHeaderValue.Value & "';")
                Response.Write("opt.value = '" & sGUID & "';")
                Response.Write("ddl.selectedIndex = ddl.options.length - 1;")
                Response.Write("window.close();")
                Response.Write("</script>")
                Response.End()
            Catch exUpload As Exception
                sStatus = "Error: " & exUpload.Message
            End Try
        End If
    End Sub
End Class
