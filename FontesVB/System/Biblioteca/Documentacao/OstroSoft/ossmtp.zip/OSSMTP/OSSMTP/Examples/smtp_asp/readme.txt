The latest version of OstroSoft SMTP Component is located at http://www.ostrosoft.com/ossmtp.aspx

Before starting the project make sure OSSMTP is installed/registered on your computer
Under 32-bit operating systems it should be located in Windows system directory
Under 64-bit operating systems it should be located in Windows\SysWOW64 directory

To register OSSMTP on some versions of Windows you may need to run Command Prompt in Administrator mode
You can do it by clicking on its shortcut while holding Ctrl+Shift keys
At the command prompt enter the following: regsvr32 <full path to OSSMTP> and hit Enter key
