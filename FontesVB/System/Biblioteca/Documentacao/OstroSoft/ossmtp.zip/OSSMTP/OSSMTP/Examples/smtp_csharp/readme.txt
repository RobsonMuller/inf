The latest version of OstroSoft SMTP Component is located at http://www.ostrosoft.com/ossmtp.aspx


Before starting the project make sure OSSMTP is installed/registered on your computer
Under 32-bit operating systems it should be located in Windows system directory
Under 64-bit operating systems it should be located in Windows\SysWOW64 directory

To register OSSMTP on some versions of Windows you may need to run Command Prompt in Administrator mode
You can do it by clicking on its shortcut while holding Ctrl+Shift keys
At the command prompt enter the following: regsvr32 <full path to OSSMTP> and hit Enter key


Make sure OSSMTP shows in project references
To see project references go to Solution Explorer and expand References under the project
If you don't see References, click on "Show all files" icon on top of Solution Explorer

If there is no reference to OSSMTP, right click on References and select "Add Reference" from pop-up menu
Select Browse tab, then browse to OSSMTP.dll

If reference to OSSMTP shows with exclamation point, remove it and add a reference as described above


If you are running 64-bit Windows, make sure that project build/compile options are set to x86 CPU
