using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace smtp_csharp
{
	/// <summary>
	/// Summary description for frmAddCustomHeader.
	/// </summary>
	public class frmAddCustomHeader : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Button btnCancel;
    internal System.Windows.Forms.Button btnOK;
    internal System.Windows.Forms.Label Label18;
    internal System.Windows.Forms.TextBox txtHeaderValue;
    internal System.Windows.Forms.Label Label19;
    internal System.Windows.Forms.TextBox txtHeaderName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAddCustomHeader()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.Label18 = new System.Windows.Forms.Label();
            this.txtHeaderValue = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtHeaderName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(182, 64);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 20);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(78, 64);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 20);
            this.btnOK.TabIndex = 3;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(38, 32);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(34, 13);
            this.Label18.TabIndex = 23;
            this.Label18.Text = "Value";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtHeaderValue
            // 
            this.txtHeaderValue.Location = new System.Drawing.Point(78, 32);
            this.txtHeaderValue.Name = "txtHeaderValue";
            this.txtHeaderValue.Size = new System.Drawing.Size(184, 20);
            this.txtHeaderValue.TabIndex = 2;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(30, 8);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(42, 13);
            this.Label19.TabIndex = 21;
            this.Label19.Text = "Header";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // txtHeaderName
            // 
            this.txtHeaderName.Location = new System.Drawing.Point(78, 8);
            this.txtHeaderName.Name = "txtHeaderName";
            this.txtHeaderName.Size = new System.Drawing.Size(184, 20);
            this.txtHeaderName.TabIndex = 1;
            // 
            // frmAddCustomHeader
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(292, 93);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.txtHeaderValue);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.txtHeaderName);
            this.Name = "frmAddCustomHeader";
            this.Text = "Add Custom Header";
            this.ResumeLayout(false);
            this.PerformLayout();

    }
		#endregion

    private void btnOK_Click(object sender, System.EventArgs e)
    {
      this.Hide();
    }

    private void btnCancel_Click(object sender, System.EventArgs e)
    {
      txtHeaderName.Text = "";
      this.Hide();
    }
	}
}
