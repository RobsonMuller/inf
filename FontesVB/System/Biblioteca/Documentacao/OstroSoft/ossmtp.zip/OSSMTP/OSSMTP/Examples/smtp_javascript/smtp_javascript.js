/*
JavaScript example for OstroSoft SMTP Component
written by Igor Ostrovsky (OstroSoft)

For more information about OstroSoft SMTP Component go to
http://www.ostrosoft.com/ossmtp.aspx
*/

var sStatus = '';
var bClose = false;
var nTimeout = 1000;
var n = 0;

var oSMTP = new ActiveXObject("OSSMTP.SMTPSession");
WScript.ConnectObject(oSMTP, "oSMTP_");

oSMTP.Server = 'localhost'; //server name or IP address
oSMTP.MailFrom = 'info@localhost'; //sender e-mail address
oSMTP.SendTo = 'test@localhost'; //recipient e-mail address
oSMTP.MessageSubject = 'test message'; //message subject
oSMTP.MessageText = 'this is\r\nmulti-line test'; //message text

//oSMTP.Attachments.Add('c:\\Temp\\avatar.jpg'); //add an attachment

////connection and authentication
//oSMTP.Port = 465; //default SMTP port is 25, otherwise set it here
//oSMTP.AuthenticationType = 2; //most mailservers require authentication, values for this field are: 0 (default) - no authentication, 1 - authentication via POP3 session (obsolete), 2 - AUTH LOGIN, 3 - AUTH PLAIN, 4 - NTLM
//oSMTP.Username = '<your mailserver login>';
//oSMTP.Password = '<your mailserver password>';
//oSMTP.UseSSL = false; //set to true for mailservers requiring connection over SSL

//oSMTP.CustomHeaders.Add('x-custom-header: some value'); //add custom header

//oSMTP.EmbeddedObjects.Add('c:\\temp\\avatar.jpg'); //add embedded image
//oSMTP.MessageHTML = '<html><body>this is embedded image<br><img src=\"cid:avatar.jpg\"></body></html>'; //use added image

oSMTP.RaiseError = true; //when property set to true, component raises an error, otherwise - fires ErrorSMTP event

oSMTP.SendEmail();

function oSMTP_ConnectSMTP() {
//connected to mailserver
}

function oSMTP_SendSMTP() {
//message successfully sent
}

function oSMTP_StatusChanged(Status) {
  sStatus = sStatus + oSMTP.Status + '\r\n';
}

function oSMTP_ErrorSMTP(Number, Description) {
//error occured
  sStatus = sStatus + 'Error ' + Number + ': ' + Description + '\r\n';
  bClose = true;
}

function oSMTP_CloseSMTP() {
//connection to mailserver closed
  bClose = true;
}

while (!bClose) {
  WScript.Sleep(1);
  n = n + 1;
  if (n > nTimeout) {
    sStatus = sStatus + 'Timeout' + '\r\n';
    break;
  }
}

WScript.Echo(sStatus);
oSMTP = null;
