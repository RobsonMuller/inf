Imports System.Net
Imports System.IO

Public Class frm6_HTML
    Inherits System.Windows.Forms.Form
    Dim WithEvents oSMTP As OSSMTP.SMTPSession

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMailFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSendTo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMessageSubject As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMessageText As System.Windows.Forms.TextBox
    Friend WithEvents btnSendEmail As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ddlAuthenticationType As System.Windows.Forms.ComboBox
    Friend WithEvents txtPOPServer As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtMessageHTML As System.Windows.Forms.TextBox
    Friend WithEvents btnLoadFromFile As System.Windows.Forms.Button
    Friend WithEvents btnLoadFromURL As System.Windows.Forms.Button
    Private WithEvents chkUseSSL As System.Windows.Forms.CheckBox
    Friend WithEvents dlg As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMailFrom = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtSendTo = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMessageSubject = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtMessageText = New System.Windows.Forms.TextBox
        Me.btnSendEmail = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtPOPServer = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.ddlAuthenticationType = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtMessageHTML = New System.Windows.Forms.TextBox
        Me.btnLoadFromFile = New System.Windows.Forms.Button
        Me.btnLoadFromURL = New System.Windows.Forms.Button
        Me.dlg = New System.Windows.Forms.OpenFileDialog
        Me.chkUseSSL = New System.Windows.Forms.CheckBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(104, 8)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(184, 20)
        Me.txtServer.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Server"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Mail From"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMailFrom
        '
        Me.txtMailFrom.Location = New System.Drawing.Point(104, 152)
        Me.txtMailFrom.Name = "txtMailFrom"
        Me.txtMailFrom.Size = New System.Drawing.Size(184, 20)
        Me.txtMailFrom.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Send To"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtSendTo
        '
        Me.txtSendTo.Location = New System.Drawing.Point(104, 176)
        Me.txtSendTo.Name = "txtSendTo"
        Me.txtSendTo.Size = New System.Drawing.Size(184, 20)
        Me.txtSendTo.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 200)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Message Subject"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageSubject
        '
        Me.txtMessageSubject.Location = New System.Drawing.Point(104, 200)
        Me.txtMessageSubject.Name = "txtMessageSubject"
        Me.txtMessageSubject.Size = New System.Drawing.Size(184, 20)
        Me.txtMessageSubject.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 224)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Message Text"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageText
        '
        Me.txtMessageText.Location = New System.Drawing.Point(104, 224)
        Me.txtMessageText.Multiline = True
        Me.txtMessageText.Name = "txtMessageText"
        Me.txtMessageText.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMessageText.Size = New System.Drawing.Size(184, 96)
        Me.txtMessageText.TabIndex = 8
        '
        'btnSendEmail
        '
        Me.btnSendEmail.Location = New System.Drawing.Point(264, 328)
        Me.btnSendEmail.Name = "btnSendEmail"
        Me.btnSendEmail.Size = New System.Drawing.Size(75, 23)
        Me.btnSendEmail.TabIndex = 13
        Me.btnSendEmail.Text = "Send Email"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 344)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Status"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(8, 360)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(584, 168)
        Me.txtStatus.TabIndex = 14
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtPOPServer)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.ddlAuthenticationType)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 116)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Authentication settings"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(59, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Type"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "POP3 Server"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPOPServer
        '
        Me.txtPOPServer.Location = New System.Drawing.Point(96, 88)
        Me.txtPOPServer.Name = "txtPOPServer"
        Me.txtPOPServer.Size = New System.Drawing.Size(184, 20)
        Me.txtPOPServer.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(34, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Password"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(96, 64)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(184, 20)
        Me.txtPassword.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Username"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(96, 40)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(184, 20)
        Me.txtUsername.TabIndex = 2
        '
        'ddlAuthenticationType
        '
        Me.ddlAuthenticationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlAuthenticationType.Location = New System.Drawing.Point(96, 16)
        Me.ddlAuthenticationType.Name = "ddlAuthenticationType"
        Me.ddlAuthenticationType.Size = New System.Drawing.Size(184, 21)
        Me.ddlAuthenticationType.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(304, 8)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 13)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Message HTML"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtMessageHTML
        '
        Me.txtMessageHTML.Location = New System.Drawing.Point(304, 24)
        Me.txtMessageHTML.Multiline = True
        Me.txtMessageHTML.Name = "txtMessageHTML"
        Me.txtMessageHTML.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMessageHTML.Size = New System.Drawing.Size(288, 256)
        Me.txtMessageHTML.TabIndex = 10
        '
        'btnLoadFromFile
        '
        Me.btnLoadFromFile.Location = New System.Drawing.Point(344, 288)
        Me.btnLoadFromFile.Name = "btnLoadFromFile"
        Me.btnLoadFromFile.Size = New System.Drawing.Size(96, 23)
        Me.btnLoadFromFile.TabIndex = 11
        Me.btnLoadFromFile.Text = "Load from file"
        '
        'btnLoadFromURL
        '
        Me.btnLoadFromURL.Location = New System.Drawing.Point(456, 288)
        Me.btnLoadFromURL.Name = "btnLoadFromURL"
        Me.btnLoadFromURL.Size = New System.Drawing.Size(96, 23)
        Me.btnLoadFromURL.TabIndex = 12
        Me.btnLoadFromURL.Text = "Load from URL"
        '
        'chkUseSSL
        '
        Me.chkUseSSL.AutoSize = True
        Me.chkUseSSL.Location = New System.Drawing.Point(104, 326)
        Me.chkUseSSL.Name = "chkUseSSL"
        Me.chkUseSSL.Size = New System.Drawing.Size(68, 17)
        Me.chkUseSSL.TabIndex = 9
        Me.chkUseSSL.Text = "Use SSL"
        Me.chkUseSSL.UseVisualStyleBackColor = True
        '
        'frm6_HTML
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 533)
        Me.Controls.Add(Me.chkUseSSL)
        Me.Controls.Add(Me.btnLoadFromURL)
        Me.Controls.Add(Me.btnLoadFromFile)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtMessageHTML)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtMessageText)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtMessageSubject)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtSendTo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMailFrom)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtServer)
        Me.Controls.Add(Me.btnSendEmail)
        Me.Name = "frm6_HTML"
        Me.Text = "Sending email (with HTML part)"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub btnSendEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendEmail.Click
        txtStatus.Text = ""
        With oSMTP
            'connection
            .Server = txtServer.Text
            'authentication
            .AuthenticationType = ddlAuthenticationType.SelectedIndex
            If txtUsername.Text <> "" Then .Username = txtUsername.Text
            If txtPassword.Text <> "" Then .Password = txtPassword.Text
            If txtPOPServer.Text <> "" Then .POPServer = txtPOPServer.Text
            oSMTP.UseSSL = chkUseSSL.Checked
            'message
            .MailFrom = txtMailFrom.Text
            .SendTo = txtSendTo.Text
            .MessageSubject = txtMessageSubject.Text
            .MessageText = txtMessageText.Text
            .MessageHTML = txtMessageHTML.Text
            'send email
            .SendEmail()
        End With
    End Sub

    Private Sub oSMTP_ErrorSMTP(ByVal Number As Short, ByRef Description As String) Handles oSMTP.ErrorSMTP
        txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
    End Sub

    Private Sub oSMTP_StatusChanged(ByVal Status As String) Handles oSMTP.StatusChanged
        txtStatus.Text = txtStatus.Text & oSMTP.Status & vbCrLf
    End Sub

    Private Sub frm1_Basic_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        oSMTP = New OSSMTP.SMTPSession
        With ddlAuthenticationType.Items
            .Add("None")
            .Add("POP3")
            .Add("AUTH LOGIN")
            .Add("AUTH PLAIN")
            .Add("NTLM")
        End With
        ddlAuthenticationType.SelectedIndex = 0
    End Sub

    Private Sub frm1_Basic_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        oSMTP = Nothing
    End Sub

    Private Sub ddlAuthenticationType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlAuthenticationType.SelectedIndexChanged
        Select Case ddlAuthenticationType.SelectedIndex
            Case OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = False
                txtUsername.Text = ""
                txtPassword.Enabled = False
                txtPassword.Text = ""
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
            Case OSSMTP.authentication_type.AuthPOP
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = True
            Case OSSMTP.authentication_type.AuthLogin, OSSMTP.authentication_type.AuthNone
                txtUsername.Enabled = True
                txtPassword.Enabled = True
                txtPOPServer.Enabled = False
                txtPOPServer.Text = ""
        End Select
    End Sub

    Private Sub btnLoadFromFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadFromFile.Click
        dlg.ShowDialog()
        If dlg.FileName <> "" Then
            Dim oStreamReader As StreamReader = New StreamReader(dlg.FileName)
            Dim s As String = ""
            While oStreamReader.Peek > -1
                s = s & oStreamReader.ReadLine
            End While
            oStreamReader.Close()
            txtMessageHTML.Text = s
        End If
    End Sub

    Private Sub btnLoadFromURL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadFromURL.Click
        Dim sFile As String = InputBox("Enter URL", "Enter URL", "http://localhost")
        Dim oHttpWebRequest As HttpWebRequest = CType(WebRequest.Create(sFile), HttpWebRequest)
        Dim oHttpWebResponse As HttpWebResponse = oHttpWebRequest.GetResponse
        Dim oStream As Stream = oHttpWebResponse.GetResponseStream()
        Dim oStreamReader As StreamReader = New StreamReader(oStream)
        Dim s As String = ""
        While oStreamReader.Peek > -1
            s = s & oStreamReader.ReadLine
        End While
        oStreamReader.Close()
        oStream.Close()
        oHttpWebResponse.Close()
        txtMessageHTML.Text = s
    End Sub
End Class
