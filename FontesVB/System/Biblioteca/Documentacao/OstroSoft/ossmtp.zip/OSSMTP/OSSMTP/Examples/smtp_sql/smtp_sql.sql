/*
SQL server example for OstroSoft SMTP Component
written by Igor Ostrovsky (OstroSoft)

For more information about OstroSoft SMTP Component go to
http://www.ostrosoft.com/ossmtp.aspx
*/

DECLARE @hSMTP int
DECLARE @hAttachment int
DECLARE @nRet int
DECLARE @src varchar(255), @desc varchar(255)

-- create SMTPSession object
EXEC @nRet = sp_OACreate 'OSSMTP.SMTPSession', @hSMTP OUT
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- set SMTPSession object properties
EXEC @nRet = sp_OASetProperty @hSMTP, 'RaiseError', -1 -- raise SMTP errors
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hSMTP, 'Server', 'localhost' -- mailserver hostname or IP address
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hSMTP, 'MailFrom', 'test' -- sender email address
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hSMTP, 'SendTo', 'info' -- recipient email address
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hSMTP, 'MessageSubject', 'test message' -- message subject
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hSMTP, 'MessageText', 'this is multi-line message' -- message body
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- create Attachment object
EXEC @nRet = sp_OACreate 'OSSMTP.Attachment', @hAttachment OUT
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hAttachment, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- set Attachment object properties
-- !!make sure to set a full path!!
EXEC @nRet = sp_OASetProperty @hAttachment, 'FilePath', 'c:\temp.zip' -- full path to attachment location
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hAttachment, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hAttachment, 'AttachmentName', 'test' -- attachment name
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hAttachment, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hAttachment, 'ContentType', 'application/octet-stream' -- content type of attachment
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hAttachment, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

EXEC @nRet = sp_OASetProperty @hAttachment, 'ContentTransferEncoding', 0 -- 0 - encBase64, 1 - enc7Bit
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hAttachment, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- add attachment to SMTPSession object
EXEC @nRet = sp_OAMethod @hSMTP, 'Attachments.Add', NULL, @hAttachment
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
  SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
  RETURN 
END

-- send email
EXEC @nRet = sp_OAMethod @hSMTP, 'SendEmail'
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- destroy SMTP object
EXEC @nRet = sp_OADestroy @hSMTP
IF @nRet <> 0
BEGIN
  EXEC sp_OAGetErrorInfo @hSMTP, @src OUT, @desc OUT
	SELECT Status = 'Error', Number = CONVERT(varbinary(4), @nRet), Source = @src, Description = @desc
	RETURN
END

-- no errors occured during the session
-- we assume the message was accepted
SELECT Status = 'Message accepted for delivery'
