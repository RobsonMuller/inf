using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace smtp_csharp
{
    /// <summary>
    /// Summary description for frmMain.
    /// </summary>
    public class frmMain : System.Windows.Forms.Form
    {
        internal System.Windows.Forms.Button btnExit;
        internal System.Windows.Forms.Button btnAll;
        internal System.Windows.Forms.Button btnHeaders;
        internal System.Windows.Forms.Button btnAttachments;
        internal System.Windows.Forms.Button btnAuthentication;
        internal System.Windows.Forms.Button btnBasic;
        internal System.Windows.Forms.Button btnHTML;
        internal System.Windows.Forms.Label lbl;
        internal Button btnEmbed;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public frmMain()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnHeaders = new System.Windows.Forms.Button();
            this.btnAttachments = new System.Windows.Forms.Button();
            this.btnAuthentication = new System.Windows.Forms.Button();
            this.btnBasic = new System.Windows.Forms.Button();
            this.btnHTML = new System.Windows.Forms.Button();
            this.lbl = new System.Windows.Forms.Label();
            this.btnEmbed = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(352, 320);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(64, 23);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(20, 145);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(392, 23);
            this.btnAll.TabIndex = 4;
            this.btnAll.Text = "Sending email (all properties, collections and methods)";
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnHeaders
            // 
            this.btnHeaders.Location = new System.Drawing.Point(20, 113);
            this.btnHeaders.Name = "btnHeaders";
            this.btnHeaders.Size = new System.Drawing.Size(392, 23);
            this.btnHeaders.TabIndex = 3;
            this.btnHeaders.Text = "Sending email (with extra headers and additional recipients)";
            this.btnHeaders.Click += new System.EventHandler(this.btnHeaders_Click);
            // 
            // btnAttachments
            // 
            this.btnAttachments.Location = new System.Drawing.Point(20, 81);
            this.btnAttachments.Name = "btnAttachments";
            this.btnAttachments.Size = new System.Drawing.Size(392, 23);
            this.btnAttachments.TabIndex = 2;
            this.btnAttachments.Text = "Sending email (with attachments)";
            this.btnAttachments.Click += new System.EventHandler(this.btnAttachments_Click);
            // 
            // btnAuthentication
            // 
            this.btnAuthentication.Location = new System.Drawing.Point(20, 49);
            this.btnAuthentication.Name = "btnAuthentication";
            this.btnAuthentication.Size = new System.Drawing.Size(392, 23);
            this.btnAuthentication.TabIndex = 1;
            this.btnAuthentication.Text = "Sending email (with authentication)";
            this.btnAuthentication.Click += new System.EventHandler(this.btnAuthentication_Click);
            // 
            // btnBasic
            // 
            this.btnBasic.Location = new System.Drawing.Point(20, 16);
            this.btnBasic.Name = "btnBasic";
            this.btnBasic.Size = new System.Drawing.Size(392, 23);
            this.btnBasic.TabIndex = 0;
            this.btnBasic.Text = "Sending email (basic)";
            this.btnBasic.Click += new System.EventHandler(this.btnBasic_Click);
            // 
            // btnHTML
            // 
            this.btnHTML.Location = new System.Drawing.Point(20, 176);
            this.btnHTML.Name = "btnHTML";
            this.btnHTML.Size = new System.Drawing.Size(392, 23);
            this.btnHTML.TabIndex = 5;
            this.btnHTML.Text = "Sending email (with HTML part)";
            this.btnHTML.Click += new System.EventHandler(this.btnHTML_Click);
            // 
            // lbl
            // 
            this.lbl.Location = new System.Drawing.Point(24, 248);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(392, 56);
            this.lbl.TabIndex = 14;
            // 
            // btnEmbed
            // 
            this.btnEmbed.Location = new System.Drawing.Point(20, 208);
            this.btnEmbed.Name = "btnEmbed";
            this.btnEmbed.Size = new System.Drawing.Size(392, 23);
            this.btnEmbed.TabIndex = 15;
            this.btnEmbed.Text = "Sending email (with HTML and embedded objects)";
            this.btnEmbed.Click += new System.EventHandler(this.btnEmbed_Click);
            // 
            // frmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(432, 349);
            this.Controls.Add(this.btnEmbed);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.btnHTML);
            this.Controls.Add(this.btnBasic);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.btnHeaders);
            this.Controls.Add(this.btnAttachments);
            this.Controls.Add(this.btnAuthentication);
            this.Name = "frmMain";
            this.Text = "C# samples for OstroSoft SMTP Component (OSSMTP.dll)";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }
        #endregion

        [STAThread]
        static void Main()
        {
            Application.Run(new frmMain());
        }

        private void btnExit_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void btnBasic_Click(object sender, System.EventArgs e)
        {
            frm1_Basic frm = new frm1_Basic();
            frm.Show();
        }

        private void btnAuthentication_Click(object sender, System.EventArgs e)
        {
            frm2_Authentication frm = new frm2_Authentication();
            frm.Show();
        }

        private void btnAttachments_Click(object sender, System.EventArgs e)
        {
            frm3_Attachments frm = new frm3_Attachments();
            frm.Show();
        }

        private void btnHeaders_Click(object sender, System.EventArgs e)
        {
            frm4_Headers frm = new frm4_Headers();
            frm.Show();
        }

        private void btnAll_Click(object sender, System.EventArgs e)
        {
            frm5_All frm = new frm5_All();
            frm.Show();
        }

        private void btnHTML_Click(object sender, System.EventArgs e)
        {
            frm6_HTML frm = new frm6_HTML();
            frm.Show();
        }

        private void frmMain_Load(object sender, System.EventArgs e)
        {
            lbl.Text = "OstroSoft SMTP Component sample for C#,\n" +
              "written by Igor Ostrovsky (OstroSoft)\n" +
              "For more information about OstroSoft SMTP Component go to\n" +
              "http://www.ostrosoft.com/ossmtp.aspx";
        }

        private void btnEmbed_Click(object sender, EventArgs e)
        {
            frm7_EmbeddedObjects frm = new frm7_EmbeddedObjects();
            frm.Show();
        }
    }
}
