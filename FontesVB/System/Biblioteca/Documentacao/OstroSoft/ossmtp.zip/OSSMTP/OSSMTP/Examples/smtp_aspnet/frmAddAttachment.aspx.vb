Partial Class frmAddAttachment
    Inherits System.Web.UI.Page
    Public sStatus As String = ""
    Public PAGE_TITLE As String = "Add Attachment"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnAdd_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.ServerClick
        Dim sName As String = ""
        Dim sPath As String = ""

        If Not File1.PostedFile Is Nothing And File1.PostedFile.ContentLength > 0 Then
            Try
                Dim sGUID As String = System.Guid.NewGuid.ToString
                With File1.PostedFile
                    sName = Mid(.FileName, InStrRev(.FileName, "\") + 1)
                    sPath = Server.MapPath("Attachments") & "\" & sName
                    .SaveAs(sPath)
                End With
                Session(sGUID) = sPath
                Response.Write("<script language=javascript>")
                Response.Write("var ddl = window.opener.document.getElementById('lstAttachments');")
                Response.Write("var opt = window.opener.document.createElement('option');")
                Response.Write("opt.text = '" & sName & "';")
                Response.Write("opt.value = '" & sGUID & "';")
                Response.Write("ddl.options.add(opt);")
                Response.Write("ddl.selectedIndex = ddl.options.length - 1;")
                Response.Write("ddl.focus();")
                Response.Write("window.close();")
                Response.Write("</script>")
                Response.End()
            Catch exUpload As Exception
                sStatus = "Error: " & exUpload.Message
            End Try
        Else
            sStatus = "Please select a file to upload."
        End If
    End Sub
End Class
