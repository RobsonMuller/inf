'VB.NET example for OstroSoft POP3 Component
'written by Igor Ostrovsky (OstroSoft)
'
'For more information about OstroSoft POP3 Component go to
'http://www.ostrosoft.com/ospop3.aspx
'
'Questions, suggestions, comments - email to info@ostrosoft.com
'or submit a form at http://www.ostrosoft.com/contact.aspx

Public Class frmSession
  Inherits System.Windows.Forms.Form

    Public WithEvents oSession As New OSPOP3_Plus.Session
    Public bHeadersOnly As Boolean

#Region " Windows Form Designer declarations "
    Private WithEvents chkSSL As System.Windows.Forms.CheckBox
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPort As System.Windows.Forms.TextBox
    Friend WithEvents cmdConnect As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdHeaders As System.Windows.Forms.Button
    Friend WithEvents fmMessages As System.Windows.Forms.GroupBox
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdView As System.Windows.Forms.Button
    Friend WithEvents lvwMessages As System.Windows.Forms.ListView
    Friend WithEvents clmID As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmSize As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmUIDL As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdReset As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtSize As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtLogin As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.chkSSL = New System.Windows.Forms.CheckBox
        Me.cmdRefresh = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.txtNumber = New System.Windows.Forms.TextBox
        Me.txtPort = New System.Windows.Forms.TextBox
        Me.cmdConnect = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmdHeaders = New System.Windows.Forms.Button
        Me.fmMessages = New System.Windows.Forms.GroupBox
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.cmdView = New System.Windows.Forms.Button
        Me.lvwMessages = New System.Windows.Forms.ListView
        Me.clmID = New System.Windows.Forms.ColumnHeader
        Me.clmSize = New System.Windows.Forms.ColumnHeader
        Me.clmUIDL = New System.Windows.Forms.ColumnHeader
        Me.cmdReset = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtSize = New System.Windows.Forms.TextBox
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtLogin = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.fmMessages.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkSSL
        '
        Me.chkSSL.AutoSize = True
        Me.chkSSL.Location = New System.Drawing.Point(148, 58)
        Me.chkSSL.Name = "chkSSL"
        Me.chkSSL.Size = New System.Drawing.Size(68, 17)
        Me.chkSSL.TabIndex = 4
        Me.chkSSL.Text = "Use SSL"
        Me.chkSSL.UseVisualStyleBackColor = True
        '
        'cmdRefresh
        '
        Me.cmdRefresh.Location = New System.Drawing.Point(448, 160)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.Size = New System.Drawing.Size(113, 23)
        Me.cmdRefresh.TabIndex = 8
        Me.cmdRefresh.Text = "Refresh Msg. List"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(232, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 13)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Number of emails"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(195, 26)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(26, 13)
        Me.label2.TabIndex = 9
        Me.label2.Text = "Port"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(328, 24)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(48, 20)
        Me.txtNumber.TabIndex = 7
        Me.txtNumber.Text = "0"
        Me.txtNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPort
        '
        Me.txtPort.Location = New System.Drawing.Point(224, 24)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.Size = New System.Drawing.Size(36, 20)
        Me.txtPort.TabIndex = 1
        Me.txtPort.Text = "110"
        '
        'cmdConnect
        '
        Me.cmdConnect.Location = New System.Drawing.Point(229, 54)
        Me.cmdConnect.Name = "cmdConnect"
        Me.cmdConnect.Size = New System.Drawing.Size(113, 23)
        Me.cmdConnect.TabIndex = 5
        Me.cmdConnect.Text = "Connect"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(400, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Password"
        '
        'cmdHeaders
        '
        Me.cmdHeaders.Location = New System.Drawing.Point(448, 92)
        Me.cmdHeaders.Name = "cmdHeaders"
        Me.cmdHeaders.Size = New System.Drawing.Size(113, 23)
        Me.cmdHeaders.TabIndex = 11
        Me.cmdHeaders.Text = "View Headers"
        '
        'fmMessages
        '
        Me.fmMessages.Controls.Add(Me.cmdDelete)
        Me.fmMessages.Controls.Add(Me.cmdHeaders)
        Me.fmMessages.Controls.Add(Me.cmdView)
        Me.fmMessages.Controls.Add(Me.lvwMessages)
        Me.fmMessages.Controls.Add(Me.cmdReset)
        Me.fmMessages.Controls.Add(Me.cmdRefresh)
        Me.fmMessages.Controls.Add(Me.Label6)
        Me.fmMessages.Controls.Add(Me.txtNumber)
        Me.fmMessages.Controls.Add(Me.Label5)
        Me.fmMessages.Controls.Add(Me.txtSize)
        Me.fmMessages.Location = New System.Drawing.Point(2, 94)
        Me.fmMessages.Name = "fmMessages"
        Me.fmMessages.Size = New System.Drawing.Size(568, 192)
        Me.fmMessages.TabIndex = 20
        Me.fmMessages.TabStop = False
        Me.fmMessages.Text = "Messages"
        '
        'cmdDelete
        '
        Me.cmdDelete.Location = New System.Drawing.Point(448, 120)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(113, 23)
        Me.cmdDelete.TabIndex = 12
        Me.cmdDelete.Text = "Delete Message"
        '
        'cmdView
        '
        Me.cmdView.Location = New System.Drawing.Point(448, 64)
        Me.cmdView.Name = "cmdView"
        Me.cmdView.Size = New System.Drawing.Size(113, 23)
        Me.cmdView.TabIndex = 10
        Me.cmdView.Text = "View Message"
        '
        'lvwMessages
        '
        Me.lvwMessages.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.clmID, Me.clmSize, Me.clmUIDL})
        Me.lvwMessages.FullRowSelect = True
        Me.lvwMessages.HideSelection = False
        Me.lvwMessages.Location = New System.Drawing.Point(8, 56)
        Me.lvwMessages.Name = "lvwMessages"
        Me.lvwMessages.Size = New System.Drawing.Size(432, 128)
        Me.lvwMessages.TabIndex = 13
        Me.lvwMessages.UseCompatibleStateImageBehavior = False
        Me.lvwMessages.View = System.Windows.Forms.View.Details
        '
        'clmID
        '
        Me.clmID.Text = "ID"
        Me.clmID.Width = 38
        '
        'clmSize
        '
        Me.clmSize.Text = "Size"
        Me.clmSize.Width = 91
        '
        'clmUIDL
        '
        Me.clmUIDL.Text = "UIDL"
        Me.clmUIDL.Width = 274
        '
        'cmdReset
        '
        Me.cmdReset.Location = New System.Drawing.Point(448, 24)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.Size = New System.Drawing.Size(113, 23)
        Me.cmdReset.TabIndex = 9
        Me.cmdReset.Text = "Reset Session"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Mailbox size, octets (bytes)"
        '
        'txtSize
        '
        Me.txtSize.Location = New System.Drawing.Point(160, 24)
        Me.txtSize.Name = "txtSize"
        Me.txtSize.Size = New System.Drawing.Size(56, 20)
        Me.txtSize.TabIndex = 6
        Me.txtSize.Text = "0"
        Me.txtSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(456, 24)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(102, 20)
        Me.txtPassword.TabIndex = 3
        Me.txtPassword.Text = "info"
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(10, 294)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(560, 144)
        Me.txtStatus.TabIndex = 21
        Me.txtStatus.Text = "Connection status"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(262, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Login"
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(48, 24)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(141, 20)
        Me.txtServer.TabIndex = 0
        Me.txtServer.Text = "localhost"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkSSL)
        Me.GroupBox1.Controls.Add(Me.label2)
        Me.GroupBox1.Controls.Add(Me.txtPort)
        Me.GroupBox1.Controls.Add(Me.cmdConnect)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtLogin)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtServer)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(568, 87)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Session"
        '
        'txtLogin
        '
        Me.txtLogin.Location = New System.Drawing.Point(295, 24)
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.Size = New System.Drawing.Size(105, 20)
        Me.txtLogin.TabIndex = 2
        Me.txtLogin.Text = "info"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Server"
        '
        'frmSession
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(572, 440)
        Me.Controls.Add(Me.fmMessages)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmSession"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OstroSoft POP3 Component"
        Me.fmMessages.ResumeLayout(False)
        Me.fmMessages.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub frmSession_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        fmMessages.Enabled = False
    End Sub

    Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
        cmdConnect.Enabled = False
        If cmdConnect.Text = "Connect" Then
            txtStatus.Text = ""
            oSession.UseSSL = chkSSL.Checked
            oSession.OpenPOP3(txtServer.Text, Convert.ToInt32(txtPort.Text), txtLogin.Text, txtPassword.Text)
        Else
            oSession.ClosePOP3()
        End If
    End Sub

    Private Sub cmdRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        GetStats()
    End Sub

    Private Sub cmdReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReset.Click
        oSession.ResetSession()
        GetStats()
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If lvwMessages.SelectedItems.Count > 0 Then
            If MsgBox("Would you like to delete a selected email?", vbYesNo, "Confirm") = vbYes Then
                oSession.DeleteMessage(lvwMessages.SelectedItems(0).Text)
                lvwMessages.Items.Remove(lvwMessages.SelectedItems(0))
            End If
        End If
    End Sub

    Private Sub cmdHeaders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHeaders.Click
        If lvwMessages.SelectedItems.Count > 0 Then
            bHeadersOnly = True
            Dim frm As New frmMessage
            With frm
                .iMessageID = lvwMessages.SelectedItems(0).Text
                .bHeadersOnly = bHeadersOnly
                .oSession = oSession
                .ShowDialog()
            End With
        End If
    End Sub

    Private Sub cmdView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdView.Click
        If lvwMessages.SelectedItems.Count > 0 Then
            bHeadersOnly = False
            Dim frm As New frmMessage
            With frm
                .iMessageID = lvwMessages.SelectedItems(0).Text
                .bHeadersOnly = bHeadersOnly
                .oSession = oSession
                .ShowDialog()
            End With
        End If
    End Sub

    Private Sub txtStatus_Change(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtStatus.Click
        txtStatus.SelectionStart = Len(txtStatus.Text)
        txtStatus.ScrollToCaret()
    End Sub

    Private Sub oSession_Closed() Handles oSession.Closed
        txtSize.Text = "0"
        txtNumber.Text = "0"
        lvwMessages.Items.Clear()

        cmdConnect.Text = "Connect"
        cmdConnect.Enabled = True
        fmMessages.Enabled = False
    End Sub

    Private Sub oSession_Connected() Handles oSession.Connected
        GetStats()
        cmdConnect.Text = "Disconnect"
        cmdConnect.Enabled = True
        fmMessages.Enabled = True
    End Sub

    Private Sub oSession_ErrorPOP3(ByVal Number As Integer, ByVal Description As String) Handles oSession.ErrorPOP3
        'txtStatus.Text = txtStatus.Text & "Error " & Number & ": " & Description & vbCrLf
        If oSession.State = OSPOP3_Plus.Session.StateConstants.popClosed Then
            cmdConnect.Text = "Connect"
            fmMessages.Enabled = False
        Else
            cmdConnect.Text = "Disconnect"
        End If
        cmdConnect.Enabled = True
    End Sub

    Private Sub oSession_StatusChanged(ByVal Status As String, ByVal StatusType As OSPOP3_Plus.Session.StatusTypeConstants) Handles oSession.StatusChanged
        Dim sPrompt As String
        Select Case StatusType
            Case OSPOP3_Plus.Session.StatusTypeConstants.stPOP3Request : sPrompt = "< "
            Case OSPOP3_Plus.Session.StatusTypeConstants.stPOP3Response : sPrompt = "> "
            Case OSPOP3_Plus.Session.StatusTypeConstants.stError : sPrompt = "! "
            Case OSPOP3_Plus.Session.StatusTypeConstants.stState : sPrompt = "# "
            Case Else : sPrompt = "? "
        End Select

        txtStatus.Text = txtStatus.Text & sPrompt & Status & vbCrLf
    End Sub

    Private Sub GetStats()
        oSession.GetMailboxSize()
        txtSize.Text = oSession.MailboxSize
        txtNumber.Text = oSession.MessageCount

        Dim oMessageList As New Collection
        Dim oMLE As OSPOP3_Plus.MessageListEntry
        Dim li As ListViewItem

        lvwMessages.Items.Clear()
        oSession.GetMessageList()
        For Each oMLE In oSession.MessageList
            li = lvwMessages.Items.Add(oMLE.ID)
            li.SubItems.Add(oMLE.Size)
            li.SubItems.Add(oMLE.UIDL)
        Next
    End Sub
End Class
