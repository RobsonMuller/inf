Public Class frmMessage
    Inherits System.Windows.Forms.Form

    Public oSession As New OSPOP3_Plus.Session
    Public iMessageID As Integer
    Public bHeadersOnly As Boolean

    Private m As OSPOP3_Plus.Message

#Region " Windows Form Designer declarations "
    Private WithEvents dlgFolder As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Private WithEvents chkAttachments As System.Windows.Forms.CheckBox
    Private WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents tvw As System.Windows.Forms.TreeView


    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.dlgFolder = New System.Windows.Forms.FolderBrowserDialog()
        Me.tvw = New System.Windows.Forms.TreeView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkAttachments = New System.Windows.Forms.CheckBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tvw
        '
        Me.tvw.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tvw.Location = New System.Drawing.Point(2, 4)
        Me.tvw.Name = "tvw"
        Me.tvw.Size = New System.Drawing.Size(324, 313)
        Me.tvw.TabIndex = 4
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Panel1.Controls.Add(Me.chkAttachments)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Location = New System.Drawing.Point(55, 323)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(218, 40)
        Me.Panel1.TabIndex = 6
        '
        'chkAttachments
        '
        Me.chkAttachments.AutoSize = True
        Me.chkAttachments.Location = New System.Drawing.Point(93, 12)
        Me.chkAttachments.Name = "chkAttachments"
        Me.chkAttachments.Size = New System.Drawing.Size(121, 17)
        Me.chkAttachments.TabIndex = 7
        Me.chkAttachments.Text = "include attachments"
        Me.chkAttachments.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(12, 10)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 6
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'frmMessage
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 360)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.tvw)
        Me.Name = "frmMessage"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Message"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmMessage_Load(ByVal sender As Object, ByVal evt As System.EventArgs) Handles MyBase.Load
        Dim h As OSPOP3_Plus.Header
        Dim s As String
        Dim e As OSPOP3_Plus.Email
        Dim a As OSPOP3_Plus.Attachment

        'On Error GoTo err_handler
        tvw.Nodes.Clear()

        If bHeadersOnly Then
            m = oSession.GetMessageHeaders(iMessageID)
        Else
            m = oSession.GetMessage(iMessageID)
        End If

        Dim nd As TreeNode = tvw.Nodes.Add("message " & iMessageID)

        Dim ndFrom As TreeNode = nd.Nodes.Add("from")
        ndFrom.Nodes.Add("name: " & m.Sender.Name)
        ndFrom.Nodes.Add("address: " & m.Sender.Address)

        Dim ndTo As TreeNode = nd.Nodes.Add("to")
        Dim ndRecipient As TreeNode
        For Each e In m.Recipients
            ndRecipient = ndTo.Nodes.Add("recipient")
            ndRecipient.Nodes.Add("name: " & e.Name)
            ndRecipient.Nodes.Add("address: " & e.Address)
        Next

        Dim ndChild As TreeNode
        ndChild = nd.Nodes.Add("subject")
        ndChild.Nodes.Add(m.Subject)

        ndChild = nd.Nodes.Add("date")
        ndChild.Nodes.Add(m.DateSent)

        ndChild = nd.Nodes.Add("Content-Type")
        ndChild.Nodes.Add(m.ContentType)

        ndChild = nd.Nodes.Add("Charset")
        ndChild.Nodes.Add(m.Charset)

        ndChild = nd.Nodes.Add("UIDL")
        ndChild.Nodes.Add(m.UIDL)

        Dim ndHeaders As TreeNode
        ndHeaders = nd.Nodes.Add("headers")
        Dim ndHeader As TreeNode
        For Each h In m.Headers
            ndHeader = ndHeaders.Nodes.Add(h.Name)
            For Each s In h.Values
                ndHeader.Nodes.Add(s)
            Next
        Next

        If Not bHeadersOnly Then
            ndChild = nd.Nodes.Add("body")
            ndChild.Nodes.Add(m.Body)

            ndChild = nd.Nodes.Add("html")
            ndChild.Nodes.Add(m.HTMLBody)

            ndChild = nd.Nodes.Add("attachments")
            Dim ndAttachment As TreeNode
            For Each a In m.Attachments
                ndAttachment = ndChild.Nodes.Add(a.AttachmentName)
                ndAttachment.Nodes.Add("ContentDisposition: " & a.ContentDisposition)
                ndAttachment.Nodes.Add("ContentTransferEncoding: " & a.ContentTransferEncoding)
                ndAttachment.Nodes.Add("ContentType: " & a.ContentType)
                ndAttachment.Nodes.Add("FileName: " & a.Filename)
                ndAttachment.Nodes.Add("Body: " & a.Body)
                'a.Save App.Path & "\" & a.FileName 'uncomment to save an attachment
            Next

            'm.Save App.Path & "\" & m.UIDL & ".eml" 'uncomment to save the message
        End If

        tvw.ExpandAll()
        ndHeaders.Collapse()
        tvw.SelectedNode = nd

err_handler:
        If Err.Number <> 0 Then MsgBox("Error " & Err.Number & ": " & Err.Description)
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        dlgFolder.ShowDialog()
        Dim path As String = dlgFolder.SelectedPath
        m.Save(path + "\\" + m.UIDL + ".eml")
        If (chkAttachments.Checked) Then
            Dim a As OSPOP3_Plus.Attachment
            For Each a In m.Attachments
                Dim fileName As String = ""
                Dim attachmentCounter As Integer = 1
                If a.AttachmentName <> "" Then
                    fileName = a.AttachmentName.Replace("""", "") 'attachment name may contain quotes!
                Else
                    fileName = "attachment_" + attachmentCounter.ToString() 'file name can't be blank
                    If a.ContentType = "message/rfc822" Then
                        fileName = fileName + ".eml"
                    End If

                End If
                a.Save(path + "\" + fileName)
                attachmentCounter = attachmentCounter + 1
            Next
        End If
        MessageBox.Show("message saved")
    End Sub
End Class
